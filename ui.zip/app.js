import { $, sleep, isTyping } from "./js/dom.js";
import { state } from "./js/state.js";
import { bridgeProbe, bridgeWindow } from "./js/bridge.js";
import { on } from "./js/bus.js";
import { initFx, setWindowActive } from "./js/fx.js";
import { initTooltips, hideTooltip } from "./js/tooltip.js";
import { toast } from "./js/toast.js";
import { isOverlayOpen } from "./js/dialog.js";
import { isMenuOpen } from "./js/menu.js";
import { initConsole, clearConsole, focusConsoleSearch, log } from "./js/console.js";
import { initEditor, newTab, closeTab, cycleTab, openFileDialog, saveActive, currentScript, renameActiveTab, flushPersist, pasteFromClipboard, clearEditor } from "./js/editor.js";
import { initLibrary, focusLibrarySearch } from "./js/library.js";
import { initNav, goToPage, toggleSidebar, toggleConsole, PAGE_IDS } from "./js/nav.js";
import { initActions, runScript, inject, launchSupportedRoblox } from "./js/actions.js";
import { initLicense, checkAuth, showLicenseGate } from "./js/license.js";
import { initAccount, renderAccount } from "./js/account.js";
import { initVersions } from "./js/versions.js";
import { initMenuBar, toggleBottomConsole } from "./js/menubar.js";
import { initHomeAndExplorer } from "./js/home.js";
import { initSettings, loadSettings, applyLocalPrefs } from "./js/settings.js";
import { initUpdate, checkUpdate } from "./js/update.js";
import { initPalette, openPalette, isPaletteOpen } from "./js/palette.js";
import { openShortcuts } from "./js/shortcuts.js";
import { pollStatus, startPolling } from "./js/status.js";
import { store } from "./js/store.js";
import { initCtxMenu } from "./js/ctxmenu.js";
import { initAccounts } from "./js/accounts.js";
import { bridgeGet, bridgePost } from "./js/bridge.js";
import { confirmDialog } from "./js/dialog.js";
import { startSetup } from "./js/setup.js";

const html = document.documentElement;
const BOOT_MIN_MS = 450;
const UPDATE_INTERVAL_MS = 30 * 60 * 1000;

applyLocalPrefs();

function safe(name, fn) {
  try { fn(); } catch (e) { console.error(`[byte] ${name} failed to init`, e); }
}

function applyWindowState(s) {
  if (!s || typeof s !== "object") return;
  if ("maximized" in s) {
    html.classList.toggle("is-max", !!s.maximized);
    const b = $("#win-max");
    const label = s.maximized ? "Restore" : "Maximize";
    b.setAttribute("aria-label", label);
  }
  if ("active" in s) setWindowActive(!!s.active);
}

function initWindow() {
  $("#win-min").addEventListener("click", () => bridgeWindow("min"));
  $("#win-max").addEventListener("click", () => bridgeWindow("max"));
  $("#win-close").addEventListener("click", () => { flushPersist(); bridgeWindow("close"); });

  window.chrome?.webview?.addEventListener?.("message", (e) => {
    if (e.data && e.data.type === "window") applyWindowState(e.data);
  });
  bridgeProbe("/window/state").then(applyWindowState);
}

function onKey(e) {
  if (e.defaultPrevented || e.isComposing) return;
  if (state.gateOpen || isPaletteOpen() || isOverlayOpen() || isMenuOpen()) return;

  const mod = e.ctrlKey || e.metaKey;
  const key = e.key.length === 1 ? e.key.toLowerCase() : e.key;
  const inMonaco = !!e.target.closest?.(".monaco-editor");
  const typing = isTyping(e.target);
  const onExec = state.page === "execution";
  let handled = true;

  if (mod && !e.altKey && key === "k" && !inMonaco) openPalette();
  else if (mod && !e.altKey && key === "p") openPalette();
  else if (mod && key === "Enter") {
    if (e.shiftKey) inject();
    else { if (!onExec) goToPage("execution"); runScript(currentScript(), { button: $("#btn-execute") }); }
  }
  else if (mod && !e.shiftKey && !e.altKey && key >= "1" && key <= "4") goToPage(PAGE_IDS[+key - 1]);
  else if (mod && (key === "`" || key === "~")) toggleConsole();
  else if (mod && !e.shiftKey && key === "b") toggleSidebar();
  else if (mod && !e.shiftKey && key === "t") { if (!onExec) goToPage("execution"); newTab(); }
  else if (mod && !e.shiftKey && key === "w" && onExec) closeTab();
  else if (mod && key === "Tab" && onExec) cycleTab(e.shiftKey ? -1 : 1);
  else if (mod && !e.shiftKey && key === "o") { if (!onExec) goToPage("execution"); openFileDialog(); }
  else if (mod && !e.shiftKey && key === "s" && onExec) saveActive();
  else if (mod && !e.shiftKey && key === "l" && !inMonaco) clearConsole();
  else if (mod && !e.shiftKey && key === "f" && !inMonaco && state.page === "library") focusLibrarySearch();
  else if (mod && !e.shiftKey && key === "f" && !inMonaco && state.page === "console") focusConsoleSearch();
  else if (!mod && key === "F2" && onExec && !typing) renameActiveTab();
  else if (!mod && !e.altKey && e.key === "?" && !typing) openShortcuts();
  else if (!mod && !e.altKey && e.key === "/" && !typing && state.page === "library") focusLibrarySearch();
  else if (e.key === "F5" || (mod && key === "r")) {  }
  else handled = false;

  if (handled) {
    e.preventDefault();
    e.stopPropagation();
    hideTooltip();
  }
}

function setBootProgress(ratio) {
  const bar = $("#boot-progress-bar");
  if (bar) bar.style.width = `${Math.min(100, Math.max(0, Math.round(ratio * 100)))}%`;

  const steps = document.querySelectorAll(".boot-steps .step");
  const stepIdx = ratio < 0.25 ? 0 : ratio < 0.5 ? 1 : ratio < 0.8 ? 2 : 3;
  steps.forEach((s, j) => {
    s.classList.toggle("done", j < stepIdx || ratio >= 0.98);
    s.classList.toggle("active", j === stepIdx && ratio < 0.98);
  });
}

function hideBoot() {
  const b = $("#app-boot");
  if (!b || b.classList.contains("hide")) return;
  b.classList.add("hide");
  setTimeout(() => b.remove(), 250);
}

function revealApp() {
  html.classList.add("app-enter");
  html.classList.remove("cover-on");
  setTimeout(() => html.classList.remove("app-enter"), 300);
}

async function boot() {
  html.classList.add("cover-on");
  const bootMsg = $("#boot-msg");
  if (bootMsg) bootMsg.textContent = "Starting Byte";
  setBootProgress(0.15);

  // Fire every boot task in parallel — no scripted sleeps, no sequential
  // typewriter animations. The splash hides the instant the real work
  // resolves, with a small minimum visible time so it never flashes.
  const bootStart = performance.now();
  const MIN_BOOT_VISIBLE_MS = BOOT_MIN_MS;

  const [, auth] = await Promise.all([
    pollStatus().then(() => startPolling()),
    checkAuth(),
    loadSettings(),
  ]);

  setBootProgress(1.0);
  const elapsed = performance.now() - bootStart;
  if (elapsed < MIN_BOOT_VISIBLE_MS) await sleep(MIN_BOOT_VISIBLE_MS - elapsed);

  hideBoot();

  if (auth.offline) {
    showLicenseGate("Bridge offline. Make sure Byte is running.", "err", { retry: true });
  } else if (!auth.authed) {
    showLicenseGate();
  } else {
    renderAccount();
    revealApp();
  }

  if (state.settings.autoUpdate) checkUpdate(false);
  setInterval(() => { if (state.settings.autoUpdate) checkUpdate(false); }, UPDATE_INTERVAL_MS);

  // Re-poll /auth/state every 30s so an admin kill-switch flip and a key
  // expiring mid-session both propagate without a restart. checkAuth() is
  // cheap and the native side already debounces its own backend sync.
  setInterval(() => { checkAuth(); }, 30 * 1000);
  document.addEventListener("visibilitychange", () => { if (!document.hidden) checkAuth(); });

  // Non-blocking: compare installed Roblox hashes to the supported one and
  // nudge the user when they're outdated. Runs after reveal so it never
  // delays startup.
  checkRobloxVersion().catch(() => {});
}

/* -------------------------------------------- Roblox client version check */
// On boot, nudge the user when Roblox is on the wrong version. Three paths:
//   1. Supported client isn't installed → offer download (or auto-download if
//      "Force Roblox update" is on).
//   2. Supported is installed, but a running Roblox is on a different version
//      → warn and offer to close & relaunch the supported one.
//   3. Otherwise do nothing.
async function checkRobloxVersion() {
  const [v, s] = await Promise.all([bridgeGet("/versions"), bridgeGet("/status")]);
  if (!v?.ok || !v.supportedHash) return;
  const supported = v.supportedHash;

  const installedEntries = (v.versions || []).filter((e) => e.installed);
  const installed = installedEntries.map((e) => e.hash);
  const hasSupported = installed.includes(supported);
  const outdatedInstalled = installed.filter((h) => h !== supported);

  // Does the supported client have Byte's files in place? "needsSetup" is
  // true when the version folder is there but RobloxPlayerBeta.dll is still
  // stock-sized or Module.dll is missing — the native /versions endpoint
  // computes this for us.
  const supportedEntry = installedEntries.find((e) => e.hash === supported);
  const supportedNeedsSetup = !!supportedEntry?.needsSetup;

  const runningHashes = (s?.robloxHashes || []).filter(Boolean);
  const runningSupported = runningHashes.length > 0 && runningHashes.every((h) => h === supported);
  const runningOutdated  = runningHashes.length > 0 && !runningSupported;

  const openInstaller = async () => {
    const r = await bridgePost("/download-version", { hash: supported });
    if (r?.ok) {
      toast("Roblox installer opened in your browser.", "ok", 3000);
      log(`Downloading Roblox ${supported}`, "info");
    } else {
      toast(`Could not open installer: ${r?.error || "unknown"}`, "err", 3500);
    }
  };

  const closeRunningRoblox = async () => {
    const r = await bridgePost("/kill-roblox");
    if (!r?.ok) toast("Could not close Roblox.", "err");
    return !!r?.ok;
  };

  const launchSupported = async () => {
    const r = await bridgePost("/launch-roblox", { hash: supported });
    if (r?.ok) {
      toast("Launching supported Roblox…", "info", 2500);
      log(`Launched supported Roblox ${supported}`, "info");
    } else {
      toast(`Launch failed: ${r?.error || "unable to launch"}`, "err", 3500);
    }
    return !!r?.ok;
  };

  const runSetup = async () => {
    // If Roblox is running on *any* hash, close it first — the version
    // folder's RobloxPlayerBeta.dll is locked while it's loaded.
    if (runningHashes.length > 0) {
      await closeRunningRoblox();
    }
    const r = await startSetup(supported);
    if (r.ok) {
      log(`Roblox ${supported} is now set up for Byte.`, "ok");
    }
    return r;
  };

  // Case A: supported client is installed but missing Byte's files (stock
  // RobloxPlayerBeta.dll, or no Module.dll). Highest priority — this is the
  // "just installed Roblox, now set it up" path.
  if (hasSupported && supportedNeedsSetup) {
    log(`Roblox ${supported} is installed but needs Byte setup (patched DLL + Module.dll).`, "warn");
    if (state.settings.forceUpdate) {
      log(`Force Roblox update is on — running auto-setup immediately.`, "info");
      await runSetup();
      return;
    }
    const choice = await confirmDialog({
      title: "Finish Roblox setup for Byte?",
      message: `Byte is built for \`${supported}\` and the client is installed, but the Byte files aren't in place yet. I'll download the patched RobloxPlayerBeta.dll (~27 MB) and copy Byte's module into your Roblox install so Byte can attach.`,
      confirmLabel: "Set up now",
      cancelLabel: "Skip",
      iconName: "download",
    });
    if (choice === true) await runSetup();
    return;
  }

  // Force Update on: for the remaining outdated cases, skip every dialog
  // and immediately open the installer URL in the browser.
  if (state.settings.forceUpdate && (!hasSupported || runningOutdated || outdatedInstalled.length > 0)) {
    log(`Force Roblox update is on — opening installer for ${supported} immediately.`, "warn");
    toast("Downloading supported Roblox…", "info", 2500);
    openInstaller();
    return;
  }

  // Case 1: supported client not installed anywhere.
  if (!hasSupported) {
    log(`Supported Roblox is ${supported}; you don't have it installed.`, "warn");
    const choice = await confirmDialog({
      title: "Download the latest Roblox?",
      message: `Byte is built for \`${supported}\`. Your installed Roblox client is older — scripts won't run on it. Open Roblox's installer now?`,
      confirmLabel: "Download",
      cancelLabel: "Skip",
      iconName: "download",
    });
    if (choice === true) openInstaller();
    return;
  }

  // Case 2: supported installed, but a running Roblox process is a different version.
  if (runningOutdated) {
    const wrong = runningHashes.filter((h) => h !== supported).join(", ");
    log(`Roblox is running on ${wrong}; Byte needs ${supported}.`, "warn");
    const choice = await confirmDialog({
      title: "You're running the wrong Roblox",
      message: `Byte is built for \`${supported}\`, but Roblox is open on \`${wrong}\`. Scripts won't run until you launch the supported client. I can close your current Roblox and launch the right one for you — or download a fresh installer if you'd rather reinstall.`,
      confirmLabel: "Switch Roblox",
      altLabel: "Download fresh",
      cancelLabel: "Skip",
      iconName: "warn",
    });
    if (choice === true) {
      await closeRunningRoblox();
      await launchSupported();
    } else if (choice === "alt") {
      openInstaller();
    }
    return;
  }

  // Case 3: supported installed, Roblox not running, but one or more old
  // client versions are still on disk. Nudge the user to launch the right
  // one (or redownload fresh if they'd rather). Keeps the prompt visible
  // every boot while they're still carrying outdated clients around.
  if (outdatedInstalled.length > 0) {
    log(`Outdated Roblox client(s) still installed: ${outdatedInstalled.join(", ")}. Byte needs ${supported}.`, "warn");
    const choice = await confirmDialog({
      title: "Launch the supported Roblox?",
      message: `Byte is built for \`${supported}\` and you have it installed. You also still have outdated client${outdatedInstalled.length > 1 ? "s" : ""} on disk: \`${outdatedInstalled.join("`, `")}\`. Launch the supported one so Byte can attach, or download a fresh copy of it.`,
      confirmLabel: "Launch supported",
      altLabel: "Download fresh",
      cancelLabel: "Skip",
      iconName: "download",
    });
    if (choice === true) {
      await launchSupported();
    } else if (choice === "alt") {
      openInstaller();
    }
    return;
  }

  // Case 4: all good — only the supported client is installed and (if running) is the one running.
}

safe("fx", initFx);
safe("tooltips", initTooltips);
safe("ctxmenu", initCtxMenu);
safe("console", initConsole);
safe("editor", initEditor);
safe("nav", initNav);
safe("actions", initActions);
safe("library", initLibrary);
safe("versions", initVersions);
safe("menubar", initMenuBar);
safe("home", initHomeAndExplorer);
safe("account", initAccount);
safe("accounts-page", initAccounts);
safe("license", initLicense);
safe("settings", initSettings);
safe("update", initUpdate);
safe("palette", initPalette);
safe("window", initWindow);

$("#btn-execute")?.addEventListener("click", (e) => runScript(currentScript(), { button: e.currentTarget }));
$("#btn-inject")?.addEventListener("click", () => inject());
$("#btn-clipboard")?.addEventListener("click", pasteFromClipboard);
$("#btn-clear")?.addEventListener("click", clearEditor);
$("#btn-mini-expand")?.addEventListener("click", () => goToPage("console"));
$("#tb-launch")?.addEventListener("click", (e) => launchSupportedRoblox(e.currentTarget));
$("#ws-launch")?.addEventListener("click", (e) => launchSupportedRoblox(e.currentTarget));
$("#btn-clients")?.addEventListener("click", () => {
  const pids = state.robloxPids || state.pids || [];
  toast(pids.length ? `Connected to ${pids.length} client(s): PID ${pids.join(", ")}` : "No Roblox client detected.", pids.length ? "ok" : "info");
});
$("#tb-console")?.addEventListener("click", () => toggleBottomConsole());
$("#sb-shortcuts")?.addEventListener("click", openShortcuts);
window.addEventListener("keydown", onKey, true);

on("app-reveal", revealApp);

window.addEventListener("error", (e) => log(`UI error: ${e.message}`, "err"));
window.addEventListener("unhandledrejection", (e) => log(`UI error: ${e.reason?.message || e.reason}`, "err"));

boot().catch((e) => {
  console.error("[byte] boot failed", e);
  hideBoot();
  showLicenseGate("Something went wrong while starting. Restart Byte.", "err");
});
