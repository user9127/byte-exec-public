import { $, sleep, isTyping } from "./js/dom.js";
import { state } from "./js/state.js";
import { bridgeProbe, bridgeWindow } from "./js/bridge.js";
import { on } from "./js/bus.js";
import { initFx, setWindowActive } from "./js/fx.js";
import { initTooltips, hideTooltip } from "./js/tooltip.js";
import { toast } from "./js/toast.js";
import { isOverlayOpen } from "./js/dialog.js";
import { isMenuOpen } from "./js/menu.js";
import { initConsole, clearConsole, focusConsoleSearch, log } from "./js/console.js";
import { initEditor, newTab, closeTab, cycleTab, openFileDialog, saveActive, currentScript, renameActiveTab, flushPersist, pasteFromClipboard, clearEditor } from "./js/editor.js";
import { initLibrary, focusLibrarySearch } from "./js/library.js";
import { initNav, goToPage, toggleSidebar, toggleConsole, PAGE_IDS } from "./js/nav.js";
import { initActions, runScript, inject, launchSupportedRoblox } from "./js/actions.js";
import { initLicense, checkAuth, showLicenseGate } from "./js/license.js";
import { initAccount, renderAccount } from "./js/account.js";
import { initVersions } from "./js/versions.js";
import { initMenuBar, toggleBottomConsole } from "./js/menubar.js";
import { initHomeAndExplorer } from "./js/home.js";
import { initSettings, loadSettings, applyLocalPrefs } from "./js/settings.js";
import { initUpdate, checkUpdate } from "./js/update.js";
import { initPalette, openPalette, isPaletteOpen } from "./js/palette.js";
import { openShortcuts } from "./js/shortcuts.js";
import { pollStatus, startPolling } from "./js/status.js";
import { store } from "./js/store.js";
import { animateDecryptedText } from "./js/decrypted.js";
import { initCtxMenu } from "./js/ctxmenu.js";

const html = document.documentElement;
const BOOT_MIN_MS = 450;
const UPDATE_INTERVAL_MS = 30 * 60 * 1000;

applyLocalPrefs();

function safe(name, fn) {
  try { fn(); } catch (e) { console.error(`[byte] ${name} failed to init`, e); }
}

function applyWindowState(s) {
  if (!s || typeof s !== "object") return;
  if ("maximized" in s) {
    html.classList.toggle("is-max", !!s.maximized);
    const b = $("#win-max");
    const label = s.maximized ? "Restore" : "Maximize";
    b.setAttribute("aria-label", label);
  }
  if ("active" in s) setWindowActive(!!s.active);
}

function initWindow() {
  $("#win-min").addEventListener("click", () => bridgeWindow("min"));
  $("#win-max").addEventListener("click", () => bridgeWindow("max"));
  $("#win-close").addEventListener("click", () => { flushPersist(); bridgeWindow("close"); });

  window.chrome?.webview?.addEventListener?.("message", (e) => {
    if (e.data && e.data.type === "window") applyWindowState(e.data);
  });
  bridgeProbe("/window/state").then(applyWindowState);
}

function onKey(e) {
  if (e.defaultPrevented || e.isComposing) return;
  if (state.gateOpen || isPaletteOpen() || isOverlayOpen() || isMenuOpen()) return;

  const mod = e.ctrlKey || e.metaKey;
  const key = e.key.length === 1 ? e.key.toLowerCase() : e.key;
  const inMonaco = !!e.target.closest?.(".monaco-editor");
  const typing = isTyping(e.target);
  const onExec = state.page === "execution";
  let handled = true;

  if (mod && !e.altKey && key === "k" && !inMonaco) openPalette();
  else if (mod && !e.altKey && key === "p") openPalette();
  else if (mod && key === "Enter") {
    if (e.shiftKey) inject();
    else { if (!onExec) goToPage("execution"); runScript(currentScript(), { button: $("#btn-execute") }); }
  }
  else if (mod && !e.shiftKey && !e.altKey && key >= "1" && key <= "4") goToPage(PAGE_IDS[+key - 1]);
  else if (mod && (key === "`" || key === "~")) toggleConsole();
  else if (mod && !e.shiftKey && key === "b") toggleSidebar();
  else if (mod && !e.shiftKey && key === "t") { if (!onExec) goToPage("execution"); newTab(); }
  else if (mod && !e.shiftKey && key === "w" && onExec) closeTab();
  else if (mod && key === "Tab" && onExec) cycleTab(e.shiftKey ? -1 : 1);
  else if (mod && !e.shiftKey && key === "o") { if (!onExec) goToPage("execution"); openFileDialog(); }
  else if (mod && !e.shiftKey && key === "s" && onExec) saveActive();
  else if (mod && !e.shiftKey && key === "l" && !inMonaco) clearConsole();
  else if (mod && !e.shiftKey && key === "f" && !inMonaco && state.page === "library") focusLibrarySearch();
  else if (mod && !e.shiftKey && key === "f" && !inMonaco && state.page === "console") focusConsoleSearch();
  else if (!mod && key === "F2" && onExec && !typing) renameActiveTab();
  else if (!mod && !e.altKey && e.key === "?" && !typing) openShortcuts();
  else if (!mod && !e.altKey && e.key === "/" && !typing && state.page === "library") focusLibrarySearch();
  else if (e.key === "F5" || (mod && key === "r")) {  }
  else handled = false;

  if (handled) {
    e.preventDefault();
    e.stopPropagation();
    hideTooltip();
  }
}

function setBootProgress(ratio) {
  const bar = $("#boot-progress-bar");
  if (bar) bar.style.width = `${Math.min(100, Math.max(0, Math.round(ratio * 100)))}%`;

  const steps = document.querySelectorAll(".boot-steps .step");
  const stepIdx = ratio < 0.25 ? 0 : ratio < 0.5 ? 1 : ratio < 0.8 ? 2 : 3;
  steps.forEach((s, j) => {
    s.classList.toggle("done", j < stepIdx || ratio >= 0.98);
    s.classList.toggle("active", j === stepIdx && ratio < 0.98);
  });
}

function hideBoot() {
  const b = $("#app-boot");
  if (!b || b.classList.contains("hide")) return;
  b.classList.add("hide");
  setTimeout(() => b.remove(), 250);
}

function revealApp() {
  html.classList.add("app-enter");
  html.classList.remove("cover-on");
  setTimeout(() => html.classList.remove("app-enter"), 300);
}

async function boot() {
  html.classList.add("cover-on");
  const bootMsg = $("#boot-msg");

  setBootProgress(0.04);

  await animateDecryptedText({
    element: bootMsg,
    text: "Checking Roblox",
    speed: 110,
    sequential: true,
    onProgress: (p) => setBootProgress(0.04 + p * 0.21)
  });

  await pollStatus();
  startPolling();
  await sleep(400);

  await animateDecryptedText({
    element: bootMsg,
    text: "Core Files Ready",
    speed: 95,
    sequential: true,
    onProgress: (p) => setBootProgress(0.40 + p * 0.35)
  });
  await sleep(300);

  await animateDecryptedText({
    element: bootMsg,
    text: "Enjoy Byte",
    speed: 75,
    sequential: true,
    onProgress: (p) => setBootProgress(0.80 + p * 0.20)
  });

  setBootProgress(1.0);
  await sleep(600);

  const auth = await checkAuth();
  await loadSettings();

  hideBoot();

  if (auth.offline) {
    showLicenseGate("Bridge offline. Make sure Byte is running.", "err", { retry: true });
  } else if (!auth.authed) {
    showLicenseGate();
  } else {
    renderAccount();
    revealApp();
  }

  if (state.settings.autoUpdate) checkUpdate(false);
  setInterval(() => { if (state.settings.autoUpdate) checkUpdate(false); }, UPDATE_INTERVAL_MS);
}

safe("fx", initFx);
safe("tooltips", initTooltips);
safe("ctxmenu", initCtxMenu);
safe("console", initConsole);
safe("editor", initEditor);
safe("nav", initNav);
safe("actions", initActions);
safe("library", initLibrary);
safe("versions", initVersions);
safe("menubar", initMenuBar);
safe("home", initHomeAndExplorer);
safe("account", initAccount);
safe("license", initLicense);
safe("settings", initSettings);
safe("update", initUpdate);
safe("palette", initPalette);
safe("window", initWindow);

$("#btn-execute")?.addEventListener("click", (e) => runScript(currentScript(), { button: e.currentTarget }));
$("#btn-inject")?.addEventListener("click", () => inject());
$("#btn-clipboard")?.addEventListener("click", pasteFromClipboard);
$("#btn-clear")?.addEventListener("click", clearEditor);
$("#btn-mini-expand")?.addEventListener("click", () => goToPage("console"));
$("#tb-launch")?.addEventListener("click", (e) => launchSupportedRoblox(e.currentTarget));
$("#ws-launch")?.addEventListener("click", (e) => launchSupportedRoblox(e.currentTarget));
$("#btn-clients")?.addEventListener("click", () => {
  const pids = state.robloxPids || state.pids || [];
  toast(pids.length ? `Connected to ${pids.length} client(s): PID ${pids.join(", ")}` : "No Roblox client detected.", pids.length ? "ok" : "info");
});
$("#tb-console")?.addEventListener("click", () => toggleBottomConsole());
$("#sb-shortcuts")?.addEventListener("click", openShortcuts);
window.addEventListener("keydown", onKey, true);

on("app-reveal", revealApp);

window.addEventListener("error", (e) => log(`UI error: ${e.message}`, "err"));
window.addEventListener("unhandledrejection", (e) => log(`UI error: ${e.reason?.message || e.reason}`, "err"));

boot().catch((e) => {
  console.error("[byte] boot failed", e);
  hideBoot();
  showLicenseGate("Something went wrong while starting. Restart Byte.", "err");
});
