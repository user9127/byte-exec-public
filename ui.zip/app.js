/* =============================================================================
   Byte launcher UI entry point.
   Wires the feature modules in ./js together, runs the boot sequence, syncs
   native window state, and owns the global keyboard shortcuts.
   Bridge contract: ByteUI.cpp / ByteUIExtras.cpp on 127.0.0.1:8734.
   ========================================================================== */

import { $, sleep, isTyping } from "./js/dom.js";
import { state } from "./js/state.js";
import { bridgeProbe, bridgeWindow } from "./js/bridge.js";
import { on } from "./js/bus.js";
import { initFx, setWindowActive } from "./js/fx.js";
import { initTooltips, hideTooltip } from "./js/tooltip.js";
import { isOverlayOpen } from "./js/dialog.js";
import { isMenuOpen } from "./js/menu.js";
import { initConsole, clearConsole, focusConsoleSearch, log } from "./js/console.js";
import { initEditor, newTab, closeTab, cycleTab, openFileDialog, saveActive, currentScript, renameActiveTab, flushPersist, pasteFromClipboard, clearEditor } from "./js/editor.js";
import { initLibrary, focusLibrarySearch } from "./js/library.js";
import { initNav, goToPage, toggleSidebar, PAGE_IDS } from "./js/nav.js";
import { initActions, runScript, inject } from "./js/actions.js";
import { initLicense, checkAuth, showLicenseGate } from "./js/license.js";
import { initAccount, renderAccount } from "./js/account.js";
import { initSettings, loadSettings, applyLocalPrefs } from "./js/settings.js";
import { initUpdate, checkUpdate } from "./js/update.js";
import { initPalette, openPalette, isPaletteOpen } from "./js/palette.js";
import { openShortcuts } from "./js/shortcuts.js";
import { pollStatus, startPolling } from "./js/status.js";
import { startServiceStatus } from "./js/service.js";

const html = document.documentElement;
const BOOT_MIN_MS = 450;
const UPDATE_INTERVAL_MS = 30 * 60 * 1000;

applyLocalPrefs();

/* one failing module must not take the whole launcher down */
function safe(name, fn) {
  try { fn(); } catch (e) { console.error(`[byte] ${name} failed to init`, e); }
}

/* ------------------------------------------------------------ window state */
function applyWindowState(s) {
  if (!s || typeof s !== "object") return;
  if ("maximized" in s) {
    html.classList.toggle("is-max", !!s.maximized);
    const b = $("#win-max");
    const label = s.maximized ? "Restore" : "Maximize";
    b.setAttribute("aria-label", label);
    b.dataset.tip = label;
  }
  if ("active" in s) setWindowActive(!!s.active);
}

function initWindow() {
  $("#win-min").addEventListener("click", () => bridgeWindow("min"));
  $("#win-max").addEventListener("click", () => bridgeWindow("max"));
  $("#win-close").addEventListener("click", () => { flushPersist(); bridgeWindow("close"); });
  // the host pushes {type:"window", maximized, active} on WM_SIZE / WM_ACTIVATE
  window.chrome?.webview?.addEventListener?.("message", (e) => {
    if (e.data && e.data.type === "window") applyWindowState(e.data);
  });
  bridgeProbe("/window/state").then(applyWindowState);
}

/* ------------------------------------------------------- keyboard shortcuts */
function onKey(e) {
  if (e.defaultPrevented || e.isComposing) return;
  if (state.gateOpen || isPaletteOpen() || isOverlayOpen() || isMenuOpen()) return;

  const mod = e.ctrlKey || e.metaKey;
  const key = e.key.length === 1 ? e.key.toLowerCase() : e.key;
  const inMonaco = !!e.target.closest?.(".monaco-editor");
  const typing = isTyping(e.target);
  const onExec = state.page === "execution";
  let handled = true;

  if (mod && !e.altKey && key === "k" && !inMonaco) openPalette();
  else if (mod && !e.altKey && key === "p") openPalette();
  else if (mod && key === "Enter") {
    if (e.shiftKey) inject();
    else { if (!onExec) goToPage("execution"); runScript(currentScript(), { button: $("#btn-execute") }); }
  }
  else if (mod && !e.shiftKey && !e.altKey && key >= "1" && key <= "5") goToPage(PAGE_IDS[+key - 1]);
  else if (mod && !e.shiftKey && key === "b") toggleSidebar();
  else if (mod && !e.shiftKey && key === "t") { if (!onExec) goToPage("execution"); newTab(); }
  else if (mod && !e.shiftKey && key === "w" && onExec) closeTab();
  else if (mod && key === "Tab" && onExec) cycleTab(e.shiftKey ? -1 : 1);
  else if (mod && !e.shiftKey && key === "o") { if (!onExec) goToPage("execution"); openFileDialog(); }
  else if (mod && !e.shiftKey && key === "s" && onExec) saveActive();
  else if (mod && !e.shiftKey && key === "l" && !inMonaco) clearConsole();
  else if (mod && !e.shiftKey && key === "f" && !inMonaco && state.page === "library") focusLibrarySearch();
  else if (mod && !e.shiftKey && key === "f" && !inMonaco && state.page === "console") focusConsoleSearch();
  else if (!mod && key === "F2" && onExec && !typing) renameActiveTab();
  else if (!mod && !e.altKey && e.key === "?" && !typing) openShortcuts();
  else if (!mod && !e.altKey && e.key === "/" && !typing && state.page === "library") focusLibrarySearch();
  else if (e.key === "F5" || (mod && key === "r")) { /* swallow reload: it would drop editor state mid-session */ }
  else handled = false;

  if (handled) {
    e.preventDefault();
    e.stopPropagation();
    hideTooltip();
  }
}

/* --------------------------------------------------------------- boot flow */
function setBootStep(i, msg) {
  document.querySelectorAll(".boot-steps .step").forEach((s, j) => {
    s.classList.toggle("done", j < i);
    s.classList.toggle("active", j === i);
  });
  const m = $("#boot-msg");
  if (m && msg) m.textContent = msg;
}

function hideBoot() {
  const b = $("#app-boot");
  if (!b || b.classList.contains("hide")) return;
  b.classList.add("hide");
  setTimeout(() => b.remove(), 200);
}

function revealApp() {
  html.classList.add("app-enter");
  html.classList.remove("cover-on");
  setTimeout(() => html.classList.remove("app-enter"), 300);
}

async function boot() {
  const t0 = performance.now();
  html.classList.add("cover-on");

  setBootStep(0, "Checking license");
  const auth = await checkAuth();

  setBootStep(1, "Loading settings");
  await loadSettings();

  setBootStep(2, "Looking for Roblox");
  await pollStatus();
  startPolling();

  setBootStep(3, "Ready");
  const wait = BOOT_MIN_MS - (performance.now() - t0);
  if (wait > 0) await sleep(wait);
  document.querySelectorAll(".boot-steps .step").forEach((s) => { s.classList.add("done"); s.classList.remove("active"); });
  await sleep(80);
  hideBoot();

  if (auth.offline) showLicenseGate("Bridge offline. Make sure Byte.exe is running.", "err", { retry: true });
  else if (!auth.authed) showLicenseGate("Waiting for input.");
  else { renderAccount(); revealApp(); }

  // update check talks to GitHub; never block the reveal on it
  if (state.settings.autoUpdate) checkUpdate(false);
  setInterval(() => { if (state.settings.autoUpdate) checkUpdate(false); }, UPDATE_INTERVAL_MS);

  // service health is independent of the auto-update setting
  startServiceStatus();
}

/* ------------------------------------------------------------------ start */
safe("fx", initFx);
safe("tooltips", initTooltips);
safe("console", initConsole);
safe("editor", initEditor);
safe("nav", initNav);
safe("actions", initActions);
safe("library", initLibrary);
safe("account", initAccount);
safe("license", initLicense);
safe("settings", initSettings);
safe("update", initUpdate);
safe("palette", initPalette);
safe("window", initWindow);

$("#btn-execute").addEventListener("click", (e) => runScript(currentScript(), { button: e.currentTarget }));
$("#btn-inject").addEventListener("click", () => inject());
$("#btn-clipboard").addEventListener("click", pasteFromClipboard);
$("#btn-clear").addEventListener("click", clearEditor);
$("#btn-mini-expand").addEventListener("click", () => goToPage("console"));
$("#sb-shortcuts").addEventListener("click", openShortcuts);
window.addEventListener("keydown", onKey, true);

on("app-reveal", revealApp);

window.addEventListener("error", (e) => log(`UI error: ${e.message}`, "err"));
window.addEventListener("unhandledrejection", (e) => log(`UI error: ${e.reason?.message || e.reason}`, "err"));

boot().catch((e) => {
  console.error("[byte] boot failed", e);
  hideBoot();
  showLicenseGate("Something went wrong while starting. Restart Byte.", "err");
});
