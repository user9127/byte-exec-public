import { $, sleep } from "./dom.js";
import { state, DISCORD_INVITE } from "./state.js";
import { bridgeGet, bridgePost } from "./bridge.js";
import { syncInert } from "./dialog.js";
import { shake } from "./fx.js";
import { applyAuthState, renderAccount } from "./account.js";
import { toast } from "./toast.js";
import { emit, on } from "./bus.js";

const html = document.documentElement;

export async function checkAuth() {
  const s = await bridgeGet("/auth/state");
  if (!s) {
    state.bridgeReachable = false;
    return { ok: false, offline: true, authed: false };
  }
  state.bridgeReachable = true;
  applyAuthState(s);
  emit("auth");
  return { ok: true, offline: false, authed: state.authed };
}

function setStatus(text, kind = "") {
  const el = $("#license-status");
  if (!el) return;
  if (!text) {
    el.hidden = true;
    el.style.display = "none";
    const txt = el.querySelector(".sl-text");
    if (txt) txt.textContent = "";
    return;
  }
  el.style.display = "";
  el.className = `signin-status ${kind}`;
  const txt = el.querySelector(".sl-text");
  if (txt) txt.textContent = text;
  el.hidden = false;
}

export function isGateOpen() { return state.gateOpen; }

export function showLicenseGate(msg, kind = "") {
  const gate = $("#license-gate");
  if (!gate) return;
  if (!state.gateOpen) {
    state.gateOpen = true;
    syncInert();
    html.classList.add("cover-on");
    gate.classList.remove("leaving", "show");
    gate.hidden = false;
    void gate.offsetWidth;
    gate.classList.add("show");
    const btn = $("#license-submit");
    if (btn) {
      btn.disabled = false;
      btn.classList.remove("loading");
    }
  }
  setStatus(msg || "", kind);
  setTimeout(() => {
    const user = $("#login-username");
    const pwd = $("#login-password");
    if (user && !user.value) user.focus({ preventScroll: true });
    else if (pwd) pwd.focus({ preventScroll: true });
  }, 160);
}

function hideLicenseGate() {
  return new Promise((resolve) => {
    const gate = $("#license-gate");
    if (!state.gateOpen) { resolve(); return; }
    state.gateOpen = false;
    gate.classList.add("leaving");
    setTimeout(() => {
      gate.hidden = true;
      gate.classList.remove("show", "leaving");
      html.classList.remove("cover-on");
      syncInert();
      resolve();
    }, 130);
  });
}

async function unlock() {
  renderAccount();
  await hideLicenseGate();
  emit("app-reveal");
}

async function submitLogin() {
  const usernameInput = $("#login-username");
  const pwdInput = $("#login-password");
  const btn = $("#license-submit");
  if (!btn || btn.classList.contains("loading")) return;

  const username = (usernameInput?.value || "").trim() || usernameInput?.placeholder || "RainYuu";
  const password = pwdInput?.value || "";

  btn.classList.add("loading");
  btn.disabled = true;
  setStatus("Signing in…", "working");

  const r = await bridgePost("/auth/login", { username, password }, { timeout: 15000 });
  btn.classList.remove("loading");
  btn.disabled = false;

  if (r?.ok) {
    setStatus("Welcome back! Loading workspace…", "ok");
    await sleep(250);
    const a = await checkAuth();
    if (a.authed) {
      await unlock();
      return;
    }
  }

  setStatus(r?.error || "Sign in failed. Check your credentials.", "err");
  shake($("#password-wrap"));
  pwdInput?.focus();
}

function bindInputs() {
  const user = $("#login-username");
  const pwd = $("#login-password");
  const eyeBtn = $("#btn-toggle-pwd");

  if (user && pwd) {
    user.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        pwd.focus();
      }
    });
    pwd.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        submitLogin();
      }
    });
  }

  if (eyeBtn && pwd) {
    eyeBtn.addEventListener("click", () => {
      const isPwd = pwd.type === "password";
      pwd.type = isPwd ? "text" : "password";
      const open = eyeBtn.querySelector(".eye-open");
      const closed = eyeBtn.querySelector(".eye-closed");
      if (open) open.hidden = isPwd;
      if (closed) closed.hidden = !isPwd;
      pwd.focus();
    });
  }
}

export function initLicense() {
  bindInputs();

  $("#license-submit")?.addEventListener("click", submitLogin);

  $("#btn-create-account")?.addEventListener("click", async () => {
    const r = await bridgePost("/open-url", { url: DISCORD_INVITE });
    if (!r?.ok) toast("Registration opens in browser.", "ok");
  });

  $("#btn-login-help")?.addEventListener("click", async () => {
    const r = await bridgePost("/open-url", { url: DISCORD_INVITE });
    if (!r?.ok) toast("Visit discord.gg/wbyte for assistance.", "ok");
  });

  on("signed-out", () => {
    const pwd = $("#login-password");
    if (pwd) pwd.value = "";
    showLicenseGate("Signed out.");
  });
}
