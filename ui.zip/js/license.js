import { $, $$, sleep } from "./dom.js";
import { state, DISCORD_INVITE } from "./state.js";
import { bridgeGet, bridgePost } from "./bridge.js";
import { syncInert } from "./dialog.js";
import { shake } from "./fx.js";
import { applyAuthState, renderAccount } from "./account.js";
import { toast } from "./toast.js";
import { emit, on } from "./bus.js";

const html = document.documentElement;
const HELP_URL = "https://discord.gg/invite/xbyte";
const WORKINK_TIMEOUT_MS = 10 * 60 * 1000;

// Shared state for the multi-step register flow. We hold the license key the
// user already proved they own, carry it into the account step, and store the
// account token the server returns so the discord step can bind to the right
// account.
const regState = { licenseKey: "", accountToken: "", username: "" };

// Per-panel work.ink pollers so a user starting the free-key flow on the
// signin panel and then switching to the register panel doesn't collide with
// themselves. Each entry: { poll, clock, start }.
const workinkRunners = Object.create(null);

export async function checkAuth() {
  const s = await bridgeGet("/auth/state");
  if (!s) {
    state.bridgeReachable = false;
    return { ok: false, offline: true, authed: false };
  }
  state.bridgeReachable = true;
  applyAuthState(s);
  emit("auth");
  return { ok: true, offline: false, authed: state.authed };
}

// --- Panel switching ---------------------------------------------------------

function switchPanel(name) {
  $$(".gate-panel").forEach((p) => {
    const active = p.dataset.panel === name;
    p.hidden = !active;
    p.classList.toggle("active", active);
  });
  // Focus the first visible input in the new panel.
  setTimeout(() => {
    const panel = document.querySelector(`.gate-panel[data-panel="${name}"]`);
    const input = panel?.querySelector("input:not([disabled])");
    input?.focus({ preventScroll: true });
  }, 60);
}

// --- Status indicator (per panel) --------------------------------------------

function setStatus(panelName, text, kind = "") {
  // One shared status area per panel keeps the markup simple; look it up by
  // its panel.
  const panel = panelName
    ? document.querySelector(`.gate-panel[data-panel="${panelName}"]`)
    : document.querySelector(".gate-panel:not([hidden])");
  const el = panel?.querySelector(".signin-status");
  if (!el) return;
  if (!text) {
    el.hidden = true;
    el.style.display = "none";
    const txt = el.querySelector(".sl-text");
    if (txt) txt.textContent = "";
    return;
  }
  el.style.display = "";
  el.className = `signin-status ${kind}`;
  const txt = el.querySelector(".sl-text");
  if (txt) txt.textContent = text;
  el.hidden = false;
}

export function isGateOpen() { return state.gateOpen; }

export function showLicenseGate(msg, kind = "") {
  const gate = $("#license-gate");
  if (!gate) return;
  switchPanel("signin");
  if (!state.gateOpen) {
    state.gateOpen = true;
    syncInert();
    html.classList.add("cover-on");
    gate.classList.remove("leaving", "show");
    gate.hidden = false;
    void gate.offsetWidth;
    gate.classList.add("show");
    const btn = $("#license-submit");
    if (btn) {
      btn.disabled = false;
      btn.classList.remove("loading");
    }
  }
  setStatus("signin", msg || "", kind);
  setTimeout(() => {
    const user = $("#login-username");
    const pwd = $("#login-password");
    if (user && !user.value) user.focus({ preventScroll: true });
    else if (pwd) pwd.focus({ preventScroll: true });
  }, 160);
}

function hideLicenseGate() {
  return new Promise((resolve) => {
    const gate = $("#license-gate");
    if (!state.gateOpen) { resolve(); return; }
    state.gateOpen = false;
    gate.classList.add("leaving");
    setTimeout(() => {
      gate.hidden = true;
      gate.classList.remove("show", "leaving");
      html.classList.remove("cover-on");
      syncInert();
      resolve();
    }, 130);
  });
}

async function unlock() {
  renderAccount();
  await hideLicenseGate();
  emit("app-reveal");
}

// --- Sign in (existing account) ---------------------------------------------

async function submitLogin() {
  const usernameInput = $("#login-username");
  const pwdInput = $("#login-password");
  const btn = $("#license-submit");
  if (!btn || btn.classList.contains("loading")) return;

  const username = (usernameInput?.value || "").trim();
  const password = pwdInput?.value || "";
  if (!username || !password) {
    setStatus("signin", "Enter a username and password.", "err");
    shake($(username ? "#password-wrap" : "#username-wrap"));
    return;
  }

  btn.classList.add("loading");
  btn.disabled = true;
  setStatus("signin", "Signing in…", "working");

  const r = await bridgePost("/auth/login", { username, password }, { timeout: 15000 });
  btn.classList.remove("loading");
  btn.disabled = false;

  if (r?.ok) {
    setStatus("signin", "Welcome back! Loading workspace…", "ok");
    await sleep(250);
    const a = await checkAuth();
    if (a.authed) {
      await unlock();
      return;
    }
  }

  setStatus("signin", r?.error || "Sign in failed. Check your credentials.", "err");
  shake($("#password-wrap"));
  pwdInput?.focus();
}

// --- Sign in with Discord (opens OAuth, polls for session) ------------------

async function signInWithDiscord() {
  const btn = $("#btn-signin-discord");
  if (btn?.classList.contains("loading")) return;
  btn?.classList.add("loading");
  setStatus("signin", "Opening Discord…", "working");

  const r = await bridgePost("/auth/discord-signin", {});
  if (!r?.ok) {
    btn?.classList.remove("loading");
    setStatus("signin", r?.error || "Could not open Discord sign-in.", "err");
    return;
  }
  setStatus("signin", "Waiting for Discord authorization…", "working");

  // Poll /auth/state until the host confirms a Discord sign-in landed or we
  // time out. The server's callback writes the account state; we just wait.
  const started = Date.now();
  while (Date.now() - started < 180000) {
    await sleep(1500);
    const a = await checkAuth();
    if (a.authed) {
      btn?.classList.remove("loading");
      setStatus("signin", "Signed in!", "ok");
      await sleep(200);
      await unlock();
      return;
    }
    const err = state.discordSignInError;
    if (err) {
      state.discordSignInError = "";
      btn?.classList.remove("loading");
      setStatus("signin", err, "err");
      return;
    }
  }
  btn?.classList.remove("loading");
  setStatus("signin", "Discord sign-in timed out. Try again.", "err");
}

// --- Register: step 1 — validate license ------------------------------------

async function submitRegisterLicense() {
  const input = $("#register-license-input");
  const btn = $("#register-license-next");
  if (!btn || btn.classList.contains("loading")) return;

  const key = (input?.value || "").trim();
  if (!key) {
    setStatus("register-license", "Enter your license key.", "err");
    shake($("#register-license-wrap"));
    return;
  }

  btn.classList.add("loading");
  btn.disabled = true;
  setStatus("register-license", "Checking key…", "working");

  // Reuses the same endpoint SubmitLicense uses from the regular gate; a
  // key the server marks active is good enough to register against.
  const r = await bridgePost("/auth/register-check-key", { key }, { timeout: 15000 });
  btn.classList.remove("loading");
  btn.disabled = false;

  if (!r?.ok) {
    setStatus("register-license", r?.error || "That key isn't valid or is already bound. Try another.", "err");
    shake($("#register-license-wrap"));
    return;
  }

  regState.licenseKey = key;
  setStatus("register-license", "", "");
  switchPanel("register-account");
  setStatus("register-account", "Pick a username and password for your Byte account.", "");
}

// --- Register: step 2 — create account ---------------------------------------

async function submitRegisterAccount() {
  const btn = $("#register-account-next");
  if (!btn || btn.classList.contains("loading")) return;

  const username = ($("#register-username")?.value || "").trim();
  const password = $("#register-password")?.value || "";
  const confirm  = $("#register-confirm")?.value || "";
  if (!username || username.length < 3) {
    setStatus("register-account", "Username must be at least 3 characters.", "err");
    shake($("#register-username-wrap"));
    return;
  }
  if (!password || password.length < 8) {
    setStatus("register-account", "Password must be at least 8 characters.", "err");
    shake($("#register-password-wrap"));
    return;
  }
  if (password !== confirm) {
    setStatus("register-account", "Passwords don't match.", "err");
    shake($("#register-confirm-wrap"));
    return;
  }

  btn.classList.add("loading");
  btn.disabled = true;
  setStatus("register-account", "Creating account…", "working");

  const r = await bridgePost("/auth/register", {
    username,
    password,
    license_key: regState.licenseKey,
  }, { timeout: 20000 });

  btn.classList.remove("loading");
  btn.disabled = false;

  if (!r?.ok) {
    setStatus("register-account", r?.error || "Could not create account. Try again.", "err");
    return;
  }

  regState.username = username;
  switchPanel("register-discord");
  setStatus("register-discord", "Last step — link your Discord so you can sign in with it later.", "");
}

// --- Register: step 3 — connect Discord --------------------------------------

async function connectRegisterDiscord() {
  const btn = $("#register-discord-connect");
  if (!btn || btn.classList.contains("loading")) return;

  btn.classList.add("loading");
  setStatus("register-discord", "Opening Discord…", "working");
  const r = await bridgePost("/discord/link", {});
  if (!r?.ok) {
    btn.classList.remove("loading");
    setStatus("register-discord", "Could not open Discord. Try again or skip.", "err");
    return;
  }
  setStatus("register-discord", "Finish the Discord link in your browser…", "working");

  // Poll /auth/state until a discord_id lands or the user bails via Skip.
  const started = Date.now();
  while (Date.now() - started < 180000) {
    await sleep(1500);
    const s = await bridgeGet("/auth/state");
    if (s?.discord?.id) {
      btn.classList.remove("loading");
      setStatus("register-discord", "Discord linked!", "ok");
      await sleep(250);
      await unlock();
      return;
    }
  }
  btn.classList.remove("loading");
  setStatus("register-discord", "Discord link timed out. You can link it later from Account.", "err");
}

async function skipDiscord() {
  await unlock();
}

// --- Work.ink free 24h key (shared by signin + register-license panels) ------
// Native endpoints (see ByteUIExtras.cpp): /workink/start opens the browser,
// /workink/state returns {phase, error?}. Phases: 0 idle, 1 waiting, 2 verifying,
// 3 ok, 4 failed. On phase 3, the native side has already redeemed the key via
// the license worker, so /auth/state picks it up.
function fmtDuration(ms) {
  const t = Math.max(0, Math.floor(ms / 1000));
  const m = Math.floor(t / 60);
  const s = t % 60;
  return `${m}:${s.toString().padStart(2, "0")}`;
}

function stopWorkink(key) {
  const r = workinkRunners[key];
  if (!r) return;
  clearInterval(r.poll);
  clearInterval(r.clock);
  delete workinkRunners[key];
}

function workinkUi(key) {
  // key: "signin" | "register-license"
  return {
    btn:      $(key === "signin" ? "#btn-signin-getkey" : "#btn-register-getkey"),
    progress: $(key === "signin" ? "#signin-workink-progress" : "#register-workink-progress"),
    elapsed:  $(key === "signin" ? "#signin-workink-elapsed" : "#register-workink-elapsed"),
    cancel:   $(key === "signin" ? "#signin-workink-cancel" : "#register-workink-cancel"),
    panel:    key,
  };
}

function resetWorkink(key, msg, kind) {
  stopWorkink(key);
  const u = workinkUi(key);
  if (u.btn) { u.btn.disabled = false; u.btn.classList.remove("loading"); }
  if (u.progress) u.progress.hidden = true;
  if (msg) setStatus(u.panel, msg, kind);
  else setStatus(u.panel, "", "");
}

async function onWorkinkSuccess(key) {
  const u = workinkUi(key);
  stopWorkink(key);
  if (u.progress) u.progress.hidden = true;
  if (u.btn) { u.btn.disabled = false; u.btn.classList.remove("loading"); }
  // Pull the fresh key off the host — the native work.ink callback already
  // persisted it. For the register panel we drop it into the input so the
  // user can continue the register flow with no retype.
  const auth = await checkAuth();
  if (key === "register-license") {
    const input = $("#register-license-input");
    if (input && state.licenseKey) {
      input.value = state.licenseKey;
      regState.licenseKey = state.licenseKey;
    }
    setStatus("register-license", "Key activated. Continue to create your account.", "ok");
    return;
  }
  // Signin panel: if the host already has a signed-in account linked to this
  // PC's new key (byte-license's HWID binding does this), unlock straight into
  // the app. Otherwise the key is bound to this PC but no account signed in,
  // so leave the user on the signin form with a hint.
  if (auth?.authed) {
    setStatus("signin", "Key activated. Loading workspace…", "ok");
    await sleep(250);
    await unlock();
    return;
  }
  setStatus("signin",
    "Free 24-hour key activated for this PC. Sign in to your account, or create one.",
    "ok");
}

async function startWorkink(key) {
  const u = workinkUi(key);
  if (!u.btn || u.btn.classList.contains("loading")) return;
  u.btn.classList.add("loading");
  u.btn.disabled = true;
  setStatus(u.panel, "Opening work.ink in your browser…", "working");

  const r = await bridgePost("/workink/start");
  if (!r?.ok) {
    resetWorkink(key, `Could not open browser: ${r?.error || "unknown"}`, "err");
    return;
  }
  setStatus(u.panel, "Complete one checkpoint in your browser. This screen updates automatically.", "working");
  if (u.progress) u.progress.hidden = false;

  const start = Date.now();
  if (u.elapsed) u.elapsed.textContent = "0:00";
  const clock = setInterval(() => {
    if (u.elapsed) u.elapsed.textContent = fmtDuration(Date.now() - start);
  }, 1000);
  const poll = setInterval(async () => {
    if (Date.now() - start > WORKINK_TIMEOUT_MS) {
      resetWorkink(key, "Timed out. Click again to retry.", "err");
      return;
    }
    const s = await bridgeGet("/workink/state");
    if (!s) return;
    if (s.phase === 2) setStatus(u.panel, "Verifying your checkpoint…", "working");
    else if (s.phase === 3) await onWorkinkSuccess(key);
    else if (s.phase === 4) resetWorkink(key, s.error || "Redemption failed. Click again to retry.", "err");
  }, 1500);

  workinkRunners[key] = { poll, clock, start };
}

// --- Keyboard + eye wiring ---------------------------------------------------

function bindInputs() {
  const user = $("#login-username");
  const pwd = $("#login-password");
  const eyeBtn = $("#btn-toggle-pwd");

  if (user && pwd) {
    user.addEventListener("keydown", (e) => {
      if (e.key === "Enter") { e.preventDefault(); pwd.focus(); }
    });
    pwd.addEventListener("keydown", (e) => {
      if (e.key === "Enter") { e.preventDefault(); submitLogin(); }
    });
  }

  if (eyeBtn && pwd) {
    eyeBtn.addEventListener("click", () => {
      const isPwd = pwd.type === "password";
      pwd.type = isPwd ? "text" : "password";
      const open = eyeBtn.querySelector(".eye-open");
      const closed = eyeBtn.querySelector(".eye-closed");
      if (open) open.hidden = isPwd;
      if (closed) closed.hidden = !isPwd;
      pwd.focus();
    });
  }

  // Register panel: Enter advances to the next field / commits.
  $("#register-license-input")?.addEventListener("keydown", (e) => {
    if (e.key === "Enter") { e.preventDefault(); submitRegisterLicense(); }
  });
  $("#register-username")?.addEventListener("keydown", (e) => {
    if (e.key === "Enter") { e.preventDefault(); $("#register-password")?.focus(); }
  });
  $("#register-password")?.addEventListener("keydown", (e) => {
    if (e.key === "Enter") { e.preventDefault(); $("#register-confirm")?.focus(); }
  });
  $("#register-confirm")?.addEventListener("keydown", (e) => {
    if (e.key === "Enter") { e.preventDefault(); submitRegisterAccount(); }
  });
}

// --- Help opens the public invite --------------------------------------------

async function openHelp() {
  await bridgePost("/open-url", { url: HELP_URL });
}

// --- Public ------------------------------------------------------------------

export function initLicense() {
  bindInputs();

  // Sign-in panel
  $("#license-submit")?.addEventListener("click", submitLogin);
  $("#btn-signin-discord")?.addEventListener("click", signInWithDiscord);
  $("#btn-login-help")?.addEventListener("click", openHelp);

  // "Create account" switches into the register flow instead of leaving the app.
  $("#btn-create-account")?.addEventListener("click", () => {
    setStatus("signin", "", "");
    switchPanel("register-license");
    setStatus("register-license", "Enter the license key you were given to register.", "");
  });

  // Register wiring
  $("#register-license-next")?.addEventListener("click", submitRegisterLicense);
  $("#register-license-back")?.addEventListener("click", () => switchPanel("signin"));
  $("#register-account-next")?.addEventListener("click", submitRegisterAccount);
  $("#register-account-back")?.addEventListener("click", () => switchPanel("register-license"));
  $("#register-discord-connect")?.addEventListener("click", connectRegisterDiscord);
  $("#register-discord-skip")?.addEventListener("click", skipDiscord);
  $("#register-help")?.addEventListener("click", openHelp);

  // Free 24h key — one shared work.ink flow, surfaced on signin (expired key
  // on an existing account) and register-license (no key yet).
  $("#btn-signin-getkey")?.addEventListener("click", () => startWorkink("signin"));
  $("#btn-register-getkey")?.addEventListener("click", () => startWorkink("register-license"));
  $("#signin-workink-cancel")?.addEventListener("click", () =>
    resetWorkink("signin", "Cancelled. Click again to retry.", ""));
  $("#register-workink-cancel")?.addEventListener("click", () =>
    resetWorkink("register-license", "Cancelled. Click again to retry.", ""));

  on("signed-out", () => {
    $("#login-password") && ($("#login-password").value = "");
    $("#register-password") && ($("#register-password").value = "");
    $("#register-confirm") && ($("#register-confirm").value = "");
    showLicenseGate("Signed out.");
  });
}
