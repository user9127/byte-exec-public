/* License gate: Byte account sign-in (same login as projectbyte.cc), key entry
   (live cleanup + validity check), work.ink free-key flow, bridge-offline auto
   retry, a periodic re-check that reopens the gate when the account's key stops
   working, and the unlock transition into the app. */

import { $, sleep, formatDuration } from "./dom.js";
import { state, DISCORD_INVITE, ACCOUNT_URL } from "./state.js";
import { bridgeGet, bridgePost } from "./bridge.js";
import { syncInert } from "./dialog.js";
import { buttonFeedback, shake } from "./fx.js";
import { applyAuthState, renderAccount } from "./account.js";
import { initSeg, setSeg } from "./seg.js";
import { toast } from "./toast.js";
import { emit, on } from "./bus.js";

const KEY_RE = /^BYTE(-[A-Z0-9]+)+$/;
const USERNAME_RE = /^[A-Za-z0-9_]{3,20}$/;
const WORKINK_TIMEOUT_MS = 10 * 60 * 1000;
// The native side syncs with the account at most once a minute; this only
// decides how soon an open app notices a key that expired or was replaced.
const RECHECK_MS = 2 * 60 * 1000;
const html = document.documentElement;

let offlineRetry = 0;
let wkPoll = 0;
let wkClock = 0;
let wkStart = 0;
let mode = "account";

/* Server / native status codes -> what the user should do about them. */
const REASONS = {
  invalid_credentials: "Wrong username or password.",
  rate_limited: "Too many attempts. Wait 15 minutes and try again.",
  account_disabled: "This account is disabled. Open a ticket in the Discord.",
  missing_credentials: "Enter your username and password.",
  network_error: "Could not reach the license server. Check your connection.",
  hwid_error: "Could not read this PC's hardware ID.",
  invalid_key: "That key was not accepted. Check it, or open a ticket if it is linked to someone else.",
  expired: "That key has expired. Get a free 24-hour key below or use a key with time left.",
  disabled: "That key was disabled by staff. Open a ticket in the Discord.",
  wrong_hwid: "That key is bound to a different PC. Open a ticket for a HWID reset.",
  signed_out: "Your account was signed out on the website. Sign in again.",
  server_error: "The license server had a problem. Try again shortly.",
  "bridge offline": "Bridge offline. Make sure Byte.exe is running."
};
const reasonText = (code) => REASONS[code] || `Rejected: ${code || "unknown"}`;
const ADD_KEY_PROMPT = "Signed in. Add a key to continue.";

/* Why a signed-in account still sees the gate. */
function accountWhy() {
  if (!state.licenseKey) return { text: "This account has no key yet. Get a free 24-hour key below or enter a key.", kind: "warn" };
  if (state.licenseStatus === "expired") return { text: "Your key expired. Get a free 24-hour key below or enter a new key.", kind: "warn" };
  if (state.licenseStatus === "disabled") return { text: "Your key was disabled by staff. Open a ticket in the Discord.", kind: "err" };
  return { text: "Your key could not be activated on this PC. Enter a key or get a free 24-hour key.", kind: "warn" };
}

/* -> { ok, offline, authed } */
export async function checkAuth() {
  const s = await bridgeGet("/auth/state", { timeout: 20000 });
  if (!s) {
    state.bridgeReachable = false;
    return { ok: false, offline: true, authed: false };
  }
  state.bridgeReachable = true;
  applyAuthState(s);
  emit("auth");
  return { ok: true, offline: false, authed: state.authed };
}

function setStatus(text, kind = "", { retry = false } = {}) {
  const el = $("#license-status");
  el.className = `status-line ${kind}`;
  el.querySelector(".sl-text").textContent = text;
  $("#license-retry").hidden = !retry;
}

function setHint(text, kind = "") {
  const el = $("#license-getkey-hint");
  el.className = `license-hint ${kind}`;
  el.querySelector(".lh-text").textContent = text;
}

function focusActive() {
  const target = mode === "account"
    ? ($("#account-username").value ? $("#account-password") : $("#account-username"))
    : $("#license-input");
  setTimeout(() => target?.focus({ preventScroll: true }), 160);
}

function setMode(next) {
  mode = next;
  $("#pane-account").hidden = next !== "account";
  $("#pane-key").hidden = next !== "key";
  setSeg($("#gate-mode"), next);
}

/* Signed in to an account but without a working key: show who, and why,
   and offer the key field + free key instead of the login form. */
function renderGateAccount() {
  const box = $("#gate-account");
  const signedIn = !!state.account;
  box.hidden = !signedIn;
  $("#gate-mode").hidden = signedIn;
  if (!signedIn) {
    $("#license-title").textContent = "Sign in to Byte";
    $("#license-sub").textContent = "Use your Byte account from projectbyte.cc, or activate with a license key. A key binds to this computer the first time it is used.";
    return;
  }
  const why = accountWhy();
  box.className = `gate-account ${why.kind}`;
  $("#gate-account-name").textContent = state.account.username;
  $("#gate-account-why").textContent = why.text;
  $("#license-title").textContent = "Your account needs a key";
  $("#license-sub").textContent = "A key you enter here, or a free 24-hour key, becomes your account's key on the website too.";
  setMode("key");
}

export function isGateOpen() { return state.gateOpen; }

export function showLicenseGate(msg, kind = "", opts = {}) {
  const gate = $("#license-gate");
  if (!state.gateOpen) {
    state.gateOpen = true;
    syncInert();
    html.classList.add("cover-on");
    gate.classList.remove("leaving", "show");
    gate.hidden = false;
    void gate.offsetWidth;
    gate.classList.add("show");
    for (const id of ["#license-submit", "#account-submit"]) {
      const btn = $(id);
      btn.disabled = false;
      btn.classList.remove("loading", "is-success");
    }
  }
  renderGateAccount();
  if (msg) setStatus(msg, kind, opts);
  if (!state.bridgeReachable) startOfflineRetry();
  focusActive();
}

function hideLicenseGate() {
  return new Promise((resolve) => {
    const gate = $("#license-gate");
    stopOfflineRetry();
    stopWorkink();
    if (!state.gateOpen) { resolve(); return; }
    state.gateOpen = false;
    gate.classList.add("leaving");
    setTimeout(() => {
      gate.hidden = true;
      gate.classList.remove("show", "leaving");
      html.classList.remove("cover-on");
      syncInert();
      resolve();
    }, 130);
  });
}

async function unlock() {
  $("#account-password").value = "";
  renderAccount();
  await hideLicenseGate();
  emit("app-reveal");
}

/* ---------------------------------------------------------- account sign-in */
async function submitAccount() {
  const btn = $("#account-submit");
  if (btn.classList.contains("loading")) return;
  const userEl = $("#account-username");
  const passEl = $("#account-password");
  const username = userEl.value.trim();
  const password = passEl.value;
  if (!username || !password) {
    setStatus(REASONS.missing_credentials, "err");
    shake((username ? passEl : userEl).closest(".key-input"));
    (username ? passEl : userEl).focus();
    return;
  }
  if (!USERNAME_RE.test(username)) {
    setStatus("Usernames are 3 to 20 letters, numbers or underscores.", "err");
    shake(userEl.closest(".key-input"));
    userEl.focus();
    return;
  }

  btn.classList.add("loading");
  btn.disabled = true;
  setStatus("Signing in…", "working");
  const r = await bridgePost("/auth/account", { username, password }, { timeout: 30000 });
  btn.classList.remove("loading");
  btn.disabled = false;

  if (!r?.ok) {
    passEl.value = "";
    buttonFeedback(btn, "fail");
    setStatus(reasonText(r?.status || r?.error || "bridge offline"), "err", { retry: !r });
    shake(passEl.closest(".key-input"));
    passEl.focus();
    return;
  }

  passEl.value = "";
  const a = await checkAuth();
  if (r.authed && a.authed) {
    buttonFeedback(btn, "success", 700);
    setStatus(`Signed in as ${state.account?.username || username}. Loading your workspace…`, "ok");
    await sleep(350);
    await unlock();
    return;
  }
  // Credentials were right; the account just has no working key on this PC.
  // The banner explains why; the status line only says what to do next,
  // unless the key is fine but bound to another PC.
  renderGateAccount();
  if (r.status === "wrong_hwid") setStatus(REASONS.wrong_hwid, "err");
  else setStatus(ADD_KEY_PROMPT, "");
  focusActive();
}

async function signOutAccount() {
  await bridgePost("/auth/signout");
  await checkAuth();
  renderAccount();
  renderGateAccount();
  setMode("account");
  setStatus("Signed out.", "");
  focusActive();
}

/* -------------------------------------------------------------- key input */
function cleanKey(v) {
  // spaces become dashes so a key pasted as "BYTE XXXX XXXX" still validates
  return v.toUpperCase().replace(/\s+/g, "-").replace(/[^A-Z0-9-]/g, "").replace(/-{2,}/g, "-");
}

function bindKeyInput() {
  const input = $("#license-input");
  const wrap = $("#key-input-wrap");
  input.addEventListener("input", () => {
    const before = input.value;
    const caret = input.selectionStart ?? before.length;
    const cleaned = cleanKey(before);
    if (cleaned !== before) {
      const pos = cleanKey(before.slice(0, caret)).length;
      input.value = cleaned;
      input.setSelectionRange(pos, pos);
    }
    wrap.classList.remove("invalid");
    wrap.classList.toggle("valid", KEY_RE.test(cleaned));
  });
  input.addEventListener("keydown", (e) => { if (e.key === "Enter") submitLicense(); });
}

async function submitLicense() {
  const input = $("#license-input");
  const wrap = $("#key-input-wrap");
  const btn = $("#license-submit");
  if (btn.classList.contains("loading")) return;
  const key = cleanKey(input.value.trim());
  if (!KEY_RE.test(key)) {
    setStatus(key ? "That does not look like a Byte key." : "Enter your license key first.", "err");
    wrap.classList.add("invalid");
    shake(wrap);
    input.focus();
    return;
  }
  btn.classList.add("loading");
  btn.disabled = true;
  setStatus(state.account ? "Adding the key to your account…" : "Contacting license server…", "working");
  const r = await bridgePost("/auth/license", { key }, { timeout: 30000 });
  btn.classList.remove("loading");
  if (r?.ok) {
    buttonFeedback(btn, "success", 700);
    setStatus("Authenticated. Loading your workspace…", "ok");
    await sleep(350);
    const a = await checkAuth();
    if (a.authed) { await unlock(); return; }
    btn.disabled = false;
    setStatus("Activated, but the launcher did not confirm the session. Try again.", "warn");
    return;
  }
  btn.disabled = false;
  const reason = r?.status || r?.error || "bridge offline";
  if (reason === "signed_out") { await checkAuth(); renderGateAccount(); setMode("account"); }
  setStatus(reasonText(reason), "err", { retry: reason === "bridge offline" });
  wrap.classList.remove("valid");
  wrap.classList.add("invalid");
  buttonFeedback(btn, "fail");
  shake(wrap);
}

/* ----------------------------------------------------- bridge offline retry */
function startOfflineRetry() {
  if (offlineRetry) return;
  offlineRetry = setInterval(async () => {
    const a = await checkAuth();
    if (!a.ok) return;
    stopOfflineRetry();
    if (a.authed) { await unlock(); return; }
    renderGateAccount();
    setStatus(state.account ? ADD_KEY_PROMPT : "Connected to Byte. Sign in to continue.", "");
  }, 3000);
}

function stopOfflineRetry() {
  clearInterval(offlineRetry);
  offlineRetry = 0;
}

async function retryNow() {
  const btn = $("#license-retry");
  btn.disabled = true;
  setStatus("Reconnecting…", "working");
  const a = await checkAuth();
  btn.disabled = false;
  if (!a.ok) { setStatus(REASONS["bridge offline"], "err", { retry: true }); return; }
  stopOfflineRetry();
  if (a.authed) await unlock();
  else { renderGateAccount(); setStatus(state.account ? ADD_KEY_PROMPT : "Connected to Byte. Sign in to continue.", ""); }
}

/* --------------------------------------------------- work.ink free 24h key */
// Native phases (bxu::WorkinkPhase): 0 idle, 1 waiting, 2 verifying, 3 ok, 4 failed
function stopWorkink() {
  clearInterval(wkPoll);
  clearInterval(wkClock);
  wkPoll = 0;
  wkClock = 0;
  $("#workink-progress").hidden = true;
}

function resetWorkinkUi(msg, kind) {
  stopWorkink();
  const btn = $("#license-getkey");
  btn.disabled = false;
  btn.classList.remove("loading");
  setHint(msg, kind);
}

async function startWorkink() {
  const btn = $("#license-getkey");
  btn.classList.add("loading");
  btn.disabled = true;
  setHint("Opening work.ink in your browser…", "working");
  const r = await bridgePost("/workink/start");
  btn.classList.remove("loading");
  if (!r?.ok) {
    btn.disabled = false;
    buttonFeedback(btn, "fail");
    setHint(`Could not open browser: ${r?.error || "unknown"}`, "err");
    return;
  }
  setHint("Complete one checkpoint in your browser. This screen unlocks automatically.", "working");
  $("#workink-progress").hidden = false;
  wkStart = Date.now();
  $("#workink-elapsed").textContent = "0:00";
  clearInterval(wkClock);
  wkClock = setInterval(() => { $("#workink-elapsed").textContent = formatDuration(Date.now() - wkStart); }, 1000);

  clearInterval(wkPoll);
  wkPoll = setInterval(async () => {
    if (Date.now() - wkStart > WORKINK_TIMEOUT_MS) {
      resetWorkinkUi("Timed out. Click again to retry.", "err");
      return;
    }
    const s = await bridgeGet("/workink/state");
    if (!s) return;
    if (s.phase === 2) setHint("Verifying your checkpoint…", "working");
    if (s.phase === 3) {
      stopWorkink();
      setHint(state.account ? "Key received and added to your account. Activating…" : "Key received. Activating…", "ok");
      await sleep(240);
      const a = await checkAuth();
      if (a.authed) await unlock();
      else resetWorkinkUi("Key received but activation did not finish. Try again.", "err");
    } else if (s.phase === 4) {
      resetWorkinkUi(s.error || "Redemption failed. Click again to retry.", "err");
    }
  }, 1500);
}

/* ------------------------------------------- keep the open app in step */
// The website can renew, replace or revoke this PC's key at any time. Re-read
// the auth state now and then: a new key is picked up quietly, a key that
// stopped working (or a sign-out from the website) brings the gate back.
async function recheck() {
  if (state.gateOpen || document.hidden) return;
  const before = state.licenseKey;
  const a = await checkAuth();
  if (!a.ok) return;
  if (!a.authed) {
    showLicenseGate(state.account ? "Your key stopped working. Add a key to continue." : "You were signed out. Sign in again to continue.", "warn");
    return;
  }
  if (before && state.licenseKey && before !== state.licenseKey) {
    renderAccount();
    toast("Your key was updated from your Byte account.", "ok", 4000);
  }
}

/* ------------------------------------------------------------------- init */
export function initLicense() {
  bindKeyInput();
  initSeg($("#gate-mode"), mode, (value) => {
    setMode(value);
    setStatus(value === "account" ? "Sign in with your projectbyte.cc account." : "Enter your license key.", "");
    focusActive();
  });
  setMode(mode);

  $("#license-submit").addEventListener("click", submitLicense);
  $("#account-submit").addEventListener("click", submitAccount);
  for (const id of ["#account-username", "#account-password"]) {
    $(id).addEventListener("keydown", (e) => { if (e.key === "Enter") submitAccount(); });
  }
  $("#account-create").addEventListener("click", async () => {
    const r = await bridgePost("/open-url", { url: ACCOUNT_URL });
    if (!r?.ok) toast("Could not open the browser.", "err");
  });
  $("#gate-account-signout").addEventListener("click", signOutAccount);
  $("#license-retry").addEventListener("click", retryNow);
  $("#license-getkey").addEventListener("click", startWorkink);
  $("#workink-cancel").addEventListener("click", () =>
    resetWorkinkUi("Opens work.ink in your browser. Complete one checkpoint and this screen unlocks automatically.", ""));
  $("#gate-discord").addEventListener("click", async () => {
    const r = await bridgePost("/open-url", { url: DISCORD_INVITE });
    if (!r?.ok) toast("Could not open the browser.", "err");
  });

  setInterval(recheck, RECHECK_MS);
  document.addEventListener("visibilitychange", () => { if (!document.hidden) recheck(); });

  on("signed-out", () => {
    $("#license-input").value = "";
    $("#account-password").value = "";
    $("#key-input-wrap").classList.remove("valid", "invalid");
    setMode("account");
    showLicenseGate("Signed out.");
  });
}
