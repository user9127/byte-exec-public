// Custom right-click clipboard menu.
// WebView2 has AreDefaultContextMenusEnabled(FALSE), so right-click normally
// does nothing. This installs a small floating menu with Copy / Cut / Paste /
// Select All for inputs, textareas, and anything marked .selectable.
// Reads/writes the system clipboard via navigator.clipboard; falls back to
// document.execCommand on the (rare) WebView2 configurations where the async
// clipboard API is blocked.

const INPUT_SEL = 'input, textarea, [contenteditable=""], [contenteditable="true"]';
const TEXT_SEL  = `${INPUT_SEL}, .selectable`;

let menuEl = null;

function ensureMenu() {
  if (menuEl) return menuEl;
  menuEl = document.createElement("div");
  menuEl.className = "ctx-menu";
  menuEl.hidden = true;
  menuEl.setAttribute("role", "menu");
  // Prevent the menu itself from stealing focus from the target input.
  menuEl.addEventListener("mousedown", (e) => e.preventDefault());
  document.body.appendChild(menuEl);
  return menuEl;
}

function hideMenu() {
  if (menuEl) menuEl.hidden = true;
}

async function readClipboard() {
  try { return await navigator.clipboard.readText(); } catch { /* fall through */ }
  // execCommand("paste") requires focus on an input + user gesture. Not
  // perfect but kept as a last-ditch fallback.
  try {
    const scratch = document.createElement("textarea");
    scratch.style.position = "fixed"; scratch.style.left = "-9999px";
    document.body.appendChild(scratch);
    scratch.focus();
    const ok = document.execCommand("paste");
    const v = ok ? scratch.value : "";
    document.body.removeChild(scratch);
    return v;
  } catch { return ""; }
}

async function writeClipboard(text) {
  try { await navigator.clipboard.writeText(text); return true; } catch {}
  try {
    const scratch = document.createElement("textarea");
    scratch.value = text;
    scratch.style.position = "fixed"; scratch.style.left = "-9999px";
    document.body.appendChild(scratch);
    scratch.select();
    const ok = document.execCommand("copy");
    document.body.removeChild(scratch);
    return ok;
  } catch { return false; }
}

function isEditable(el) {
  if (!el) return false;
  if (el.matches(INPUT_SEL)) return !el.disabled && !el.readOnly;
  return false;
}

function selectionText(el) {
  if (!el) return "";
  if (el.matches(INPUT_SEL)) {
    const start = el.selectionStart ?? 0;
    const end   = el.selectionEnd ?? 0;
    return (el.value || "").slice(start, end);
  }
  return String(window.getSelection?.() || "");
}

function replaceSelection(el, text) {
  if (!el || !el.matches(INPUT_SEL)) return false;
  const start = el.selectionStart ?? 0;
  const end   = el.selectionEnd ?? 0;
  const v = el.value || "";
  el.value = v.slice(0, start) + text + v.slice(end);
  const caret = start + text.length;
  el.setSelectionRange(caret, caret);
  el.dispatchEvent(new Event("input", { bubbles: true }));
  return true;
}

function selectAll(el) {
  if (!el) return;
  if (el.matches(INPUT_SEL)) {
    el.focus();
    el.select?.();
  } else {
    const range = document.createRange();
    range.selectNodeContents(el);
    const sel = window.getSelection();
    sel?.removeAllRanges();
    sel?.addRange(range);
  }
}

function makeItem(label, kbd, enabled, onPick) {
  const item = document.createElement("button");
  item.type = "button";
  item.className = "ctx-item";
  if (!enabled) item.setAttribute("disabled", "disabled");
  item.innerHTML = `<span>${label}</span><span class="kbd">${kbd || ""}</span>`;
  if (enabled) {
    item.addEventListener("click", async () => {
      hideMenu();
      await onPick();
    });
  }
  return item;
}

function makeSep() {
  const s = document.createElement("div");
  s.className = "ctx-sep";
  return s;
}

function showMenuAt(x, y, target) {
  const menu = ensureMenu();
  menu.innerHTML = "";

  const editable = isEditable(target);
  const sel = selectionText(target);
  const hasSel = sel.length > 0;

  menu.appendChild(makeItem("Cut",   "Ctrl+X", editable && hasSel, async () => {
    if (await writeClipboard(sel)) replaceSelection(target, "");
  }));
  menu.appendChild(makeItem("Copy",  "Ctrl+C", hasSel, async () => {
    await writeClipboard(sel);
  }));
  menu.appendChild(makeItem("Paste", "Ctrl+V", editable, async () => {
    const t = await readClipboard();
    if (t) replaceSelection(target, t);
  }));
  menu.appendChild(makeSep());
  menu.appendChild(makeItem("Select all", "Ctrl+A", true, async () => {
    selectAll(target);
  }));

  menu.hidden = false;
  // Clamp into viewport.
  const rect = menu.getBoundingClientRect();
  const pad = 4;
  const px = Math.min(x, window.innerWidth  - rect.width  - pad);
  const py = Math.min(y, window.innerHeight - rect.height - pad);
  menu.style.left = Math.max(pad, px) + "px";
  menu.style.top  = Math.max(pad, py) + "px";
}

function onContextMenu(e) {
  const el = e.target.closest(TEXT_SEL);
  if (!el) return;
  e.preventDefault();
  showMenuAt(e.clientX, e.clientY, el);
}

export function initCtxMenu() {
  document.addEventListener("contextmenu", onContextMenu, true);
  // Any click outside the menu dismisses it.
  document.addEventListener("mousedown", (e) => {
    if (!menuEl || menuEl.hidden) return;
    if (!menuEl.contains(e.target)) hideMenu();
  }, true);
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") hideMenu();
  });
  window.addEventListener("blur", hideMenu);
  window.addEventListener("resize", hideMenu);
  window.addEventListener("scroll", hideMenu, true);
}
