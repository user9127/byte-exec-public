import { $, $$ } from "./dom.js";
import { glide, reducedMotion } from "./motion.js";
import { state, DISCORD_INVITE } from "./state.js";
import { store } from "./store.js";
import { bridgePost } from "./bridge.js";
import { toast } from "./toast.js";
import { hideTooltip } from "./tooltip.js";
import { emit, on } from "./bus.js";

export const PAGE_IDS = ["execution", "library", "versions", "accounts", "settings", "console"];
const html = document.documentElement;
const timers = new WeakMap();
const narrowMq = window.matchMedia("(max-width: 900px)");
let sidebarOverride = null; 
let lastPageBeforeConsole = "execution";

export function toggleConsole() {
  if (state.page === "console") {
    goToPage(lastPageBeforeConsole || "execution");
  } else {
    lastPageBeforeConsole = state.page;
    goToPage("console");
  }
}

const pageEl = (id) => $(`.page[data-page="${id}"]`);

function syncNav(instant = false) {
  let activeItem = null;
  for (const n of $$(".nav-item[data-page]")) {
    const on = n.dataset.page === state.page;
    n.classList.toggle("active", on);
    if (on) { n.setAttribute("aria-current", "page"); activeItem = n; }
    else n.removeAttribute("aria-current");
  }
  const ind = $("#nav-indicator");
  if (ind) {
    if (activeItem) {
      ind.style.display = "";
      glide(ind, activeItem, { axis: "y", instant });
    } else {
      ind.style.display = "none";
    }
  }
  const tbConsole = $("#tb-console");
  if (tbConsole) {
    tbConsole.classList.toggle("active", state.page === "console");
  }
}

export function goToPage(p, { instant = false, replay = false } = {}) {
  if (!PAGE_IDS.includes(p)) return;
  const from = state.page;
  if (p === from && !replay) return;
  state.page = p;
  syncNav(instant);

  const toEl = pageEl(p);
  const fromEl = pageEl(from);
  const dir = PAGE_IDS.indexOf(p) >= PAGE_IDS.indexOf(from) ? 1 : -1;
  const animated = !instant && !reducedMotion();
  toEl.style.setProperty("--enter-y", `${dir * 14}px`);

  if (fromEl && fromEl !== toEl) {
    fromEl.style.setProperty("--leave-y", `${-dir * 8}px`);
    fromEl.classList.remove("active", "entering");
    clearTimeout(timers.get(fromEl));
    if (animated) {
      fromEl.classList.add("leaving");
      timers.set(fromEl, setTimeout(() => fromEl.classList.remove("leaving"), 10));
    }
  }

  clearTimeout(timers.get(toEl));
  toEl.classList.remove("leaving");
  toEl.classList.add("active");
  if (animated) {
    toEl.classList.remove("entering");
    void toEl.offsetWidth; 
    toEl.classList.add("entering");
    timers.set(toEl, setTimeout(() => toEl.classList.remove("entering"), 200));
  }

  try { history.replaceState(null, "", `#${p}`); } catch {  }
  emit("page", { from, to: p });
}

function sidebarCollapsed() {
  if (sidebarOverride !== null) return sidebarOverride;
  return narrowMq.matches || store.get("sidebar", "expanded") === "collapsed";
}

export function applySidebar() {
  const collapsed = sidebarCollapsed();
  html.dataset.sidebar = collapsed ? "collapsed" : "expanded";
  const btn = $("#sidebar-toggle");
  btn.setAttribute("aria-expanded", String(!collapsed));
  btn.setAttribute("aria-label", collapsed ? "Expand sidebar" : "Collapse sidebar");
  hideTooltip();
  emit("sidebar", collapsed);
}

export function toggleSidebar() {
  if (narrowMq.matches) sidebarOverride = !sidebarCollapsed();
  else store.set("sidebar", sidebarCollapsed() ? "expanded" : "collapsed");
  applySidebar();
}

export function setSidebarPref(collapsed) {
  store.set("sidebar", collapsed ? "collapsed" : "expanded");
  sidebarOverride = null;
  applySidebar();
}

export function initNav() {
  const scroll = $("#nav-scroll");

  scroll.addEventListener("click", async (e) => {
    const n = e.target.closest(".nav-item");
    if (!n) return;
    if (n.classList.contains("external")) {
      const r = await bridgePost("/open-url", { url: n.dataset.url || DISCORD_INVITE });
      if (!r?.ok) toast("Could not open the browser.", "err");
      return;
    }
    goToPage(n.dataset.page);
  });

  scroll.addEventListener("keydown", (e) => {
    if (e.key !== "ArrowDown" && e.key !== "ArrowUp") return;
    const items = $$(".nav-item", scroll);
    const i = items.indexOf(document.activeElement);
    if (i === -1) return;
    e.preventDefault();
    items[(i + (e.key === "ArrowDown" ? 1 : -1) + items.length) % items.length].focus();
  });

  $("#sidebar-identity").addEventListener("click", async () => {
    const { confirmDialog } = await import("./dialog.js");
    const ok = await confirmDialog({
      title: "Sign out of Byte?",
      message: "Do you want to sign out and return to the login screen?",
      confirmLabel: "Sign out",
      danger: true
    });
    if (!ok) return;
    const { bridgePost } = await import("./bridge.js");
    await bridgePost("/auth/signout");
    state.authed = false;
    emit("signed-out");
  });
  $("#sidebar-toggle").addEventListener("click", toggleSidebar);
  narrowMq.addEventListener("change", () => { sidebarOverride = null; applySidebar(); });
  new ResizeObserver(() => syncNav(true)).observe(scroll);

  applySidebar();
  syncNav(true);

  const initial = (location.hash || "").replace(/^#/, "");
  if (PAGE_IDS.includes(initial) && initial !== state.page) goToPage(initial, { instant: true });

  on("prefs-reset", () => { sidebarOverride = null; applySidebar(); });
}
