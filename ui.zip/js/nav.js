/* Navigation: page switching with directional transitions and staggered
   reveals, gliding active/hover indicators, sidebar collapse (manual and
   automatic below 900px). */

import { $, $$ } from "./dom.js";
import { glide, reducedMotion } from "./motion.js";
import { state, DISCORD_INVITE } from "./state.js";
import { store } from "./store.js";
import { bridgePost } from "./bridge.js";
import { toast } from "./toast.js";
import { hideTooltip } from "./tooltip.js";
import { emit, on } from "./bus.js";

export const PAGE_IDS = ["execution", "library", "console", "account", "settings"];
const html = document.documentElement;
const timers = new WeakMap();
const narrowMq = window.matchMedia("(max-width: 900px)");
let sidebarOverride = null; // session-only toggle while the window is narrow

const pageEl = (id) => $(`.page[data-page="${id}"]`);

function syncNav(instant = false) {
  let activeItem = null;
  for (const n of $$(".nav-item[data-page]")) {
    const on = n.dataset.page === state.page;
    n.classList.toggle("active", on);
    if (on) { n.setAttribute("aria-current", "page"); activeItem = n; }
    else n.removeAttribute("aria-current");
  }
  if (activeItem) glide($("#nav-indicator"), activeItem, { axis: "y", instant });
}

export function goToPage(p, { instant = false, replay = false } = {}) {
  if (!PAGE_IDS.includes(p)) return;
  const from = state.page;
  if (p === from && !replay) return;
  state.page = p;
  syncNav(instant);

  const toEl = pageEl(p);
  const fromEl = pageEl(from);
  const dir = PAGE_IDS.indexOf(p) >= PAGE_IDS.indexOf(from) ? 1 : -1;
  const animated = !instant && !reducedMotion();
  toEl.style.setProperty("--enter-y", `${dir * 14}px`);

  if (fromEl && fromEl !== toEl) {
    fromEl.style.setProperty("--leave-y", `${-dir * 8}px`);
    fromEl.classList.remove("active", "entering");
    clearTimeout(timers.get(fromEl));
    if (animated) {
      fromEl.classList.add("leaving");
      timers.set(fromEl, setTimeout(() => fromEl.classList.remove("leaving"), 10));
    }
  }

  clearTimeout(timers.get(toEl));
  toEl.classList.remove("leaving");
  toEl.classList.add("active");
  if (animated) {
    toEl.classList.remove("entering");
    void toEl.offsetWidth; // restart the reveal keyframes
    toEl.classList.add("entering");
    timers.set(toEl, setTimeout(() => toEl.classList.remove("entering"), 200));
  }

  try { history.replaceState(null, "", `#${p}`); } catch { /* sandboxed history */ }
  emit("page", { from, to: p });
}

/* ------------------------------------------------------------------ sidebar */
function sidebarCollapsed() {
  if (sidebarOverride !== null) return sidebarOverride;
  return narrowMq.matches || store.get("sidebar", "expanded") === "collapsed";
}

export function applySidebar() {
  const collapsed = sidebarCollapsed();
  html.dataset.sidebar = collapsed ? "collapsed" : "expanded";
  const btn = $("#sidebar-toggle");
  btn.setAttribute("aria-expanded", String(!collapsed));
  btn.setAttribute("aria-label", collapsed ? "Expand sidebar" : "Collapse sidebar");
  hideTooltip();
  emit("sidebar", collapsed);
}

export function toggleSidebar() {
  if (narrowMq.matches) sidebarOverride = !sidebarCollapsed();
  else store.set("sidebar", sidebarCollapsed() ? "expanded" : "collapsed");
  applySidebar();
}

export function setSidebarPref(collapsed) {
  store.set("sidebar", collapsed ? "collapsed" : "expanded");
  sidebarOverride = null;
  applySidebar();
}

/* ---------------------------------------------------------------- init */
export function initNav() {
  const scroll = $("#nav-scroll");

  scroll.addEventListener("click", async (e) => {
    const n = e.target.closest(".nav-item");
    if (!n) return;
    if (n.classList.contains("external")) {
      const r = await bridgePost("/open-url", { url: n.dataset.url || DISCORD_INVITE });
      if (!r?.ok) toast("Could not open the browser.", "err");
      return;
    }
    goToPage(n.dataset.page);
  });

  // arrow keys move between nav items
  scroll.addEventListener("keydown", (e) => {
    if (e.key !== "ArrowDown" && e.key !== "ArrowUp") return;
    const items = $$(".nav-item", scroll);
    const i = items.indexOf(document.activeElement);
    if (i === -1) return;
    e.preventDefault();
    items[(i + (e.key === "ArrowDown" ? 1 : -1) + items.length) % items.length].focus();
  });

  $("#sidebar-identity").addEventListener("click", () => goToPage("account"));
  $("#sidebar-toggle").addEventListener("click", toggleSidebar);
  narrowMq.addEventListener("change", () => { sidebarOverride = null; applySidebar(); });
  new ResizeObserver(() => syncNav(true)).observe(scroll);

  applySidebar();
  syncNav(true);

  // deep link: #library etc. (falls back to the executor)
  const initial = (location.hash || "").replace(/^#/, "");
  if (PAGE_IDS.includes(initial) && initial !== state.page) goToPage(initial, { instant: true });

  on("prefs-reset", () => { sidebarOverride = null; applySidebar(); });
}
