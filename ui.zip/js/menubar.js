import { $, $$ } from "./dom.js";
import { openMenu, isMenuOpen, closeMenu } from "./menu.js";
import { goToPage } from "./nav.js";
import { currentScript, newTab, openFileDialog, saveActive, closeTab } from "./editor.js";
import { runScript, inject, launchSupportedRoblox, openDiscord } from "./actions.js";
import { clearConsole } from "./console.js";
import { openPalette } from "./palette.js";
import { openShortcuts } from "./shortcuts.js";
import { checkUpdate } from "./update.js";
import { toast } from "./toast.js";
import { copyText } from "./dom.js";
import { state } from "./state.js";

let activeMenuBtn = null;
let autoScrollEnabled = true;

export function isAutoScrollEnabled() {
  return autoScrollEnabled;
}

export function toggleBottomConsole() {

  if (state.page !== "execution") {
    goToPage("execution");
  }

  const panel = $("#output-panel");
  const splitter = $("#splitter");
  if (!panel) return;

  const isCollapsed = panel.classList.contains("collapsed") || panel.offsetHeight <= 42;
  if (isCollapsed) {

    panel.style.setProperty("--out-h", "200px");
    panel.classList.remove("collapsed");
    panel.style.display = "";
    if (splitter) splitter.style.display = "";
    panel.scrollIntoView({ behavior: "smooth", block: "end" });
  } else {

    panel.style.setProperty("--out-h", "38px");
    panel.classList.add("collapsed");
  }
}

export function copyAllConsoleOutput() {
  const c = $("#console") || $("#console-full");
  if (!c) {
    toast("No console output.", "warn");
    return;
  }
  const text = c.innerText || c.textContent || "";
  if (!text.trim()) {
    toast("Console is empty.", "warn");
    return;
  }
  copyText(text).then((ok) => {
    toast(ok ? "Copied console output." : "Failed to copy.", ok ? "ok" : "err", 1800);
  });
}

function getMenuEntries(menuId) {
  switch (menuId) {
    case "file":
      return [
        { label: "New Script", icon: "plus", kbd: "Ctrl+T", run: () => { goToPage("execution"); newTab(); } },
        { label: "Open File…", icon: "folder", kbd: "Ctrl+O", run: () => { goToPage("execution"); openFileDialog(); } },
        { label: "Save", icon: "save", kbd: "Ctrl+S", run: () => saveActive() },
        "sep",
        { label: "Close Tab", icon: "x", kbd: "Ctrl+W", run: () => closeTab() },
        "sep",
        { label: "Sign Out", icon: "logout", run: async () => {
          const { bridgePost } = await import("./bridge.js");
          await bridgePost("/auth/signout");
          const { state } = await import("./state.js");
          state.authed = false;
          const { emit } = await import("./bus.js");
          emit("signed-out");
        } }
      ];

    case "edit":
      return [
        { label: "Undo", kbd: "Ctrl+Z", run: () => document.execCommand("undo") },
        { label: "Redo", kbd: "Ctrl+Y", run: () => document.execCommand("redo") },
        "sep",
        { label: "Cut", kbd: "Ctrl+X", run: () => document.execCommand("cut") },
        { label: "Copy", kbd: "Ctrl+C", run: () => document.execCommand("copy") },
        { label: "Paste", kbd: "Ctrl+V", run: () => document.execCommand("paste") }
      ];

    case "selection":
      return [
        { label: "Select All", kbd: "Ctrl+A", run: () => document.execCommand("selectAll") }
      ];

    case "view":
      return [
        { label: "Workspace", icon: "code", kbd: "Ctrl+1", run: () => goToPage("execution") },
        { label: "Script Hub", icon: "library", kbd: "Ctrl+2", run: () => goToPage("library") },
        { label: "Versions", icon: "layers", kbd: "Ctrl+3", run: () => goToPage("versions") },
        { label: "Setting", icon: "gear", kbd: "Ctrl+4", run: () => goToPage("settings") },
        "sep",
        { label: "Command Palette…", icon: "search", kbd: "Ctrl+K", run: () => openPalette() }
      ];

    case "go":
      return [
        { label: "Go to Line…", kbd: "Ctrl+G", run: () => openPalette() },
        { label: "Go to File…", kbd: "Ctrl+P", run: () => openPalette() }
      ];

    case "run":
      return [
        { label: "Run Script", icon: "play", kbd: "Ctrl+Enter", run: () => runScript(currentScript(), { button: $("#btn-execute") }) },
        { label: "Inject Byte", icon: "inject", kbd: "Ctrl+Shift+Enter", run: () => inject() },
        "sep",
        { label: "Launch Roblox", icon: "play", run: () => launchSupportedRoblox() }
      ];

    case "terminal":
      return [
        { label: "Toggle Console", kbd: "Ctrl+`", run: () => toggleBottomConsole() },
        { label: "Clear Console", kbd: "Ctrl+L", run: () => clearConsole() },
        { label: "Copy Console Output", kbd: "Ctrl+Shift+Alt+C", run: () => copyAllConsoleOutput() },
        {
          label: `${autoScrollEnabled ? "✓ " : "   "}Auto Scroll`,
          kbd: "Ctrl+Shift+A",
          run: () => {
            autoScrollEnabled = !autoScrollEnabled;
            toast(`Auto Scroll ${autoScrollEnabled ? "enabled" : "disabled"}.`, "info", 1500);
          }
        }
      ];

    case "help":
      return [
        { label: "Keyboard Shortcuts", icon: "keyboard", kbd: "?", run: () => openShortcuts() },
        { label: "Discord Community", icon: "discord", run: () => openDiscord() },
        "sep",
        { label: "Check for Updates", icon: "refresh", run: () => { goToPage("settings"); checkUpdate(true); } }
      ];

    default:
      return [];
  }
}

function showSubmenu(btn) {
  const menuId = btn.dataset.menu;
  if (!menuId) return;

  const rect = btn.getBoundingClientRect();
  const entries = getMenuEntries(menuId);
  if (!entries.length) return;

  activeMenuBtn?.classList.remove("active");
  activeMenuBtn = btn;
  btn.classList.add("active");

  openMenu(rect.left, rect.bottom + 4, entries, { focusFirst: false });

  const checkClose = setInterval(() => {
    if (!isMenuOpen()) {
      clearInterval(checkClose);
      btn.classList.remove("active");
      if (activeMenuBtn === btn) activeMenuBtn = null;
    }
  }, 80);
}

export function initMenuBar() {
  const bar = $("#tb-menubar");
  if (!bar) return;

  $$(".mb-item", bar).forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      if (isMenuOpen() && activeMenuBtn === btn) {
        closeMenu();
        btn.classList.remove("active");
        activeMenuBtn = null;
      } else {
        showSubmenu(btn);
      }
    });

    btn.addEventListener("mouseenter", () => {
      if (isMenuOpen() && activeMenuBtn && activeMenuBtn !== btn) {
        showSubmenu(btn);
      }
    });
  });
}
