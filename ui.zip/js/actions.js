import { $, formatBytes } from "./dom.js";
import { state, canInject, DISCORD_INVITE } from "./state.js";
import { bridgePost, bridgePostRaw } from "./bridge.js";
import { log } from "./console.js";
import { toast } from "./toast.js";
import { buttonFeedback, shake } from "./fx.js";
import { confirmDialog } from "./dialog.js";
import { on } from "./bus.js";
import { getActiveLaunchHash } from "./versions.js";

const INJECT_WATCH_MS = 25000;
let injectWatch = 0;
let holdTimer = 0;

export async function runScript(src, { label = null, button = null } = {}) {
  if (!src || !src.trim()) {
    toast("Nothing to execute.", "warn");
    shake(button);
    return false;
  }
  if (!state.activePid) {
    toast("No Roblox attached.", "err", 3200, canInject() ? { action: { label: "Inject", run: () => inject() } } : {});
    shake(button);
    return false;
  }
  if (button) { button.classList.add("loading"); button.disabled = true; }
  const bytes = new TextEncoder().encode(src).length;
  log(label ? `Running ${label}` : `Executing ${formatBytes(bytes)} on PID ${state.activePid}`, "info");
  const r = await bridgePostRaw("/execute", src);
  if (button) { button.classList.remove("loading"); button.disabled = false; }
  if (r?.ok) {
    import("./home.js").then((m) => {
      m.recordRecent({ name: label || "Executed Script", content: src });
    }).catch(() => {});
    buttonFeedback(button, "success");
    toast(label ? `Executed ${label}.` : "Script executed.", "ok", 1600);
    log(label ? `${label} executed.` : "Executed.", "ok");
    return true;
  }
  buttonFeedback(button, "fail");
  toast("Execution failed.", "err");
  log(`Error${label ? ` running ${label}` : ""}: ${r?.error || "unknown"}`, "err");
  return false;
}

function injectButton() { return $("#btn-inject"); }

function stopInjectWatch() {
  clearTimeout(injectWatch);
  injectWatch = 0;
  injectButton()?.classList.remove("loading");
}

function holdFor(secs) {
  const btn = injectButton();
  const label = btn?.querySelector(".btn-label");
  state.injectHoldUntil = Date.now() + secs * 1000;
  clearInterval(holdTimer);
  const tick = () => {
    const left = Math.ceil((state.injectHoldUntil - Date.now()) / 1000);
    if (left <= 0) {
      clearInterval(holdTimer);
      state.injectHoldUntil = 0;
      if (label) label.textContent = "Inject";
      if (btn) btn.disabled = !canInject();
      return;
    }
    if (label) label.textContent = `Wait ${left}s`;
    if (btn) btn.disabled = true;
  };
  tick();
  holdTimer = setInterval(tick, 250);
}

export function injectBusy() {
  return !!injectWatch || (state.injectHoldUntil || 0) > Date.now();
}

export async function inject() {
  const btn = injectButton();
  if (!canInject()) {
    if (state.pids.length) toast("Byte is already attached.", "info");
    else if (!state.robloxPids.length) toast("Start Roblox first, then inject.", "warn");
    else if (!state.injectorAvailable) toast("Byte-Injector.exe was not found next to Byte.exe.", "err", 4200);
    shake(btn);
    return;
  }
  if (injectBusy()) return;
  btn.classList.add("loading");
  btn.disabled = true;
  log("Injecting Byte into Roblox…", "info");
  const r = await bridgePost("/inject");
  if (r?.ok) {
    if (r.note === "already attached") { stopInjectWatch(); return; }
    log("Injector started. Waiting for attach.", "ok");
    toast("Injecting…", "info", 1800);

    injectWatch = setTimeout(() => {
      stopInjectWatch();
      btn.disabled = !canInject();
      toast("No attach detected yet. Check the injector window.", "warn", 4500);
      log("No attach detected within 25s.", "warn");
    }, INJECT_WATCH_MS);
    return;
  }
  btn.classList.remove("loading");
  if (r?.tooEarly) {
    toast(r.error || "Roblox is still starting up.", "warn", 3400);
    log(r.error || "Too early.", "warn");
    holdFor(Number(r.waitSeconds) || 5);
    return;
  }
  btn.disabled = !canInject();
  buttonFeedback(btn, "fail");
  toast(`Inject failed: ${r?.error || "unknown"}`, "err");
  log(`Error: ${r?.error || "unknown"}`, "err");
}

export async function killRoblox() {
  const ok = await confirmDialog({
    title: "Force-close Roblox?",
    message: "Every running Roblox process will be terminated. Unsaved progress in game is lost.",
    confirmLabel: "Close Roblox",
    danger: true,
    iconName: "power"
  });
  if (!ok) return;
  const r = await bridgePost("/kill-roblox");
  if (r?.ok) {
    const n = r.killed | 0;
    toast(n ? `Closed ${n} Roblox process${n > 1 ? "es" : ""}.` : "No Roblox process was running.", n ? "ok" : "warn");
    log(`Force-closed ${n} Roblox process(es).`, "warn");
  } else {
    toast("Could not close Roblox.", "err");
  }
}

export async function openUrl(url) {
  const r = await bridgePost("/open-url", { url });
  if (!r?.ok) toast("Could not open the browser.", "err");
  return !!r?.ok;
}

export async function launchSupportedRoblox(btn = null) {
  if (btn) btn.classList.add("loading");
  const hash = getActiveLaunchHash();
  toast(`Launching supported Roblox (${hash})…`, "info", 2000);
  log(`Launching supported Roblox version: ${hash}`, "info");
  const r = await bridgePost("/launch-roblox", { hash });
  if (btn) btn.classList.remove("loading");
  if (r?.ok) {
    toast(`Roblox launched (${r.target || hash}).`, "ok", 3000);
    log(`Roblox launched successfully (${r.target || hash}).`, "ok");
  } else {
    toast(`Launch failed: ${r?.error || "unable to launch"}`, "err", 3500);
    log(`Launch failed: ${r?.error || "unknown"}`, "err");
  }
}

export const openDiscord = () => openUrl(DISCORD_INVITE);

export function initActions() {
  on("attach", () => {
    if (!injectWatch) return;
    const btn = injectButton();
    stopInjectWatch();
    buttonFeedback(btn, "success", 900);
  });
}
