import { $, formatBytes } from "./dom.js";
import { state, canInject, DISCORD_INVITE } from "./state.js";
import { bridgePost, bridgePostRaw, bridgeGet, isStandalone } from "./bridge.js";
import { log } from "./console.js";
import { toast } from "./toast.js";
import { buttonFeedback, shake } from "./fx.js";
import { confirmDialog } from "./dialog.js";
import { on } from "./bus.js";
import { getActiveLaunchHash } from "./versions.js";

const INJECT_WATCH_MS = 25000;
let injectWatch = 0;
let holdTimer = 0;

export async function runScript(src, { label = null, button = null } = {}) {
  if (!src || !src.trim()) {
    toast("Nothing to execute.", "warn");
    shake(button);
    return false;
  }
  if (!state.activePid) {
    if (isStandalone) {
      state.activePid = 1337;
      state.pids = [1337];
    } else {
      toast("No Roblox attached.", "err", 3200, canInject() ? { action: { label: "Inject", run: () => inject() } } : {});
      shake(button);
      return false;
    }
  }
  if (button) { button.classList.add("loading"); button.disabled = true; }
  const bytes = new TextEncoder().encode(src).length;
  log(label ? `Running ${label}` : `Executing ${formatBytes(bytes)} on PID ${state.activePid}`, "info");
  const r = await bridgePostRaw("/execute", src);
  if (button) { button.classList.remove("loading"); button.disabled = false; }
  if (r?.ok) {
    import("./home.js").then((m) => {
      m.recordRecent({ name: label || "Executed Script", content: src });
    }).catch(() => {});
    buttonFeedback(button, "success");
    toast(label ? `Executed ${label}.` : "Script executed.", "ok", 1600);
    log(label ? `${label} executed.` : "Executed.", "ok");
    return true;
  }
  buttonFeedback(button, "fail");
  toast("Execution failed.", "err");
  log(`Error${label ? ` running ${label}` : ""}: ${r?.error || "unknown"}`, "err");
  return false;
}

function injectButton() { return $("#btn-inject"); }

function stopInjectWatch() {
  clearTimeout(injectWatch);
  injectWatch = 0;
  injectButton()?.classList.remove("loading");
}

function holdFor(secs) {
  const btn = injectButton();
  const label = btn?.querySelector(".btn-label");
  state.injectHoldUntil = Date.now() + secs * 1000;
  clearInterval(holdTimer);
  const tick = () => {
    const left = Math.ceil((state.injectHoldUntil - Date.now()) / 1000);
    if (left <= 0) {
      clearInterval(holdTimer);
      state.injectHoldUntil = 0;
      if (label) label.textContent = "Inject";
      if (btn) btn.disabled = !canInject();
      return;
    }
    if (label) label.textContent = `Wait ${left}s`;
    if (btn) btn.disabled = true;
  };
  tick();
  holdTimer = setInterval(tick, 250);
}

export function injectBusy() {
  return !!injectWatch || (state.injectHoldUntil || 0) > Date.now();
}

export async function inject() {
  // In the current UI there is no visible #btn-inject — inject() is reached
  // from the menu bar, keyboard shortcut and command palette. Treat the
  // button handle as optional throughout so a missing element doesn't throw.
  const btn = injectButton();
  if (!canInject()) {
    if (state.pids.length) toast("Byte is already attached.", "info");
    else if (!state.robloxPids.length) toast("Start Roblox first, then inject.", "warn");
    else if (!state.injectorAvailable) toast("Byte-Injector.exe was not found next to Byte.exe.", "err", 4200);
    shake(btn);
    return;
  }
  if (injectBusy()) return;
  if (btn) { btn.classList.add("loading"); btn.disabled = true; }
  log("Injecting Byte into Roblox…", "info");
  const r = await bridgePost("/inject");
  if (r?.ok) {
    if (r.note === "already attached") { stopInjectWatch(); return; }
    log("Injector started. Waiting for attach.", "ok");
    toast("Injecting…", "info", 1800);

    injectWatch = setTimeout(() => {
      stopInjectWatch();
      if (btn) btn.disabled = !canInject();
      toast("No attach detected yet. Check the injector window.", "warn", 4500);
      log("No attach detected within 25s.", "warn");
    }, INJECT_WATCH_MS);
    return;
  }
  if (btn) btn.classList.remove("loading");
  if (r?.tooEarly) {
    toast(r.error || "Roblox is still starting up.", "warn", 3400);
    log(r.error || "Too early.", "warn");
    holdFor(Number(r.waitSeconds) || 5);
    return;
  }
  if (btn) btn.disabled = !canInject();
  buttonFeedback(btn, "fail");
  toast(`Inject failed: ${r?.error || "unknown"}`, "err");
  log(`Error: ${r?.error || "unknown"}`, "err");
}

export async function killRoblox() {
  const ok = await confirmDialog({
    title: "Force-close Roblox?",
    message: "Every running Roblox process will be terminated. Unsaved progress in game is lost.",
    confirmLabel: "Close Roblox",
    danger: true,
    iconName: "power"
  });
  if (!ok) return;
  const r = await bridgePost("/kill-roblox");
  if (r?.ok) {
    const n = r.killed | 0;
    toast(n ? `Closed ${n} Roblox process${n > 1 ? "es" : ""}.` : "No Roblox process was running.", n ? "ok" : "warn");
    log(`Force-closed ${n} Roblox process(es).`, "warn");
  } else {
    toast("Could not close Roblox.", "err");
  }
}

export async function openUrl(url) {
  const r = await bridgePost("/open-url", { url });
  if (!r?.ok) toast("Could not open the browser.", "err");
  return !!r?.ok;
}

async function resolveSupportedHash() {
  // 1) Cache from the Versions tab, if it ran at least once.
  const cached = getActiveLaunchHash();
  if (cached) return cached;

  // 2) Query /versions a few times — the first call right after Byte's boot
  // can lose a race against the native server's own init or a cold upstream
  // fetch to clientsettings.roblox.com. Long timeout + two retries covers it.
  for (let attempt = 0; attempt < 3; attempt++) {
    const v = await bridgeGet("/versions", { timeout: 15000 });
    // Prefer liveHash (newest Roblox on disk) over supportedHash — the latter
    // can lag behind when Byte's native supported-pin hasn't been bumped yet
    // but Module.dll has been rebuilt for the live version.
    if (v?.liveHash) return v.liveHash;
    if (v?.supportedHash) return v.supportedHash;
    // Fallback: any installed version flagged live, then supported.
    const live = v?.versions?.find((e) => e?.isLive);
    if (live?.hash) return live.hash;
    const supported = v?.versions?.find((e) => e?.isSupported || e?.status === "supported");
    if (supported?.hash) return supported.hash;
    await new Promise((res) => setTimeout(res, 500 * (attempt + 1)));
  }
  return "";
}

async function waitForRobloxUp(timeoutMs = 15000) {
  // Poll /status until a Roblox PID appears or we time out. Returns true if
  // Roblox was observed. Byte restarts cleanly only after Roblox is up,
  // otherwise the relaunched Byte comes back to an idle state.
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const s = await bridgeGet("/status");
    if (s && (s.robloxPids?.length || s.pids?.length)) return true;
    await new Promise((res) => setTimeout(res, 400));
  }
  return false;
}

export async function launchSupportedRoblox(btn = null) {
  // Resolve the supported hash from the Versions cache, or fetch it directly
  // if the cache isn't populated yet. The native /launch-roblox handler
  // refuses with `missing_hash` on an empty body — this is the fix for that.
  const hash = await resolveSupportedHash();
  if (!hash) {
    toast("Launch failed: no supported Roblox version resolved yet. Open Versions and retry.", "err", 4000);
    log("Launch failed: supportedHash unavailable (bridge did not return a version).", "err");
    return;
  }

  log(`Launching Roblox ${hash}`, "info");
  toast("Launching Roblox…", "info", 1500);

  if (btn) {
    btn.classList.add("loading");
    setTimeout(() => btn.classList.remove("loading"), 180);
  }

  let r;
  try {
    r = await bridgePost("/launch-roblox", { hash });
  } catch (e) {
    toast(`Launch failed: ${e?.message || e}`, "err", 3500);
    log(`Launch error: ${e?.message || e}`, "err");
    return;
  }

  if (!r?.ok) {
    toast(`Launch failed: ${r?.error || "unable to launch"}`, "err", 3500);
    log(`Launch failed: ${r?.error || "unknown"}`, "err");
    return;
  }

  // Burst-poll /status so the chip flips to "Roblox detected" within ~200 ms
  // of the process appearing, not up to 1.5 s on the next tick.
  import("./status.js").then((m) => {
    [200, 500, 900, 1400, 2200, 3200].forEach((d) => setTimeout(() => m.pollStatus(), d));
  }).catch(() => {});

  // Then relaunch Byte so it re-attaches cleanly against the new Roblox.
  // Wait for Roblox to actually appear first — restarting Byte before Roblox
  // is up just brings it back to the same idle state.
  const up = await waitForRobloxUp(15000);
  if (!up) {
    log("Roblox did not appear within 15s; skipping Byte restart.", "warn");
    return;
  }
  toast("Relaunching Byte…", "info", 2000);
  log("Relaunching Byte to attach to the new Roblox.", "info");
  try {
    await bridgePost("/update/restart");
  } catch (e) {
    log(`Byte restart request failed: ${e?.message || e}`, "warn");
  }
}

export const openDiscord = () => openUrl(DISCORD_INVITE);

export function initActions() {
  on("attach", () => {
    if (!injectWatch) return;
    const btn = injectButton();
    stopInjectWatch();
    buttonFeedback(btn, "success", 900);
  });
}
