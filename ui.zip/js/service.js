/* Executor / Byte External health in the statusbar. The host reads the
   *_status fields of api.projectbyte.cc/version and answers /service/status
   with "up" | "down" | "unknown" per product. The manifest is CDN-cached for
   a minute, so polling faster than every few minutes buys nothing. */

import { $ } from "./dom.js";
import { bridgeGet } from "./bridge.js";

const POLL_MS = 5 * 60 * 1000;

const PRODUCTS = [
  { key: "executor", el: "#sb-svc-executor", name: "Executor" },
  { key: "external", el: "#sb-svc-external", name: "Byte External" },
];

const LABEL = { up: "Up", down: "Down", unknown: "Unknown" };

function tipFor(name, status) {
  if (status === "up") return `${name} is working`;
  if (status === "down") return `${name} is down. Expect issues until a fix ships.`;
  return `${name} status unavailable`;
}

function render({ el, name }, status) {
  const item = $(el);
  if (!item) return;
  const s = LABEL[status] ? status : "unknown";
  item.querySelector(".svc-dot").className = `svc-dot ${s}`;
  item.querySelector(".v").textContent = LABEL[s];
  item.classList.toggle("svc-down", s === "down");
  item.dataset.tip = tipFor(name, s);
}

export async function pollServiceStatus() {
  // the host makes an HTTPS round trip to the API, so allow more than the default
  const r = await bridgeGet("/service/status", { timeout: 20000 });
  for (const p of PRODUCTS) render(p, r?.[p.key]);
}

export function startServiceStatus() {
  pollServiceStatus();
  setInterval(pollServiceStatus, POLL_MS);
}
