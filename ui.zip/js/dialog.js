import { $, focusables, icon } from "./dom.js";
import { reducedMotion } from "./motion.js";
import { state } from "./state.js";
import { hideTooltip } from "./tooltip.js";

const stack = [];

export function syncInert() {
  const app = $("#app");
  const titlebar = $("#titlebar");
  if (app) app.inert = stack.length > 0 || state.gateOpen;

  if (titlebar) titlebar.inert = stack.length > 0;
}

export function isOverlayOpen() {
  return stack.length > 0;
}

function trap(e, overlay) {
  if (e.key !== "Tab") return;
  const items = focusables(overlay);
  if (!items.length) { e.preventDefault(); return; }
  const first = items[0];
  const last = items[items.length - 1];
  const active = document.activeElement;
  if (!overlay.contains(active)) { e.preventDefault(); first.focus(); return; }
  if (e.shiftKey && active === first) { e.preventDefault(); last.focus(); }
  else if (!e.shiftKey && active === last) { e.preventDefault(); first.focus(); }
}

export function openOverlay(overlay, { initialFocus = null, onClose = null, dismissible = true } = {}) {
  if (!overlay || stack.some((s) => s.overlay === overlay)) return;
  hideTooltip();
  const entry = { overlay, prevFocus: document.activeElement, onClose, dismissible, cleanup: null };

  const onKey = (e) => {
    if (e.key === "Escape" && entry.dismissible) {
      e.preventDefault();
      e.stopPropagation();
      closeOverlay(overlay, "escape");
      return;
    }
    trap(e, overlay);
  };
  const onDown = (e) => {
    if (e.target === overlay && entry.dismissible) closeOverlay(overlay, "backdrop");
  };
  const onClick = (e) => {
    if (e.target.closest("[data-close]")) closeOverlay(overlay, "close");
  };
  overlay.addEventListener("keydown", onKey);
  overlay.addEventListener("pointerdown", onDown);
  overlay.addEventListener("click", onClick);
  entry.cleanup = () => {
    overlay.removeEventListener("keydown", onKey);
    overlay.removeEventListener("pointerdown", onDown);
    overlay.removeEventListener("click", onClick);
  };

  overlay.classList.remove("closing");
  overlay.hidden = false;
  stack.push(entry);
  syncInert();

  const target = initialFocus || focusables(overlay)[0];
  requestAnimationFrame(() => target?.focus({ preventScroll: true }));
}

export function closeOverlay(overlay, reason = "close") {
  const idx = stack.findIndex((s) => s.overlay === overlay);
  if (idx === -1) return;
  const [entry] = stack.splice(idx, 1);
  entry.cleanup?.();

  const finish = () => {
    overlay.hidden = true;
    overlay.classList.remove("closing");
  };
  if (reducedMotion()) finish();
  else {
    overlay.classList.add("closing");
    setTimeout(finish, 80);
  }
  syncInert();
  const prev = entry.prevFocus;
  if (prev && prev.isConnected && typeof prev.focus === "function") {
    requestAnimationFrame(() => prev.focus({ preventScroll: true }));
  }
  entry.onClose?.(reason);
}

export function closeTopOverlay() {
  const top = stack[stack.length - 1];
  if (top && top.dismissible) closeOverlay(top.overlay, "escape");
}

// confirmDialog resolves to one of three values:
//   true          — primary (ok) clicked
//   false         — cancel clicked / dismissed via Escape or backdrop
//   "alt"         — the optional secondary action (altLabel) clicked
// Pass `altLabel` to show the extra button; omit it for the normal two-button
// yes/no behaviour.
export function confirmDialog({
  title,
  message,
  confirmLabel = "Confirm",
  cancelLabel = "Cancel",
  altLabel = null,
  danger = false,
  iconName = "warn",
}) {
  const overlay = $("#confirm");
  const ok = $("#confirm-ok");
  const cancel = $("#confirm-cancel");
  const alt = $("#confirm-alt");
  $("#confirm-title").textContent = title;
  $("#confirm-msg").textContent = message;
  ok.textContent = confirmLabel;
  ok.className = `btn ${danger ? "danger" : "primary"}`;
  cancel.textContent = cancelLabel;
  if (altLabel) {
    alt.textContent = altLabel;
    alt.hidden = false;
  } else {
    alt.hidden = true;
    alt.textContent = "";
  }
  const ic = $("#confirm-ic");
  ic.className = `dlg-ic${danger ? " danger" : ""}`;
  ic.innerHTML = icon(iconName);

  return new Promise((resolve) => {
    let settled = false;
    const settle = (v) => {
      if (settled) return;
      settled = true;
      ok.removeEventListener("click", onOk);
      cancel.removeEventListener("click", onCancel);
      alt.removeEventListener("click", onAlt);
      resolve(v);
    };
    const onOk = () => { settle(true); closeOverlay(overlay, "confirm"); };
    const onCancel = () => closeOverlay(overlay, "cancel");
    const onAlt = () => { settle("alt"); closeOverlay(overlay, "alt"); };
    ok.addEventListener("click", onOk);
    cancel.addEventListener("click", onCancel);
    alt.addEventListener("click", onAlt);

    openOverlay(overlay, { initialFocus: danger ? cancel : ok, onClose: () => settle(false) });
  });
}
