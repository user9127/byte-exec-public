export const LUAU_DOCS = {
  print: {
    sig: "print(...: any): ()",
    desc: "Prints all provided values to the console output, separated by spaces and terminated with a newline.",
    example: 'print("Hello, Luau!", 123, true)'
  },
  warn: {
    sig: "warn(...: any): ()",
    desc: "Emits a warning message with yellow text to the output window. Automatically includes timestamp and callsite origin.",
    example: 'warn("Warning: asset could not be loaded!")'
  },
  error: {
    sig: "error(message: string, level?: number): never",
    desc: "Terminates execution of the current thread and raises a runtime error. The optional level indicates the stack call level.",
    example: 'error("Critical assertion failure", 2)'
  },
  assert: {
    sig: "assert<T>(condition: T, message?: string): T",
    desc: "Asserts that condition is truthy (not nil or false). If false, raises an error with the given message; otherwise returns condition.",
    example: 'local player = assert(game:GetService("Players").LocalPlayer, "LocalPlayer not found")'
  },
  pcall: {
    sig: "pcall<T...>(fn: (...any) -> T..., ...: any): (boolean, any)",
    desc: "Calls the function in protected mode. Catches any runtime errors without crashing the thread. Returns true followed by results, or false followed by error.",
    example: 'local success, result = pcall(function()\n    return game:GetService("HttpService"):GetAsync("https://example.com")\nend)'
  },
  xpcall: {
    sig: "xpcall<T...>(fn: (...any) -> T..., errHandler: (err: any) -> any, ...: any): (boolean, any)",
    desc: "Protected call with a custom error handler function. Catches errors before the call stack is unwound.",
    example: 'local success, res = xpcall(f, function(err)\n    return debug.traceback(err)\nend)'
  },
  typeof: {
    sig: "typeof(val: any): string",
    desc: "Returns the Luau/Roblox native type name, including engine types like 'Vector3', 'CFrame', 'Instance', 'Color3', etc.",
    example: 'if typeof(target) == "Instance" then ... end'
  },
  type: {
    sig: "type(val: any): string",
    desc: "Returns the standard Lua primitive type name: 'nil', 'number', 'string', 'boolean', 'table', 'function', 'thread', or 'userdata'.",
    example: 'print(type(100)) -- "number"'
  },
  tostring: {
    sig: "tostring(val: any): string",
    desc: "Converts any given value into its string representation. Invokes the __tostring metamethod if defined.",
    example: 'local s = tostring(workspace.CurrentCamera)'
  },
  tonumber: {
    sig: "tonumber(str: any, base?: number): number?",
    desc: "Converts a string to a number in the optional base (2 to 36). Returns nil if conversion fails.",
    example: 'local n = tonumber("1010", 2) -- 10'
  },
  select: {
    sig: "select(index: number | '#', ...: any): any",
    desc: "If index is '#', returns the count of subsequent arguments. If a number n, returns all arguments starting from position n.",
    example: 'local count = select("#", 1, 2, 3) -- 3'
  },
  unpack: {
    sig: "unpack(list: {any}, i?: number, j?: number): ...any",
    desc: "Unpacks elements from an array table as multiple return values. Supports start index i and end index j.",
    example: 'local a, b = unpack({10, 20})'
  },
  setmetatable: {
    sig: "setmetatable<T>(tab: T, metatable: table?): T",
    desc: "Sets the metatable for the given table and returns it. Used for OOP inheritance and operator overloading.",
    example: 'local obj = setmetatable({}, { __index = Class })'
  },
  getmetatable: {
    sig: "getmetatable(tab: table): table?",
    desc: "Returns the metatable of the given table. If the metatable has a protected __metatable field, returns that value.",
    example: 'local mt = getmetatable(obj)'
  },
  rawget: {
    sig: "rawget(tab: table, key: any): any",
    desc: "Gets the value of key in tab directly without invoking any __index metamethod.",
    example: 'local val = rawget(tab, "key")'
  },
  rawset: {
    sig: "rawset(tab: table, key: any, val: any): table",
    desc: "Sets the value of key in tab directly without invoking any __newindex metamethod.",
    example: 'rawset(tab, "secret", 123)'
  },
  rawequal: {
    sig: "rawequal(v1: any, v2: any): boolean",
    desc: "Compares two values for equality directly without invoking the __eq metamethod.",
    example: 'if rawequal(a, b) then ... end'
  },
  require: {
    sig: "require(module: ModuleScript | number): any",
    desc: "Executes and returns the exported result of a ModuleScript. Results are cached after first execution.",
    example: 'local Maid = require(ReplicatedStorage.Packages.Maid)'
  },

  "task.wait": {
    sig: "task.wait(duration?: number): number",
    desc: "Yields the current thread until the specified duration (in seconds) has passed. Returns actual elapsed time. Accurate to engine frame rate.",
    example: 'local dt = task.wait(0.5)'
  },
  "task.spawn": {
    sig: "task.spawn(fn: (...any) -> (), ...: any): thread",
    desc: "Immediately resumes or runs a new thread within the current frame scheduler budget and passes arguments.",
    example: 'task.spawn(function(name)\n    print("Hello", name)\nend, "Byte")'
  },
  "task.defer": {
    sig: "task.defer(fn: (...any) -> (), ...: any): thread",
    desc: "Defers execution of the function to the end of the current frame or next resumption cycle.",
    example: 'task.defer(function()\n    print("Deferred task")\nend)'
  },
  "task.delay": {
    sig: "task.delay(duration: number, fn: (...any) -> (), ...: any): thread",
    desc: "Schedules a function to run after duration seconds have elapsed.",
    example: 'task.delay(2.0, function()\n    print("Executed after 2s")\nend)'
  },
  "task.cancel": {
    sig: "task.cancel(t: thread): ()",
    desc: "Cancels and terminates a scheduled thread created with task.delay or task.defer.",
    example: 'local t = task.delay(5, fn)\ntask.cancel(t)'
  },

  "table.insert": {
    sig: "table.insert(t: {any}, [pos: number,] value: any): ()",
    desc: "Inserts an element into an array table at the given position. Defaults to the end of the table if pos is omitted.",
    example: 'table.insert(items, "apple")'
  },
  "table.remove": {
    sig: "table.remove(t: {any}, pos?: number): any",
    desc: "Removes and returns the element at pos from an array table. Defaults to removing the last element if pos is omitted.",
    example: 'local item = table.remove(items, 1)'
  },
  "table.find": {
    sig: "table.find(t: {any}, value: any, init?: number): number?",
    desc: "Finds the first occurrence of value in an array table starting from init. Returns index or nil.",
    example: 'local idx = table.find(names, "Alice")'
  },
  "table.clear": {
    sig: "table.clear(t: table): ()",
    desc: "Clears all keys and values from a table while retaining internal memory allocation capacity for reuse.",
    example: 'table.clear(cache)'
  },
  "table.clone": {
    sig: "table.clone<T>(t: T): T",
    desc: "Creates a fast shallow copy of the given table. Implemented natively in Luau.",
    example: 'local copy = table.clone(config)'
  },
  "table.freeze": {
    sig: "table.freeze<T>(t: T): T",
    desc: "Freezes a table, making it completely read-only. Any attempt to modify it will throw a runtime error.",
    example: 'local Consts = table.freeze({ Version = "1.0" })'
  },
  "table.sort": {
    sig: "table.sort<T>(t: {T}, comp?: (a: T, b: T) -> boolean): ()",
    desc: "Sorts the elements of an array in-place. An optional comparator function can be provided.",
    example: 'table.sort(list, function(a, b) return a > b end)'
  },
  "table.concat": {
    sig: "table.concat(t: {any}, sep?: string, i?: number, j?: number): string",
    desc: "Concatenates all elements in table from index i to j into a single string separated by sep.",
    example: 'local csv = table.concat(tokens, ", ")'
  },

  "string.format": {
    sig: "string.format(fmt: string, ...: any): string",
    desc: "Formats a string following standard printf format specifications (e.g., %s, %d, %f).",
    example: 'string.format("Player %s: %d HP", name, hp)'
  },
  "string.split": {
    sig: "string.split(s: string, sep?: string): {string}",
    desc: "Splits a string into a table of substrings divided by the separator sep (defaults to comma ',').",
    example: 'local parts = string.split("a/b/c", "/")'
  },
  "string.sub": {
    sig: "string.sub(s: string, i: number, j?: number): string",
    desc: "Extracts a substring from index i to j (inclusive). Supports negative indices from the end.",
    example: 'local sub = string.sub(str, 1, 4)'
  },
  "string.find": {
    sig: "string.find(s: string, pattern: string, init?: number, plain?: boolean): (number?, number?)",
    desc: "Searches for a pattern match in the string. Returns the start and end indices if found, or nil.",
    example: 'local startPos, endPos = string.find(str, "test")'
  },
  "string.gsub": {
    sig: "string.gsub(s: string, pattern: string, repl: any, n?: number): (string, number)",
    desc: "Replaces all occurrences of the pattern with repl. Returns the resulting string and total replacements.",
    example: 'local clean = string.gsub(raw, "%s+", " ")'
  },

  "math.clamp": {
    sig: "math.clamp(n: number, min: number, max: number): number",
    desc: "Clamps a number between min and max boundaries. Returns min if n < min, and max if n > max.",
    example: 'local health = math.clamp(hp, 0, 100)'
  },
  "math.round": {
    sig: "math.round(n: number): number",
    desc: "Rounds a number to the nearest integer.",
    example: 'local r = math.round(3.5) -- 4'
  },
  "math.random": {
    sig: "math.random(m?: number, n?: number): number",
    desc: "Generates a pseudo-random number. Without arguments, returns [0, 1). With arguments, returns [m, n].",
    example: 'local roll = math.random(1, 6)'
  },

  "Instance.new": {
    sig: "Instance.new(className: string, parent?: Instance): Instance",
    desc: "Instantiates a new Roblox object of the specified ClassName. Optionally parents the new Instance.",
    example: 'local part = Instance.new("Part")\npart.Size = Vector3.new(4, 1, 2)\npart.Parent = workspace'
  },

  game: {
    sig: "game: DataModel",
    desc: "Root Instance of the Roblox hierarchy (DataModel). Provides access to services via GetService.",
    example: 'local Players = game:GetService("Players")'
  },
  workspace: {
    sig: "workspace: Workspace",
    desc: "Root 3D physical world container. Equivalent to game:GetService('Workspace') or game.Workspace.",
    example: 'local cam = workspace.CurrentCamera'
  },
  script: {
    sig: "script: LuaSourceContainer",
    desc: "Reference to the currently running script object itself.",
    example: 'local parent = script.Parent'
  },

  getgenv: {
    sig: "getgenv(): table",
    desc: "Returns the global environment table shared across all scripts in the executor runtime.",
    example: 'getgenv().Config = { Enabled = true }'
  },
  loadstring: {
    sig: "loadstring(chunk: string, chunkName?: string): (function?, string?)",
    desc: "Dynamically compiles a Luau/Lua source code string into an executable closure.",
    example: 'local fn, err = loadstring(\'print("Dynamic code")\')\nif fn then fn() end'
  },
  identifyexecutor: {
    sig: "identifyexecutor(): (string, string)",
    desc: "Returns the name and version string of the active executor environment.",
    example: 'local name, ver = identifyexecutor()'
  }
};

export function registerLuauLanguage(monaco) {
  if (monaco.languages.getLanguages().some((l) => l.id === "luau")) return;

  monaco.languages.register({
    id: "luau",
    extensions: [".luau", ".lua"],
    aliases: ["Luau", "luau", "Lua"],
    mimetypes: ["text/x-luau", "text/x-lua"]
  });

  monaco.languages.setLanguageConfiguration("luau", {
    comments: {
      lineComment: "--",
      blockComment: ["--[[", "]]"]
    },
    brackets: [
      ["{", "}"],
      ["[", "]"],
      ["(", ")"]
    ],
    autoClosingPairs: [
      { open: "{", close: "}" },
      { open: "[", close: "]" },
      { open: "(", close: ")" },
      { open: '"', close: '"' },
      { open: "'", close: "'" },
      { open: "`", close: "`" }
    ],
    surroundingPairs: [
      { open: "{", close: "}" },
      { open: "[", close: "]" },
      { open: "(", close: ")" },
      { open: '"', close: '"' },
      { open: "'", close: "'" },
      { open: "`", close: "`" }
    ],
    indentationRules: {
      increaseIndentPattern:
        /^\s*(?:function|then|do|repeat|else|elseif)\b|^.*\b(?:function\s*\(|then|do)\s*$|.*\{\s*$/,
      decreaseIndentPattern: /^\s*(?:end|until|else|elseif|\})\b/
    }
  });

  monaco.languages.setMonarchTokensProvider("luau", {
    defaultToken: "",
    tokenPostfix: ".luau",

    keywords: [
      "and", "break", "do", "else", "elseif", "end", "false", "for", "function",
      "if", "in", "local", "nil", "not", "or", "repeat", "return", "then",
      "true", "until", "while", "continue", "type", "export", "typeof"
    ],

    types: [
      "any", "boolean", "number", "string", "thread", "buffer", "table", "nil", "never", "unknown"
    ],

    robloxGlobals: [
      "game", "workspace", "script", "shared", "_G", "_VERSION", "Enum",
      "task", "table", "string", "math", "buffer", "bit32", "coroutine", "os", "debug",
      "Instance", "Vector3", "Vector2", "CFrame", "Color3", "UDim2", "UDim", "Ray",
      "TweenInfo", "BrickColor", "NumberRange", "NumberSequence", "ColorSequence",
      "getgenv", "loadstring", "identifyexecutor", "hookfunction", "newcclosure"
    ],

    operators: [
      "+", "-", "*", "/", "//", "%", "^", "#", "==", "~=", "<=", ">=", "<", ">",
      "=", "+=", "-=", "*=", "/=", "//=", "%=", "^=", "..=", "::", "..", "..."
    ],

    tokenizer: {
      root: [
        [/--\[([=]*)\[/, "comment", "@blockComment"],
        [/--.*$/, "comment"],
        [/`/, "string.template", "@templateString"],
        [/"([^"\\]|\\.)*$/, "string.invalid"],
        [/'([^'\\]|\\.)*$/, "string.invalid"],
        [/"/, "string", '@string."'],
        [/'/, "string", "@string.'"],
        [/\[([=]*)\[/, "string", "@longBracketString"],
        [/0[xX][0-9a-fA-F]+/, "number.hex"],
        [/0[bB][01]+/, "number.binary"],
        [/\d+(\.\d+)?([eE][\-+]?\d+)?/, "number"],
        [
          /[a-zA-Z_]\w*/,
          {
            cases: {
              "@keywords": "keyword",
              "@types": "type",
              "@robloxGlobals": "keyword.global",
              "@default": "identifier"
            }
          }
        ],
        [/[{}()\[\]]/, "delimiter.bracket"],
        [/[;,]/, "delimiter"],
        [/::/, "operator.typecast"],
        [
          /[+\-*\/%^#=~<>]+/,
          {
            cases: {
              "@operators": "operator",
              "@default": ""
            }
          }
        ]
      ],

      blockComment: [
        [/\]([=]*)\]/, { cases: { "$1==$S2": { token: "comment", next: "@pop" }, "@default": "comment" } }],
        [/./, "comment"]
      ],

      templateString: [
        [/\{/, { token: "delimiter.bracket", next: "@templateInterpolation" }],
        [/`/, { token: "string.template", next: "@pop" }],
        [/\\./, "string.escape"],
        [/./, "string.template"]
      ],

      templateInterpolation: [
        [/\}/, { token: "delimiter.bracket", next: "@pop" }],
        { include: "root" }
      ],

      string: [
        [/[^\\"']+/, "string"],
        [/\\./, "string.escape"],
        [/["']/, { cases: { "$#==$S2": { token: "string", next: "@pop" }, "@default": "string" } }]
      ],

      longBracketString: [
        [/\]([=]*)\]/, { cases: { "$1==$S2": { token: "string", next: "@pop" }, "@default": "string" } }],
        [/./, "string"]
      ]
    }
  });

  registerIntellisense(monaco);
}

function registerIntellisense(monaco) {
  const TARGET_LANGUAGES = ["luau", "lua"];

  const completionProvider = {
    triggerCharacters: [".", ":"],
    provideCompletionItems: (model, position) => {
      const line = model.getLineContent(position.lineNumber);
      const textBefore = line.substring(0, position.column - 1);
      const word = model.getWordUntilPosition(position);

      const range = {
        startLineNumber: position.lineNumber,
        endLineNumber: position.lineNumber,
        startColumn: word.startColumn,
        endColumn: position.column
      };

      const suggestions = [];

      const dotMatch = textBefore.match(/([a-zA-Z_]\w*)\.$/);
      if (dotMatch) {
        const parent = dotMatch[1];
        for (const [key, item] of Object.entries(LUAU_DOCS)) {
          if (key.startsWith(parent + ".")) {
            const member = key.substring(parent.length + 1);
            suggestions.push({
              label: member,
              filterText: member,
              kind: monaco.languages.CompletionItemKind.Method,
              insertText: member + "($1)",
              insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
              detail: item.sig,
              documentation: {
                value: `**${item.sig}**\n\n${item.desc}\n\n\`\`\`luau\n${item.example}\n\`\`\``
              },
              range
            });
          }
        }
        return { suggestions };
      }

      const colonMatch = textBefore.match(/([a-zA-Z_]\w*):$/);
      if (colonMatch) {
        const instanceMethods = [
          { name: "GetService", sig: "GetService(serviceName: string): Instance", snippet: 'GetService("${1:Players}")', doc: "Retrieves a specified Roblox singleton service." },
          { name: "FindFirstChild", sig: "FindFirstChild(name: string, recursive?: boolean): Instance?", snippet: 'FindFirstChild("${1:Name}")', doc: "Returns the first child matching the name." },
          { name: "WaitForChild", sig: "WaitForChild(name: string, timeout?: number): Instance", snippet: 'WaitForChild("${1:Name}")', doc: "Yields until the named child exists." },
          { name: "Destroy", sig: "Destroy(): ()", snippet: "Destroy()", doc: "Disconnects all connections and deletes the instance." },
          { name: "Clone", sig: "Clone(): Instance", snippet: "Clone()", doc: "Creates a duplicate copy of the instance." }
        ];
        for (const m of instanceMethods) {
          suggestions.push({
            label: m.name,
            filterText: m.name,
            kind: monaco.languages.CompletionItemKind.Method,
            insertText: m.snippet,
            insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
            detail: m.sig,
            documentation: { value: `**${m.sig}**\n\n${m.doc}` },
            range
          });
        }
        return { suggestions };
      }

      for (const [name, item] of Object.entries(LUAU_DOCS)) {
        if (!name.includes(".")) {
          suggestions.push({
            label: name,
            filterText: name,
            kind: monaco.languages.CompletionItemKind.Function,
            insertText: name + "($1)",
            insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
            detail: item.sig,
            documentation: {
              value: `### ${item.sig}\n\n${item.desc}\n\n**Example**:\n\`\`\`luau\n${item.example}\n\`\`\``
            },
            range
          });
        }
      }

      const snippets = [
        { label: "pcall", snippet: "local success, ${1:result} = pcall(function()\n\t$0\nend)", doc: "Protected call block (handles errors)" },
        { label: "fori", snippet: "for ${1:i}, ${2:v} in ${3:collection} do\n\t$0\nend", doc: "Generic for-in loop" },
        { label: "forn", snippet: "for ${1:i} = ${2:1}, ${3:10} do\n\t$0\nend", doc: "Numeric step loop" },
        { label: "func", snippet: "local function ${1:name}(${2:...})\n\t$0\nend", doc: "Local function declaration" },
        { label: "service", snippet: 'local ${1:Players} = game:GetService("${1:Players}")', doc: "Get Roblox singleton service" }
      ];

      for (const s of snippets) {
        suggestions.push({
          label: s.label,
          filterText: s.label,
          kind: monaco.languages.CompletionItemKind.Snippet,
          insertText: s.snippet,
          insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
          detail: "Code Snippet",
          documentation: { value: s.doc },
          range
        });
      }

      return { suggestions };
    }
  };

  const hoverProvider = {
    provideHover: (model, position) => {
      const word = model.getWordAtPosition(position);
      if (!word) return null;

      const line = model.getLineContent(position.lineNumber);
      const prefix = line.substring(0, word.startColumn - 1);
      const dotParent = prefix.match(/([a-zA-Z_]\w*)\.$/);

      let key = word.word;
      if (dotParent) {
        key = `${dotParent[1]}.${word.word}`;
      }

      const doc = LUAU_DOCS[key] || LUAU_DOCS[word.word];
      if (doc) {
        return {
          range: new monaco.Range(position.lineNumber, word.startColumn, position.lineNumber, word.endColumn),
          contents: [
            { value: `\`\`\`luau\n${doc.sig}\n\`\`\`` },
            { value: doc.desc },
            { value: `**Example**:\n\`\`\`luau\n${doc.example}\n\`\`\`` }
          ]
        };
      }
      return null;
    }
  };

  const signatureHelpProvider = {
    signatureHelpTriggerCharacters: ["(", ","],
    provideSignatureHelp: (model, position) => {
      const line = model.getLineContent(position.lineNumber);
      const prefix = line.substring(0, position.column - 1);
      const fnMatch = prefix.match(/([a-zA-Z_]\w*(?:\.[a-zA-Z_]\w*)?)\s*\([^\)]*$/);
      if (!fnMatch) return null;

      const fnName = fnMatch[1];
      const doc = LUAU_DOCS[fnName];
      if (!doc) return null;

      return {
        value: {
          signatures: [
            {
              label: doc.sig,
              documentation: doc.desc,
              parameters: [{ label: doc.sig }]
            }
          ],
          activeSignature: 0,
          activeParameter: 0
        },
        dispose: () => {}
      };
    }
  };

  for (const lang of TARGET_LANGUAGES) {
    monaco.languages.registerCompletionItemProvider(lang, completionProvider);
    monaco.languages.registerHoverProvider(lang, hoverProvider);
    monaco.languages.registerSignatureHelpProvider(lang, signatureHelpProvider);
  }
}
