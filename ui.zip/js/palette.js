import { $, icon, escapeHtml, highlightIndices, copyText } from "./dom.js";
import { kbdHtml } from "./tooltip.js";
import { openOverlay, closeOverlay } from "./dialog.js";
import { store } from "./store.js";
import { state, canInject } from "./state.js";
import { goToPage, toggleSidebar } from "./nav.js";
import { runScript, inject, killRoblox, openDiscord, launchSupportedRoblox } from "./actions.js";
import { currentScript, newTab, openFileDialog, saveActive, closeTab, getTabs, switchTab, renameActiveTab } from "./editor.js";
import { clearConsole } from "./console.js";
import { LIBRARY, runLibraryScript, openLibraryScript } from "./library.js";
import { checkUpdate } from "./update.js";
import { openShortcuts } from "./shortcuts.js";
import { toast } from "./toast.js";

const RECENT_KEY = "palette.recent";
let open = false;
let results = [];
let active = 0;

function commands() {
  const list = [
    { id: "page:execution", group: "Go to", title: "Workspace", icon: "code", kbd: "Ctrl+1", keywords: "editor code executor", run: () => goToPage("execution") },
    { id: "page:library", group: "Go to", title: "Script Hub", icon: "library", kbd: "Ctrl+2", keywords: "scripts loaders", run: () => goToPage("library") },
    { id: "page:versions", group: "Go to", title: "Versions", icon: "layers", kbd: "Ctrl+3", keywords: "versions weao hash release download launch supported", run: () => goToPage("versions") },
    { id: "page:settings", group: "Go to", title: "Setting", icon: "gear", kbd: "Ctrl+4", keywords: "preferences options settings", run: () => goToPage("settings") },
    { id: "page:console", group: "Go to", title: "Console", icon: "terminal", kbd: "Ctrl+`", keywords: "output logs", run: () => goToPage("console") },

    { id: "launch", group: "Actions", title: "Launch supported Roblox", icon: "play", keywords: "launch roblox start", run: () => launchSupportedRoblox() },

    { id: "run", group: "Actions", title: "Run script", icon: "play", kbd: "Ctrl+Enter", keywords: "execute", hint: state.activePid ? "" : "Not attached",
      run: () => { goToPage("execution"); runScript(currentScript(), { button: $("#btn-execute") }); } },
    { id: "inject", group: "Actions", title: "Inject into Roblox", icon: "inject", kbd: "Ctrl+Shift+Enter", keywords: "attach", hint: canInject() ? "" : state.pids.length ? "Attached" : "Roblox not ready", run: () => inject() },
    { id: "newtab", group: "Actions", title: "New tab", icon: "plus", kbd: "Ctrl+T", run: () => { goToPage("execution"); newTab(); } },
    { id: "open", group: "Actions", title: "Open file", icon: "folder", kbd: "Ctrl+O", keywords: "load import", run: () => { goToPage("execution"); openFileDialog(); } },
    { id: "save", group: "Actions", title: "Save to file", icon: "save", kbd: "Ctrl+S", keywords: "export download", run: () => saveActive() },
    { id: "rename", group: "Actions", title: "Rename tab", icon: "edit", kbd: "F2", run: () => { goToPage("execution"); requestAnimationFrame(renameActiveTab); } },
    { id: "closetab", group: "Actions", title: "Close tab", icon: "x", kbd: "Ctrl+W", run: () => closeTab() },
    { id: "clearconsole", group: "Actions", title: "Clear console", icon: "trash", kbd: "Ctrl+L", keywords: "output logs", run: () => clearConsole() },
    { id: "sidebar", group: "Actions", title: "Toggle sidebar", icon: "sidebar", kbd: "Ctrl+B", keywords: "compact collapse", run: () => toggleSidebar() },
    { id: "update", group: "Actions", title: "Check for updates", icon: "refresh", keywords: "version", run: () => { goToPage("settings"); checkUpdate(true); } },
    { id: "copykey", group: "Actions", title: "Copy license key", icon: "key", run: async () => {
        if (!state.licenseKey) { toast("No key to copy.", "warn"); return; }
        const ok = await copyText(state.licenseKey);
        toast(ok ? "License key copied." : "Clipboard access denied.", ok ? "ok" : "err", 1800);
      } },
    { id: "kill", group: "Actions", title: "Force-close Roblox", icon: "power", keywords: "kill terminate", run: () => killRoblox() },
    { id: "discord", group: "Actions", title: "Open Discord support", icon: "discord", keywords: "help", run: () => openDiscord() },
    { id: "shortcuts", group: "Actions", title: "Keyboard shortcuts", icon: "keyboard", kbd: "?", keywords: "keys help", run: () => openShortcuts() }
  ];

  for (const t of getTabs()) {
    list.push({ id: `tab:${t.id}`, group: "Open tabs", title: t.name, icon: "code", hint: t.active ? "Current" : "Switch", keywords: "tab", run: () => { goToPage("execution"); switchTab(t.id); } });
  }
  for (const s of LIBRARY) {
    list.push({ id: `run:${s.name}`, group: "Scripts", title: `Run ${s.name}`, mono: s.icon, hint: s.category === "byte" ? "Byte" : "Utility", keywords: s.desc, run: () => runLibraryScript(s) });
    list.push({ id: `openlib:${s.name}`, group: "Scripts", title: `Open ${s.name} in editor`, mono: s.icon, hint: "New tab", keywords: s.desc, run: () => openLibraryScript(s), searchOnly: true });
  }
  return list;
}

function fuzzy(q, text) {
  const t = text.toLowerCase();
  const sub = t.indexOf(q);
  if (sub !== -1) {
    const wordStart = sub === 0 || /[\s\-_.]/.test(t[sub - 1]);
    return { score: 1000 - sub * 3 - (t.length - q.length) + (wordStart ? 250 : 0), idx: Array.from({ length: q.length }, (_, i) => sub + i) };
  }
  let from = 0;
  let prev = -2;
  let score = 0;
  const idx = [];
  for (const ch of q) {
    if (ch === " ") continue;
    const f = t.indexOf(ch, from);
    if (f === -1) return null;
    idx.push(f);
    score += (f === prev + 1 ? 18 : 0) + (f === 0 || /[\s\-_.]/.test(t[f - 1]) ? 14 : 0) - (f - from);
    prev = f;
    from = f + 1;
  }
  return { score, idx };
}

function search(query) {
  const q = query.trim().toLowerCase();
  const all = commands();
  if (!q) {
    const recentIds = store.get(RECENT_KEY, []) || [];
    const recent = recentIds.map((id) => all.find((c) => c.id === id)).filter(Boolean).map((c) => ({ ...c, group: "Recent" }));
    const rest = all.filter((c) => !c.searchOnly && !recentIds.includes(c.id));
    return [...recent, ...rest].map((c) => ({ c, idx: [] }));
  }
  const out = [];
  for (const c of all) {
    const m = fuzzy(q, c.title);
    if (m) { out.push({ c, idx: m.idx, score: m.score }); continue; }
    if (c.keywords && c.keywords.toLowerCase().includes(q)) out.push({ c, idx: [], score: -50 });
  }
  return out.sort((a, b) => b.score - a.score).slice(0, 40);
}

function itemHtml(r, i, query) {
  const c = r.c;
  const ic = c.mono ? `<span class="pi-ic mono">${escapeHtml(c.mono)}</span>` : `<span class="pi-ic">${icon(c.icon || "chevron")}</span>`;
  const hint = query ? c.hint || c.group : c.hint;
  return `<div class="pal-item" role="option" id="pal-opt-${i}" data-i="${i}" aria-selected="false">
    ${ic}
    <span class="pi-title">${highlightIndices(c.title, r.idx)}</span>
    ${hint ? `<span class="pi-hint">${escapeHtml(hint)}</span>` : ""}
    ${c.kbd ? `<span class="pi-keys">${kbdHtml(c.kbd)}</span>` : ""}
  </div>`;
}

function render(query) {
  const list = $("#palette-list");
  results = search(query);
  active = 0;
  let html = "";
  let lastGroup = null;
  results.forEach((r, i) => {
    if (!query && r.c.group !== lastGroup) {
      html += `<div class="pal-group" role="presentation">${escapeHtml(r.c.group)}</div>`;
      lastGroup = r.c.group;
    }
    html += itemHtml(r, i, query);
  });
  if (!results.length) html = `<div class="pal-empty">No results for "${escapeHtml(query)}".</div>`;
  list.innerHTML = html;
  $("#palette-count").textContent = results.length ? `${results.length} result${results.length === 1 ? "" : "s"}` : "";
  list.scrollTop = 0;
  setActive(0);
}

function setActive(i, { scroll = true } = {}) {
  if (!results.length) { $("#palette-input").removeAttribute("aria-activedescendant"); return; }
  active = (i + results.length) % results.length;
  const list = $("#palette-list");
  list.querySelectorAll(".pal-item").forEach((el) => {
    const on = +el.dataset.i === active;
    el.classList.toggle("active", on);
    el.setAttribute("aria-selected", String(on));
  });
  const el = list.querySelector(`#pal-opt-${active}`);
  if (!el) return;
  $("#palette-input").setAttribute("aria-activedescendant", el.id);
  if (scroll) el.scrollIntoView({ block: "nearest" });
}

function remember(id) {
  if (id.startsWith("tab:")) return;
  const r = (store.get(RECENT_KEY, []) || []).filter((x) => x !== id);
  r.unshift(id);
  store.set(RECENT_KEY, r.slice(0, 4));
}

function execute(i) {
  const r = results[i];
  if (!r) return;
  remember(r.c.id);
  closePalette();

  setTimeout(() => r.c.run(), 30);
}

export function isPaletteOpen() { return open; }

export function openPalette() {
  if (open) return;
  open = true;
  const overlay = $("#palette");
  const input = $("#palette-input");
  input.value = "";
  openOverlay(overlay, { initialFocus: input, onClose: () => { open = false; } });
  render("");
}

export function closePalette() {
  if (!open) return;
  closeOverlay($("#palette"));
}

export function initPalette() {
  const input = $("#palette-input");
  const list = $("#palette-list");
  input.addEventListener("input", () => render(input.value));
  input.addEventListener("keydown", (e) => {
    switch (e.key) {
      case "ArrowDown": e.preventDefault(); setActive(active + 1); break;
      case "ArrowUp": e.preventDefault(); setActive(active - 1); break;
      case "PageDown": e.preventDefault(); setActive(Math.min(results.length - 1, active + 6)); break;
      case "PageUp": e.preventDefault(); setActive(Math.max(0, active - 6)); break;
      case "Enter": e.preventDefault(); execute(active); break;
      case "Tab": e.preventDefault(); setActive(active + (e.shiftKey ? -1 : 1)); break;
      default: break;
    }
  });
  list.addEventListener("pointermove", (e) => {
    const el = e.target.closest(".pal-item");
    if (el && +el.dataset.i !== active) setActive(+el.dataset.i, { scroll: false });
  });
  list.addEventListener("pointerdown", (e) => { if (e.target.closest(".pal-item")) e.preventDefault(); });
  list.addEventListener("click", (e) => {
    const el = e.target.closest(".pal-item");
    if (el) execute(+el.dataset.i);
  });
  $("#palette-trigger").addEventListener("click", openPalette);
}
