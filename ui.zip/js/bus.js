const handlers = new Map();

export function on(event, fn) {
  if (!handlers.has(event)) handlers.set(event, new Set());
  handlers.get(event).add(fn);
  return () => handlers.get(event)?.delete(fn);
}

export function emit(event, data) {
  const set = handlers.get(event);
  if (!set) return;
  for (const fn of set) {
    try { fn(data); } catch (e) { console.error(`[bus] ${event} handler failed`, e); }
  }
}
