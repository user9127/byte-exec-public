import { $, icon } from "./dom.js";
import { animate } from "./motion.js";

const MAX = 4;
const ICONS = { info: "info", ok: "ok", warn: "warn", err: "err" };
const live = new Map(); 

function startTimer(rec) {
  rec.startedAt = performance.now();
  clearTimeout(rec.timer);
  rec.timer = setTimeout(() => dismiss(rec.el), rec.remaining);
}

function pauseTimer(rec) {
  clearTimeout(rec.timer);
  rec.remaining = Math.max(400, rec.remaining - (performance.now() - rec.startedAt));
}

function restartProgress(rec) {
  const bar = rec.el.querySelector(".t-progress");
  const old = bar.firstElementChild;
  const fresh = document.createElement("span");
  fresh.style.animationDuration = `${rec.duration}ms`;
  bar.replaceChild(fresh, old);
}

export function toast(msg, kind = "info", ms = 2600, opts = {}) {
  const host = $("#toasts");
  if (!host) return null;
  const key = `${kind}|${msg}`;
  const existing = live.get(key);

  if (existing && existing.el.isConnected && !existing.el.classList.contains("leaving")) {
    existing.count += 1;
    const c = existing.el.querySelector(".t-count");
    c.hidden = false;
    c.textContent = `x${existing.count}`;
    c.classList.remove("bump"); void c.offsetWidth; c.classList.add("bump");
    existing.duration = ms;
    existing.remaining = ms;
    restartProgress(existing);
    startTimer(existing);
    return existing.el;
  }

  const el = document.createElement("div");
  el.className = `toast ${kind}`;
  el.setAttribute("role", kind === "err" ? "alert" : "status");
  el.innerHTML =
    `<span class="t-ic">${icon(ICONS[kind] || "info")}</span>` +
    `<span class="t-msg"></span>` +
    `<span class="t-count" hidden></span>` +
    (opts.action ? `<button class="t-action"></button>` : "") +
    `<button class="t-close" aria-label="Dismiss notification">${icon("x")}</button>` +
    `<span class="t-progress" aria-hidden="true"><span></span></span>`;
  el.querySelector(".t-msg").textContent = msg;
  el.querySelector(".t-progress span").style.animationDuration = `${ms}ms`;

  const rec = { el, key, count: 1, duration: ms, remaining: ms, timer: 0, startedAt: 0 };
  live.set(key, rec);

  if (opts.action) {
    const b = el.querySelector(".t-action");
    b.textContent = opts.action.label;
    b.addEventListener("click", () => {
      try { opts.action.run(); } finally { dismiss(el); }
    });
  }
  el.querySelector(".t-close").addEventListener("click", () => dismiss(el));
  el.addEventListener("pointerenter", () => pauseTimer(rec));
  el.addEventListener("pointerleave", () => startTimer(rec));

  host.appendChild(el);
  startTimer(rec);

  const alive = Array.from(host.children).filter((c) => !c.classList.contains("leaving"));
  while (alive.length > MAX) dismiss(alive.shift());
  return el;
}

export function dismiss(el) {
  if (!el || el.classList.contains("leaving")) return;
  el.classList.add("leaving");
  for (const [k, rec] of live) {
    if (rec.el === el) { clearTimeout(rec.timer); live.delete(k); break; }
  }
  const h = el.offsetHeight;
  const a = animate(
    el,
    [
      { opacity: 1, transform: "none", height: `${h}px`, marginBottom: "0px" },
      { opacity: 0, transform: "translateX(8px)", height: `${h}px`, marginBottom: "0px", offset: 0.5 },
      { opacity: 0, transform: "translateX(8px)", height: "0px", paddingTop: "0px", paddingBottom: "0px", marginBottom: "-6px", borderWidth: "0px" }
    ],
    { duration: 200, easing: "cubic-bezier(0.2, 0, 0, 1)", fill: "forwards" }
  );
  if (a) a.onfinish = () => el.remove();
  else el.remove();
}
