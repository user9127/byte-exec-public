/* Motion policy + small animation utilities.
   One switch decides whether anything moves: the in-app Motion setting
   (System / Reduced / Full) layered over the OS prefers-reduced-motion flag. */

const mq = window.matchMedia("(prefers-reduced-motion: reduce)");

export function reducedMotion() {
  const m = document.documentElement.dataset.motion;
  if (m === "reduced") return true;
  if (m === "full") return false;
  return mq.matches;
}

export function onMotionChange(fn) {
  mq.addEventListener?.("change", fn);
}

/* Same curve as --ease in styles.css: fast start, no overshoot. */
export const EASE_OUT = "cubic-bezier(0.2, 0, 0, 1)";

/* WAAPI wrapper that collapses to an instant change under reduced motion. */
export function animate(el, keyframes, opts = {}) {
  if (!el || typeof el.animate !== "function") return null;
  const o = typeof opts === "number" ? { duration: opts } : { ...opts };
  if (reducedMotion()) { o.duration = 1; o.delay = 0; }
  try { return el.animate(keyframes, o); } catch { return null; }
}

/* Gliding indicator: moves `indicator` onto `target` by writing --gx/--gy/--gw/--gh.
   Both must share an offsetParent (the container is position:relative). */
export function glide(indicator, target, { axis = "y", instant = false } = {}) {
  if (!indicator || !target) return;
  if (target.offsetParent === null) return; // hidden; ResizeObserver will retry when shown
  const s = indicator.style;
  if (instant) indicator.classList.add("glide-instant");
  if (axis === "x" || axis === "both") {
    s.setProperty("--gx", `${target.offsetLeft}px`);
    s.setProperty("--gw", `${target.offsetWidth}px`);
  }
  if (axis === "y" || axis === "both") {
    s.setProperty("--gy", `${target.offsetTop}px`);
    s.setProperty("--gh", `${target.offsetHeight}px`);
  }
  if (instant) {
    void indicator.offsetWidth; // commit the jump before transitions come back
    requestAnimationFrame(() => indicator.classList.remove("glide-instant"));
  }
}
