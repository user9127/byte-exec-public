/* Themed tooltips for [data-tip] (+ optional [data-kbd]) replacing native
   title= bubbles, which render as unthemed OS popups inside WebView2.
   Delay on first hover, instant while "warm" (moving between controls). */

import { $, escapeHtml } from "./dom.js";

const SHOW_DELAY = 480;
const WARM_MS = 400;
const GAP = 8;
const MARGIN = 6;

let tip = null;
let current = null;
let showTimer = 0;
let hideTimer = 0;
let warmUntil = 0;

function eligible(t) {
  if (!t || !t.isConnected || !t.dataset.tip) return false;
  if (t.hasAttribute("data-tip-collapsed") && document.documentElement.dataset.sidebar !== "collapsed") return false;
  return true;
}

export function kbdHtml(combo) {
  if (!combo) return "";
  return combo
    .split("+")
    .map((k) => `<kbd class="kbd">${escapeHtml(k === "Enter" ? "↵" : k)}</kbd>`)
    .join("");
}

function place(t) {
  const side0 = t.dataset.tipPos || "top";
  const r = t.getBoundingClientRect();
  const w = tip.offsetWidth;
  const h = tip.offsetHeight;
  const vw = window.innerWidth;
  const vh = window.innerHeight;

  const fits = {
    top: r.top - GAP - h >= MARGIN,
    bottom: r.bottom + GAP + h <= vh - MARGIN,
    right: r.right + GAP + w <= vw - MARGIN,
    left: r.left - GAP - w >= MARGIN
  };
  const flip = { top: "bottom", bottom: "top", left: "right", right: "left" };
  const side = fits[side0] ? side0 : fits[flip[side0]] ? flip[side0] : side0;

  let x;
  let y;
  if (side === "top" || side === "bottom") {
    x = r.left + r.width / 2 - w / 2;
    y = side === "top" ? r.top - GAP - h : r.bottom + GAP;
  } else {
    y = r.top + r.height / 2 - h / 2;
    x = side === "right" ? r.right + GAP : r.left - GAP - w;
  }
  x = Math.max(MARGIN, Math.min(vw - w - MARGIN, x));
  y = Math.max(MARGIN, Math.min(vh - h - MARGIN, y));

  tip.style.left = `${Math.round(x)}px`;
  tip.style.top = `${Math.round(y)}px`;
  const off = { top: ["0px", "4px"], bottom: ["0px", "-4px"], right: ["-4px", "0px"], left: ["4px", "0px"] }[side];
  tip.style.setProperty("--dx", off[0]);
  tip.style.setProperty("--dy", off[1]);
}

function show(t) {
  if (!eligible(t)) return;
  clearTimeout(hideTimer);
  const wasShown = tip.classList.contains("show");
  current = t;
  tip.innerHTML = `<span>${escapeHtml(t.dataset.tip)}</span>${t.dataset.kbd ? `<span class="tt-keys">${kbdHtml(t.dataset.kbd)}</span>` : ""}`;
  if (!wasShown) tip.classList.remove("show");
  place(t);
  tip.setAttribute("aria-hidden", "false");
  t.setAttribute("aria-describedby", "tooltip");
  requestAnimationFrame(() => tip.classList.add("show"));
}

export function hideTooltip() {
  clearTimeout(showTimer);
  clearTimeout(hideTimer);
  if (current) {
    current.removeAttribute("aria-describedby");
    warmUntil = performance.now() + WARM_MS;
  }
  current = null;
  if (tip) {
    tip.classList.remove("show");
    tip.setAttribute("aria-hidden", "true");
  }
}

function schedule(t) {
  clearTimeout(showTimer);
  clearTimeout(hideTimer);
  if (!eligible(t)) { hideTooltip(); return; }
  const warm = tip.classList.contains("show") || performance.now() < warmUntil;
  showTimer = setTimeout(() => show(t), warm ? 0 : SHOW_DELAY);
}

export function initTooltips() {
  tip = $("#tooltip");
  if (!tip) return;

  document.addEventListener("pointerover", (e) => {
    if (e.pointerType === "touch") return;
    const t = e.target.closest("[data-tip]");
    if (t === current) { clearTimeout(hideTimer); return; }
    if (!t) { clearTimeout(showTimer); hideTimer = setTimeout(hideTooltip, 80); return; }
    schedule(t);
  });
  document.documentElement.addEventListener("pointerleave", hideTooltip);
  document.addEventListener("pointerdown", hideTooltip, true);
  document.addEventListener("wheel", hideTooltip, { passive: true, capture: true });
  document.addEventListener("scroll", hideTooltip, true);
  window.addEventListener("blur", hideTooltip);
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") hideTooltip(); }, true);

  // keyboard users get the same hint on focus-visible
  document.addEventListener("focusin", (e) => {
    const t = e.target.closest?.("[data-tip]");
    if (t && t.matches(":focus-visible")) { clearTimeout(showTimer); show(t); }
  });
  document.addEventListener("focusout", (e) => {
    if (current && e.target === current) hideTooltip();
  });
}
