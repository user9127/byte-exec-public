/* AI Connect page: front end for the native /mcp/* routes. The launcher runs
   the byte-mcp CLI and relays its JSON; detection of AI apps, writing their
   config files and the starter prompt all live in byte-mcp itself. */

import { $, copyText } from "./dom.js";
import { bridgeGet, bridgePost } from "./bridge.js";
import { toast } from "./toast.js";
import { on } from "./bus.js";

const ui = {
  status: null,
  prompt: "",
  config: null,
  busy: false,
  loadedOnce: false,
};

function setBadge(id, kind, text) {
  const b = $(`#${id}-badge`);
  if (!b) return;
  b.className = "badge" + (kind ? " " + kind : "");
  $(`#${id}-state`).textContent = text;
}

function esc(s) {
  return String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
}

function renderClients() {
  const host = $("#mcp-clients");
  if (!host) return;
  const list = ui.status?.clients ?? [];
  const found = list.filter((c) => c.detected);
  const missing = [...new Set(list.filter((c) => !c.detected).map((c) => c.name.replace(/\s*\(.*\)$/, "")))];
  const rows = found.map((c) => {
    const state = c.configured ? ["ok", "Connected"] : ["warn", "Not connected"];
    const btn = c.configured
      ? `<button class="btn ghost sm" data-mcp-remove="${esc(c.id)}"><span class="btn-label">Remove</span></button>`
      : `<button class="btn sm" data-mcp-connect="${esc(c.id)}"><span class="btn-label">Connect</span></button>`;
    return `<div class="setting-row">
      <div class="sr-text">
        <div class="label">${esc(c.name)}</div>
        <div class="desc mono">${esc(c.file || "registered through the claude command")}</div>
      </div>
      <div class="action"><span class="badge ${state[0]}"><span class="dot"></span>${state[1]}</span>${btn}</div>
    </div>`;
  });
  if (!found.length && ui.status?.ok)
    rows.push(`<div class="setting-row"><div class="sr-text"><div class="label">No AI apps found</div><div class="desc">Install one of the apps below and press Refresh, or use Manual setup.</div></div></div>`);
  if (missing.length)
    rows.push(`<div class="setting-row"><div class="sr-text"><div class="label">Also supported</div><div class="desc">${esc(missing.join(", "))}. Install one and press Refresh.</div></div></div>`);
  rows.push(`<div class="setting-row"><div class="sr-text"><div class="label">ChatGPT, Gemini, Kimi, Grok, DeepSeek websites</div><div class="desc">Chat websites can only reach servers on a public internet address, not apps on your PC. Use their agents instead, which all work with Byte: Codex for ChatGPT, Gemini CLI for Gemini, Kimi Code CLI for Kimi.</div></div></div>`);
  host.innerHTML = rows.join("");
}

function renderServer() {
  const s = ui.status;
  const desc = $("#mcp-server-desc");
  if (!s) return;
  const btn = $("#btn-mcp-install");
  if (ui.installing) return;
  if (!s.installed) {
    setBadge("mcp-server", "warn", "Not installed");
    desc.textContent = "Download the Byte MCP server once to connect AI apps (about 35 MB).";
    setInstallBtn("Install");
  } else if (!s.ok) {
    setBadge("mcp-server", "err", "Error");
    desc.textContent = s.error || "byte-mcp failed to start.";
    setInstallBtn("Reinstall");
  } else if (s.updateAvailable) {
    setBadge("mcp-server", "warn", "Update");
    desc.textContent = `v${s.version} installed, v${s.latest} available. Close AI apps before updating.`;
    setInstallBtn("Update");
  } else {
    setBadge("mcp-server", "ok", "Ready");
    desc.textContent = `v${s.version} · ${s.path}`;
    btn.hidden = true;
  }
  $("#btn-mcp-connect-all").disabled = !s.installed || !s.ok;
}

function setInstallBtn(label) {
  const btn = $("#btn-mcp-install");
  btn.hidden = false;
  btn.disabled = false;
  btn.querySelector(".btn-label").textContent = label;
}

const PHASE_TEXT = {
  checking: "Checking for the latest version...",
  downloading: "Downloading Byte MCP (about 35 MB)...",
  verifying: "Verifying the download...",
  installing: "Installing...",
};

async function install() {
  if (ui.installing) return;
  ui.installing = true;
  const btn = $("#btn-mcp-install");
  btn.disabled = true;
  setBadge("mcp-server", "", "Installing");
  try {
    const start = await bridgePost("/mcp/install", {});
    if (!start?.ok) {
      toast(start?.error || "Could not start the install.", "err");
      return;
    }
    for (;;) {
      await new Promise((r) => setTimeout(r, 700));
      const st = await bridgeGet("/mcp/install-state");
      if (!st) continue;
      if (PHASE_TEXT[st.phase]) $("#mcp-server-desc").textContent = PHASE_TEXT[st.phase];
      if (st.phase === "done") {
        toast(`Byte MCP v${st.version} installed.`, "ok");
        break;
      }
      if (st.phase === "error") {
        toast(st.error || "Install failed.", "err", 6000);
        break;
      }
    }
  } finally {
    ui.installing = false;
    // the prompt and config embed the server path, so fetch them again
    ui.prompt = "";
    ui.config = null;
    await refresh({ quiet: true });
  }
}

async function refreshRoblox() {
  const st = await bridgeGet("/status");
  const desc = $("#mcp-roblox-desc");
  if (!st) return;
  if (st.pids?.length) {
    setBadge("mcp-roblox", "ok", "Attached");
    desc.textContent = "Byte is attached. The AI can read and control the game you are in.";
  } else if (st.robloxRunning) {
    setBadge("mcp-roblox", "warn", "Not attached");
    desc.textContent = "Roblox is open but Byte is not attached. Inject from the Workspace page.";
  } else {
    setBadge("mcp-roblox", "", "Closed");
    desc.textContent = "Open Roblox, join a game and inject Byte. The AI connects through it.";
  }
}

async function refresh({ quiet = false } = {}) {
  // A refresh asked for mid-flight (e.g. right after Connect) must not be
  // dropped, or the older in-flight result would be the last one rendered.
  if (ui.busy) {
    ui.again = true;
    return;
  }
  ui.busy = true;
  $("#btn-mcp-refresh")?.setAttribute("disabled", "");
  if (!quiet) setBadge("mcp-server", "", "Checking");
  try {
    const [status, prompt, config] = await Promise.all([
      bridgeGet("/mcp/status", { timeout: 40000 }),
      ui.prompt ? null : bridgeGet("/mcp/prompt", { timeout: 20000 }),
      ui.config ? null : bridgeGet("/mcp/config", { timeout: 20000 }),
      refreshRoblox(),
    ]);
    if (status) ui.status = status;
    if (prompt?.prompt) ui.prompt = prompt.prompt;
    if (config?.mcpServers) ui.config = config;
    renderServer();
    renderClients();
    $("#mcp-prompt").textContent = ui.prompt || "Byte MCP is not installed, so there is no prompt yet.";
    $("#mcp-json").textContent = ui.config ? JSON.stringify({ mcpServers: ui.config.mcpServers }, null, 2) : "";
    ui.loadedOnce = true;
  } finally {
    ui.busy = false;
    $("#btn-mcp-refresh")?.removeAttribute("disabled");
  }
  if (ui.again) {
    ui.again = false;
    await refresh({ quiet: true });
  }
}

async function runSetup(clients, remove) {
  const btn = $("#btn-mcp-connect-all");
  btn.disabled = true;
  try {
    const res = await bridgePost("/mcp/setup", { clients, remove }, { timeout: 70000 });
    const list = res?.clients;
    if (!res?.ok || !Array.isArray(list)) {
      toast(res?.error || "Could not update the AI apps.", "err");
      return;
    }
    const failed = list.filter((c) => c.error);
    if (failed.length) toast(`${failed[0].name}: ${failed[0].error}`, "warn", 5000);
    else if (remove) toast("Removed Byte from that app.", "ok");
    else {
      const done = list.filter((c) => c.configured).map((c) => c.name);
      toast(done.length ? `Connected: ${[...new Set(done)].join(", ")}. Restart those apps.` : "No AI apps found on this PC.", done.length ? "ok" : "warn", 5000);
    }
  } finally {
    btn.disabled = false;
    await refresh({ quiet: true });
  }
}

async function copy(text, what) {
  if (!text) return toast("Nothing to copy yet.", "warn");
  if (await copyText(text)) toast(`${what} copied.`, "ok", 1800);
  else toast("Clipboard access denied.", "err");
}

export function initAi() {
  $("#btn-mcp-refresh")?.addEventListener("click", () => refresh());
  $("#btn-mcp-install")?.addEventListener("click", install);
  $("#btn-mcp-connect-all")?.addEventListener("click", () => runSetup("", false));
  $("#btn-mcp-copy-prompt")?.addEventListener("click", () => copy(ui.prompt, "Prompt"));
  $("#btn-mcp-copy-json")?.addEventListener("click", () =>
    copy(ui.config ? JSON.stringify({ mcpServers: ui.config.mcpServers }, null, 2) : "", "Config"));
  $("#btn-mcp-copy-http")?.addEventListener("click", () => {
    const h = ui.config?.http;
    copy(h ? `URL: ${h.url}\nHeader: Authorization: ${h.headers.Authorization}` : "", "URL and token");
  });
  $("#mcp-clients")?.addEventListener("click", (e) => {
    const c = e.target.closest("[data-mcp-connect]");
    const r = e.target.closest("[data-mcp-remove]");
    if (c) runSetup(c.dataset.mcpConnect, false);
    else if (r) runSetup(r.dataset.mcpRemove, true);
  });
  on("page", ({ to }) => {
    if (to === "ai") refresh({ quiet: ui.loadedOnce });
  });
}
