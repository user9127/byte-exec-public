import { $ } from "./dom.js";
import { state } from "./state.js";
import { bridgeGet, bridgePost } from "./bridge.js";
import { toast } from "./toast.js";
import { buttonFeedback } from "./fx.js";
import { reducedMotion } from "./motion.js";
import { goToPage } from "./nav.js";

let mode = "install"; 

function showBanner() {
  const b = $("#update-banner");
  b.classList.remove("closing");
  b.hidden = false;
}

function hideBanner() {
  const b = $("#update-banner");
  if (b.hidden) return;
  if (reducedMotion()) { b.hidden = true; return; }
  b.classList.add("closing");
  setTimeout(() => { b.hidden = true; b.classList.remove("closing"); }, 80);
}

export async function checkUpdate(userInitiated = false) {
  const btn = $("#btn-check-update");
  if (userInitiated) { btn.classList.add("loading"); btn.disabled = true; }
  const r = await bridgeGet("/update/check", { timeout: 20000 });
  if (userInitiated) { btn.classList.remove("loading"); btn.disabled = false; }
  if (!r) {
    if (userInitiated) { buttonFeedback(btn, "fail"); toast("Update check failed.", "err"); }
    return;
  }
  $("#settings-latest").textContent = r.latest || "?";
  state.latestVersion = r.latest || null;
  if (r.updateAvailable) {
    $("#update-version").textContent = r.latest;
    $("#update-desc").textContent = r.notes || "A new build is available.";
    if (mode === "install") showBanner();
    const sbU = $("#sb-update");
    if (sbU) sbU.hidden = false;
    if (userInitiated) toast(`Update ${r.latest} available.`, "ok");
  } else {
    hideBanner();
    const sbU = $("#sb-update");
    if (sbU) sbU.hidden = true;
    if (userInitiated) { buttonFeedback(btn, "success"); toast("You are on the latest version.", "ok"); }
  }
}

async function onApply() {
  const btn = $("#update-apply");
  const label = btn.querySelector(".btn-label");
  if (mode === "restart") {
    btn.classList.add("loading");
    btn.disabled = true;
    await bridgePost("/update/restart");
    return;
  }
  btn.classList.add("loading");
  btn.disabled = true;
  $("#update-banner").classList.add("downloading");
  $("#update-desc").textContent = "Downloading the new build…";
  const r = await bridgePost("/update/apply", undefined, { timeout: 0 });
  btn.classList.remove("loading");
  btn.disabled = false;
  $("#update-banner").classList.remove("downloading");
  if (r?.ok) {
    mode = "restart";
    label.textContent = "Restart now";
    const v = r.version || state.latestVersion;
    $("#update-desc").textContent = v ? `Version ${v} is ready. Restart Byte to finish.` : "The new build is ready. Restart Byte to finish.";
    buttonFeedback(btn, "success", 900);
    toast("Downloaded. Restart to apply.", "ok", 4000);
  } else {
    label.textContent = "Retry";
    $("#update-desc").textContent = "The download did not finish. Check your connection and retry.";
    buttonFeedback(btn, "fail");
    toast(`Update failed: ${r?.error || "unknown"}`, "err");
  }
}

export function initUpdate() {
  $("#btn-check-update").addEventListener("click", () => checkUpdate(true));
  $("#update-dismiss").addEventListener("click", hideBanner);
  $("#update-apply").addEventListener("click", onApply);
  $("#sb-update")?.addEventListener("click", () => {
    showBanner();
    goToPage("settings");
  });
}
