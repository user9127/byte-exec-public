import { $ } from "./dom.js";
import { state } from "./state.js";
import { bridgeGet, bridgePost } from "./bridge.js";
import { toast } from "./toast.js";
import { buttonFeedback } from "./fx.js";
import { reducedMotion } from "./motion.js";
import { goToPage } from "./nav.js";

// install  → first-time: button = "Install & restart", sidekick = "Later"
// updating → during the /update/apply fetch: sidekick = "Cancel"
// restart  → download done, waiting for the user: button = "Restart now", sidekick = "Later"
let mode = "install";
let applyAbort = null;

function showBanner() {
  const b = $("#update-banner");
  b.classList.remove("closing");
  b.hidden = false;
}

function hideBanner() {
  const b = $("#update-banner");
  if (b.hidden) return;
  if (reducedMotion()) { b.hidden = true; return; }
  b.classList.add("closing");
  setTimeout(() => { b.hidden = true; b.classList.remove("closing"); }, 80);
}

function setSidekick(label) {
  const span = $("#update-dismiss .btn-label");
  if (span) span.textContent = label;
}

function setMode(next) {
  mode = next;
  const apply = $("#update-apply");
  const applyLabel = apply.querySelector(".btn-label");
  if (next === "install") {
    applyLabel.textContent = "Install & restart";
    setSidekick("Later");
  } else if (next === "updating") {
    setSidekick("Cancel");
  } else if (next === "restart") {
    applyLabel.textContent = "Restart now";
    setSidekick("Later");
  }
}

export async function checkUpdate(userInitiated = false) {
  // While a download is in flight, don't flip the banner's visibility out
  // from under the user — the fetch owns the UI until it finishes or is
  // cancelled.
  if (mode === "updating") return;

  const btn = $("#btn-check-update");
  if (userInitiated) { btn.classList.add("loading"); btn.disabled = true; }
  const r = await bridgeGet("/update/check", { timeout: 20000 });
  if (userInitiated) { btn.classList.remove("loading"); btn.disabled = false; }
  if (!r) {
    if (userInitiated) { buttonFeedback(btn, "fail"); toast("Update check failed.", "err"); }
    return;
  }
  $("#settings-latest").textContent = r.latest || "?";
  state.latestVersion = r.latest || null;

  if (r.updateAvailable) {
    $("#update-version").textContent = r.latest;
    $("#update-desc").textContent = r.notes || "A new build is available.";
    if (mode === "install") showBanner();
    const sbU = $("#sb-update");
    if (sbU) sbU.hidden = false;
    if (userInitiated) toast(`Update ${r.latest} available.`, "ok");
  } else {
    setMode("install");
    hideBanner();
    const sbU = $("#sb-update");
    if (sbU) sbU.hidden = true;
    if (userInitiated) { buttonFeedback(btn, "success"); toast("You are on the latest version.", "ok"); }
  }
}

function cancelApply() {
  if (!applyAbort) return;
  try { applyAbort.abort(); } catch { /* ignore */ }
  applyAbort = null;
  const btn = $("#update-apply");
  btn.classList.remove("loading");
  btn.disabled = false;
  $("#update-banner").classList.remove("downloading");
  $("#update-desc").textContent = "Update cancelled. Click Install & restart to try again.";
  setMode("install");
  toast("Update cancelled.", "info");
}

async function onApply() {
  const btn = $("#update-apply");
  if (mode === "restart") {
    btn.classList.add("loading");
    btn.disabled = true;
    await bridgePost("/update/restart");
    return;
  }
  btn.classList.add("loading");
  btn.disabled = true;
  $("#update-banner").classList.add("downloading");
  $("#update-desc").textContent = "Downloading the new build…";
  setMode("updating");

  applyAbort = new AbortController();
  const r = await bridgePost("/update/apply", undefined, { timeout: 0, signal: applyAbort.signal });
  applyAbort = null;

  btn.classList.remove("loading");
  btn.disabled = false;
  $("#update-banner").classList.remove("downloading");

  // Fetch aborted via Cancel — cancelApply() already reset the UI.
  if (r?.error === "aborted" || r?.aborted) return;

  if (r?.ok) {
    const v = r.version || state.latestVersion;
    $("#update-desc").textContent = v ? `Version ${v} is ready. Restart Byte to finish.` : "The new build is ready. Restart Byte to finish.";
    setMode("restart");
    buttonFeedback(btn, "success", 900);
    toast("Downloaded. Restart to apply.", "ok", 4000);
  } else {
    setMode("install");
    const label = btn.querySelector(".btn-label");
    label.textContent = "Retry";
    $("#update-desc").textContent = "The download did not finish. Check your connection and retry.";
    buttonFeedback(btn, "fail");
    toast(`Update failed: ${r?.error || "unknown"}`, "err");
  }
}

function onDismissOrCancel() {
  if (mode === "updating") cancelApply();
  else hideBanner();
}

export function initUpdate() {
  $("#btn-check-update").addEventListener("click", () => checkUpdate(true));
  $("#update-dismiss").addEventListener("click", onDismissOrCancel);
  $("#update-apply").addEventListener("click", onApply);
  $("#sb-update")?.addEventListener("click", () => {
    showBanner();
    goToPage("settings");
  });

  // Re-check when the window comes back into focus so a kept-open launcher
  // picks up a fresh deploy without waiting for the 30 min interval; also
  // means the banner disappears automatically if a user updated through
  // some other path.
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden && state.settings?.autoUpdate !== false) checkUpdate(false);
  });
}
