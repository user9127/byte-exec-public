import { $, $$, escapeHtml, copyText } from "./dom.js";
import { bridgeGet, bridgePost } from "./bridge.js";
import { state } from "./state.js";
import { toast } from "./toast.js";
import { log } from "./console.js";
import { emit, on } from "./bus.js";

let versionsData = null;
let activeLauncher = "all";
let activeStatus = "all";
let searchQuery = "";
let filterOnlyRunning = false;
let filterOnlyLatest = false;
let activeLaunchHash = null;

export function getActiveLaunchHash() {
  return activeLaunchHash || versionsData?.supportedHash || "version-02c37bc51a384b8f";
}

function getLauncherImg(type) {
  if (type === "bloxstrap") return "/bloxstrap.png";
  if (type === "fishstrap") return "/fishstrap.png";
  return "/roblox.png";
}

function getLauncherIcon(type) {
  if (type === "bloxstrap") return "i-bloxstrap";
  if (type === "fishstrap") return "i-fishstrap";
  if (type === "voidstrap") return "i-voidstrap";
  return "i-roblox";
}

function renderPill(status, running, isPatched) {
  const pills = [];
  if (isPatched || status === "supported") {
    pills.push(`<span class="vcard-pill supported"><svg class="ic"><use href="#i-check"/></svg> Patched</span>`);
  } else if (status === "outdated") {
    pills.push(`<span class="vcard-pill outdated"><span class="vp-dot"></span> Outdated</span>`);
  } else {
    pills.push(`<span class="vcard-pill unsupported"><svg class="ic"><use href="#i-warn"/></svg> Unsupported</span>`);
  }

  if (running) {
    pills.push(`<span class="vcard-pill running"><span class="vp-dot"></span> Running</span>`);
  }

  return pills.join(" ");
}

function getLauncherItems(list) {

  const items = [];
  const isRunning = Boolean(state.pids?.length || state.activePid);

  const bloxVer = list.find((v) => v.status === "supported") || list[0];
  if (bloxVer) {
    items.push({
      launcher: "bloxstrap",
      launcherName: "Bloxstrap",
      version: bloxVer.version,
      hash: bloxVer.hash,
      status: bloxVer.status,
      running: isRunning,
      patched: true,
      isLatest: bloxVer.isLatest,
      installed: true,
      downloadUrl: bloxVer.downloadUrl
    });
  }

  const fishVer = list.find((v) => v.hash === "version-9affbe66b2624d20" || v.hash === "version-2366ba214ec740ca") || list[1] || list[0];
  if (fishVer) {
    items.push({
      launcher: "fishstrap",
      launcherName: "Fishstrap",
      version: fishVer.version,
      hash: fishVer.hash,
      status: "unsupported",
      running: false,
      patched: false,
      isLatest: false,
      installed: true,
      downloadUrl: fishVer.downloadUrl
    });
  }

  for (const v of list) {
    items.push({
      launcher: "roblox",
      launcherName: "Roblox",
      version: v.version,
      hash: v.hash,
      status: v.status,
      running: isRunning && (v.hash === bloxVer?.hash),
      patched: v.status === "supported",
      isLatest: v.isLatest,
      installed: v.installed,
      installedPath: v.installedPath,
      downloadUrl: v.downloadUrl
    });
  }

  return items;
}

function filterItems(items) {
  return items.filter((it) => {

    if (activeLauncher !== "all" && it.launcher !== activeLauncher) return false;

    if (activeStatus === "supported" && it.status !== "supported" && !it.patched) return false;
    if (activeStatus === "outdated" && it.status !== "outdated" && it.status !== "unsupported") return false;

    if (filterOnlyRunning && !it.running) return false;
    if (filterOnlyLatest && !it.isLatest) return false;

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      const matchHash = it.hash?.toLowerCase().includes(q);
      const matchVer = it.version?.toLowerCase().includes(q);
      const matchName = it.launcherName?.toLowerCase().includes(q);
      if (!matchHash && !matchVer && !matchName) return false;
    }

    return true;
  });
}

function updateCounts(allItems) {
  const countAll = $("#vfs-count-all");
  if (countAll) countAll.textContent = allItems.length;

  const countRoblox = $("#vfs-count-roblox");
  if (countRoblox) countRoblox.textContent = allItems.filter((i) => i.launcher === "roblox").length;

  const countBlox = $("#vfs-count-bloxstrap");
  if (countBlox) countBlox.textContent = allItems.filter((i) => i.launcher === "bloxstrap").length;

  const countFish = $("#vfs-count-fishstrap");
  if (countFish) countFish.textContent = allItems.filter((i) => i.launcher === "fishstrap").length;

  const countStatusAll = $("#vfs-status-all");
  if (countStatusAll) countStatusAll.textContent = allItems.length;

  const countSupported = $("#vfs-status-supported");
  if (countSupported) countSupported.textContent = allItems.filter((i) => i.status === "supported" || i.patched).length;

  const countOutdated = $("#vfs-status-outdated");
  if (countOutdated) countOutdated.textContent = allItems.filter((i) => i.status === "outdated" || i.status === "unsupported").length;

  const badgeInstalled = $("#ver-installed-badge");
  if (badgeInstalled) badgeInstalled.textContent = `${allItems.filter((i) => i.installed).length} installed`;
}

function renderVersions() {
  const container = $("#ver-installed-list");
  if (!container) return;

  const rawList = versionsData?.versions || [];
  const allItems = getLauncherItems(rawList);
  updateCounts(allItems);

  const filtered = filterItems(allItems);

  if (!filtered.length) {
    container.innerHTML = `
      <div class="ver-empty-box">
        <svg class="ic"><use href="#i-layers"/></svg>
        <p>No installed versions match current filter criteria.</p>
      </div>`;
    return;
  }

  const groups = {};
  for (const it of filtered) {
    const key = it.launcherName.toUpperCase();
    if (!groups[key]) groups[key] = [];
    groups[key].push(it);
  }

  container.innerHTML = Object.entries(groups).map(([groupName, items]) => {
    const launcher = items[0].launcher;
    const headerImg = getLauncherImg(launcher);
    return `
      <div class="ver-launcher-group">
        <div class="vlg-header">
          <img class="vlg-header-icon ${launcher}" src="${headerImg}" alt="${escapeHtml(groupName)}" />
          <span class="vlg-title">${escapeHtml(groupName)}</span>
          <span class="vlg-count">${items.length}</span>
        </div>

        <div class="vlg-cards">
          ${items.map((it) => {
            const isTarget = it.hash === getActiveLaunchHash();
            const cardImg = getLauncherImg(it.launcher);
            return `
              <div class="vcard-row ${it.status} ${isTarget ? "is-target" : ""}" data-hash="${escapeHtml(it.hash)}">
                <div class="vcard-icon-col">
                  <div class="vcard-app-icon ${it.launcher}">
                    <img class="vcard-brand-img ${it.launcher}" src="${cardImg}" alt="${escapeHtml(it.launcherName)}" />
                  </div>
                </div>

                <div class="vcard-info-col">
                  <div class="vcard-title-line">
                    <span class="vcard-app-name">${escapeHtml(it.launcherName)}</span>
                    ${renderPill(it.status, it.running, it.patched)}
                    ${isTarget ? '<span class="vcard-target-tag">Launch Target</span>' : ""}
                  </div>
                  <div class="vcard-sub-line">
                    <code class="vcard-hash">${escapeHtml(it.hash)}</code>
                    <span class="vcard-sep">·</span>
                    <span class="vcard-ver">${escapeHtml(it.version)}</span>
                    <button type="button" class="icon-btn sm btn-copy-hash" data-hash="${escapeHtml(it.hash)}" data-tip="Copy hash">
                      <svg class="ic"><use href="#i-copy"/></svg>
                    </button>
                  </div>
                </div>

                <div class="vcard-actions-col">
                  ${it.status === "unsupported" ? `
                    <button type="button" class="btn sm vcard-sec-btn btn-dl-comp" data-hash="${escapeHtml(it.hash)}" data-tip="Download compatible version">
                      <svg class="ic"><use href="#i-download"/></svg>
                      <span>Download compatible</span>
                    </button>
                  ` : `
                    <button type="button" class="btn sm vcard-sec-btn btn-set-target" data-hash="${escapeHtml(it.hash)}" data-tip="Set as default launch version">
                      <svg class="ic"><use href="#i-star"/></svg>
                      <span>${isTarget ? "Default" : "Patch"}</span>
                    </button>
                  `}
                  <button type="button" class="btn sm vcard-launch-btn btn-vlaunch" data-hash="${escapeHtml(it.hash)}" data-tip="Launch Roblox with this version">
                    <svg class="ic"><use href="#i-play"/></svg>
                    <span>Launch</span>
                  </button>
                </div>
              </div>
            `;
          }).join("")}
        </div>
      </div>
    `;
  }).join("");

  bindCardActions();
}

function bindCardActions() {
  const container = $("#ver-installed-list");
  if (!container) return;

  $$(".btn-copy-hash", container).forEach((btn) => {
    btn.addEventListener("click", async () => {
      const hash = btn.dataset.hash;
      if (!hash) return;
      const ok = await copyText(hash);
      toast(ok ? `Copied ${hash}` : "Failed to copy.", ok ? "ok" : "err", 1500);
    });
  });

  $$(".btn-vlaunch", container).forEach((btn) => {
    btn.addEventListener("click", async () => {
      const hash = btn.dataset.hash;
      if (!hash) return;
      btn.classList.add("loading");
      toast(`Launching Roblox (${hash})…`, "info", 2000);
      log(`Launching Roblox build: ${hash}`, "info");

      const r = await bridgePost("/launch-roblox", { hash });
      btn.classList.remove("loading");

      if (r?.ok) {
        toast(`Roblox launched (${hash}).`, "ok", 2500);
        log(`Roblox launched (${r.target || hash}).`, "ok");
      } else {
        toast(`Launch failed: ${r?.error || "unable to launch"}`, "err", 3500);
        log(`Launch failed: ${r?.error || "unknown"}`, "err");
      }
    });
  });

  $$(".btn-set-target", container).forEach((btn) => {
    btn.addEventListener("click", () => {
      const hash = btn.dataset.hash;
      if (!hash) return;
      activeLaunchHash = hash;
      renderVersions();
      toast(`Default launch set to ${hash}.`, "ok", 1800);
      log(`Selected default launch target: ${hash}`, "ok");
    });
  });

  $$(".btn-dl-comp", container).forEach((btn) => {
    btn.addEventListener("click", async () => {
      const hash = versionsData?.supportedHash || "version-02c37bc51a384b8f";
      toast(`Opening download for ${hash}…`, "info", 2000);
      const r = await bridgePost("/download-version", { hash });
      if (r?.ok) toast("Download started in browser.", "ok", 2000);
    });
  });
}

export async function refreshVersions(showToast = false) {
  const data = await bridgeGet("/versions");
  if (data?.ok) {
    versionsData = data;
    if (!activeLaunchHash) {
      activeLaunchHash = data.supportedHash || "version-02c37bc51a384b8f";
    }
    renderVersions();
    if (showToast) toast("Synced with WEAO API.", "ok", 1800);
  } else {
    if (showToast) toast("Could not reach WEAO API.", "warn", 2500);
  }
}

export function initVersions() {

  $$(".ver-pill-tab").forEach((tab) => {
    tab.addEventListener("click", () => {
      $$(".ver-pill-tab").forEach((t) => t.classList.remove("active"));
      tab.classList.add("active");
    });
  });

  const sInput = $("#ver-search-input");
  if (sInput) {
    sInput.addEventListener("input", () => {
      searchQuery = sInput.value.trim();
      renderVersions();
    });
  }

  $$(".vfs-btn[data-launcher]").forEach((btn) => {
    btn.addEventListener("click", () => {
      $$(".vfs-btn[data-launcher]").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      activeLauncher = btn.dataset.launcher || "all";
      renderVersions();
    });
  });

  $$(".vfs-btn[data-status]").forEach((btn) => {
    btn.addEventListener("click", () => {
      $$(".vfs-btn[data-status]").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      activeStatus = btn.dataset.status || "all";
      renderVersions();
    });
  });

  $("#chk-show-running")?.addEventListener("change", (e) => {
    filterOnlyRunning = e.target.checked;
    renderVersions();
  });

  $("#chk-show-latest")?.addEventListener("change", (e) => {
    filterOnlyLatest = e.target.checked;
    renderVersions();
  });

  const dlInput = $("#vib-hash-input");
  const dlBtn = $("#vib-download-btn");
  dlBtn?.addEventListener("click", async () => {
    const hash = (dlInput?.value || "").trim() || getActiveLaunchHash();
    toast(`Downloading Roblox package for ${hash}…`, "info", 2000);
    const r = await bridgePost("/download-version", { hash });
    if (r?.ok) toast("Download initiated in browser.", "ok", 2500);
  });

  $("#preset-rec")?.addEventListener("click", () => {
    const hash = versionsData?.supportedHash || "version-02c37bc51a384b8f";
    if (dlInput) dlInput.value = hash;
    toast(`Filled recommended hash: ${hash}`, "info", 1500);
  });

  $("#preset-latest")?.addEventListener("click", () => {
    const hash = versionsData?.versions?.find((v) => v.isLatest)?.hash || versionsData?.supportedHash || "version-02c37bc51a384b8f";
    if (dlInput) dlInput.value = hash;
    toast(`Filled latest hash: ${hash}`, "info", 1500);
  });

  refreshVersions(false);
  on("status", () => renderVersions());
}
