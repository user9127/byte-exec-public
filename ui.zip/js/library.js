import { $, $$, debounce, escapeHtml } from "./dom.js";
import { runScript } from "./actions.js";
import { openInNewTab } from "./editor.js";
import { goToPage } from "./nav.js";
import { toast } from "./toast.js";

const SB_BASE = "https://scriptblox.com";

export const LIBRARY = [
  {
    id: "iy",
    name: "Infinite Yield",
    category: "Universal / Admin",
    featured: true,
    hasKey: false,
    verified: true,
    notPatched: true,
    views: 892100,
    likes: 8920,
    source: "scriptblox",
    imageUrl: "https://scriptblox.com/images/script/0-1786720891617.png",
    code: `loadstring(game:HttpGet("https://raw.githubusercontent.com/edgeiy/infiniteyield/master/source", true))()`
  },
  {
    id: "dex",
    name: "Dex Explorer",
    category: "Universal / Debugger",
    featured: true,
    hasKey: false,
    verified: true,
    notPatched: true,
    views: 325400,
    likes: 3180,
    source: "scriptblox",
    imageUrl: "https://scriptblox.com/images/script/0-1790359540636.jpg",
    code: `loadstring(game:HttpGet("https://raw.githubusercontent.com/peyton2465/Dex/master/out.lua"))()`
  },
  {
    id: "qo",
    name: "Quantum Onyx Project",
    category: "Universal",
    featured: true,
    hasKey: false,
    verified: false,
    notPatched: true,
    views: 412848,
    likes: 405,
    source: "rscripts",
    imageUrl: "https://scriptblox.com/images/script/-1-1790125848725.png",
    code: `loadstring(game:HttpGet("https://raw.githubusercontent.com/QuantumOnyx/Loader/main/source.lua"))()`
  },
  {
    id: "skysaken",
    name: 'Forsaken new script "Skysaken"',
    category: "Universal",
    featured: true,
    hasKey: false,
    verified: false,
    notPatched: true,
    views: 42948,
    likes: 484,
    source: "rscripts",
    imageUrl: "https://scriptblox.com/images/script/18687417158-1789721518787.png",
    code: `loadstring(game:HttpGet("https://raw.githubusercontent.com/Skysaken/Forsaken/main/loader.lua"))()`
  },
  {
    id: "sirmeme",
    name: "Sir Meme Hub Premium Script",
    category: "Universal",
    featured: true,
    hasKey: false,
    verified: false,
    notPatched: true,
    views: 317,
    likes: 5,
    source: "rscripts",
    imageUrl: "https://scriptblox.com/images/script/77463332823746-1788444130974.png",
    code: `loadstring(game:HttpGet("https://raw.githubusercontent.com/SirMeme/SirMemeHub/main/loader.lua"))()`
  },
  {
    id: "rendex",
    name: "Rendex Hub Keyless Free Script",
    category: "Jailbreak",
    featured: true,
    hasKey: false,
    verified: false,
    notPatched: true,
    views: 775,
    likes: 3,
    source: "rscripts",
    imageUrl: "https://scriptblox.com/images/script/-1-1781532607378.png",
    code: `loadstring(game:HttpGet("https://raw.githubusercontent.com/RendexHub/Jailbreak/main/loader.lua"))()`
  },
  {
    id: "aimbot404",
    name: "KEYLESS Best Universal Aimbot",
    category: "Universal Script 📌",
    featured: false,
    hasKey: false,
    verified: false,
    notPatched: true,
    views: 33750,
    likes: 0,
    source: "rscripts",
    imageUrl: "https://scriptblox.com/images/script/0-1783804467465.png",
    code: `loadstring(game:HttpGet("https://raw.githubusercontent.com/Exunys/Aimbot-V3/main/src/Aimbot.lua"))()`
  },
  {
    id: "byteuniv",
    name: "Byte Universal",
    category: "Byte Exclusive",
    featured: false,
    hasKey: false,
    verified: true,
    notPatched: true,
    views: 120400,
    likes: 1450,
    source: "robloxscripts",
    imageUrl: "https://scriptblox.com/images/script/0-1776305687740.png",
    code: `loadstring(game:HttpGet("https://raw.githubusercontent.com/user9127/byte-public/refs/heads/main/Byte-universal.lua", true))()`
  }
];

let activeSource = "rscripts";
let query = "";
let filterVerified = false;
let filterNoKey = false;
let filterNotPatched = true;
let sortBy = "latest";
let currentPage = 1;
let isLoading = false;
let allFetchedScripts = [...LIBRARY];

function getScriptImage(s) {
  let img = s.image;
  if (!img || img === "/images/no-script.webp") {
    img = s.game?.imageUrl;
  }
  if (!img || img === "/images/no-script.webp") return null;
  if (img.startsWith("http://") || img.startsWith("https://")) return img;
  if (img.startsWith("/")) return SB_BASE + img;
  return SB_BASE + "/" + img;
}

function formatNumber(num) {
  const n = Number(num) || 0;
  if (n >= 1000000) return (n / 1000000).toFixed(1) + "M";
  if (n >= 1000) return (n / 1000).toFixed(1) + "k";
  return n.toLocaleString();
}

function slug(name) {
  return (name || "script")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "") + ".lua";
}

async function fetchRealScripts() {
  const params = new URLSearchParams();
  params.set("page", String(currentPage));
  params.set("max", "20");

  if (filterVerified) params.set("verified", "1");
  if (filterNoKey) params.set("key", "0");
  if (filterNotPatched) params.set("patched", "0");

  if (activeSource === "robloxscripts") {
    params.set("universal", "1");
  }

  let url;
  if (query && query.trim()) {
    params.set("q", query.trim());
    url = `${SB_BASE}/api/script/search?${params}`;
  } else if (activeSource === "rscripts" || activeSource === "haxhell") {
    url = `${SB_BASE}/api/script/trending?${params}`;
  } else {
    url = `${SB_BASE}/api/script/fetch?${params}`;
  }

  try {
    const res = await fetch(url);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    return data?.result?.scripts || [];
  } catch (err) {
    console.warn("[Script Hub] Fetch failed, retrying with fallback endpoint:", err);
    try {
      const fallbackUrl = `${SB_BASE}/api/script/fetch?page=1&max=20`;
      const res = await fetch(fallbackUrl);
      const data = await res.json();
      return data?.result?.scripts || [];
    } catch (e2) {
      console.error("[Script Hub] Both fetch attempts failed:", e2);
      return [];
    }
  }
}

function normalizeScript(s, index = 0) {
  const title = s.title || s.name || "Untitled Script";
  const gameName = s.game?.name || (s.isUniversal ? "Universal Script 📌" : "Universal");
  const code = s.script || (s.slug ? `loadstring(game:HttpGet("https://rawscripts.net/raw/${s.slug}"))()` : "");

  return {
    id: s._id || String(index),
    name: title,
    category: gameName,
    featured: index < 6 && !query,
    hasKey: Boolean(s.key && !s.keyless),
    verified: Boolean(s.verified),
    notPatched: !s.isPatched,
    isUniversal: Boolean(s.isUniversal),
    views: Number(s.views) || 0,
    likes: Number(s.likeCount || s.executes) || 0,
    imageUrl: getScriptImage(s),
    code: code
  };
}

export async function runLibraryScript(s, button = null) {
  return runScript(s.code, { label: s.name, button });
}

export async function openLibraryScript(s) {
  try {
    const { recordRecent } = await import("./home.js");
    recordRecent({ name: s.name, libraryName: s.name, content: s.code });
  } catch (e) {
    console.warn("recordRecent failed:", e);
  }
  openInNewTab(slug(s.name), s.code);
  goToPage("execution");
  toast(`${s.name} opened in a new tab.`, "ok", 2000);
}

function createCard(s) {
  const card = document.createElement("div");
  card.className = "sh-card";
  card.dataset.id = s.id;

  const badges = [];
  if (s.featured) badges.push(`<span class="sh-badge badge-featured">★ Featured</span>`);
  if (s.hasKey) badges.push(`<span class="sh-badge badge-key">🔑 Key</span>`);
  if (s.verified) badges.push(`<span class="sh-badge badge-verified">✓ Verified</span>`);
  if (s.isUniversal) badges.push(`<span class="sh-badge badge-univ">Universal</span>`);

  const thumbHtml = s.imageUrl
    ? `<img class="sh-thumb-img" src="${escapeHtml(s.imageUrl)}" alt="${escapeHtml(s.name)}" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.style.display='grid'" /><div class="sh-thumb-placeholder" style="display:none"><svg viewBox="0 0 32 32" fill="none" width="28" height="28"><rect x="4" y="4" width="24" height="24" rx="4" stroke="#3f3f46" stroke-width="1.5"/><path d="M10 22 L16 12 L22 22" stroke="#71717a" stroke-width="1.5" stroke-linecap="round"/><circle cx="16" cy="10" r="2" fill="#71717a"/></svg></div>`
    : `<div class="sh-thumb-placeholder"><svg viewBox="0 0 32 32" fill="none" width="28" height="28"><rect x="4" y="4" width="24" height="24" rx="4" stroke="#3f3f46" stroke-width="1.5"/><path d="M10 22 L16 12 L22 22" stroke="#71717a" stroke-width="1.5" stroke-linecap="round"/><circle cx="16" cy="10" r="2" fill="#71717a"/></svg></div>`;

  card.innerHTML = `
    <div class="sh-card-thumb">
      ${thumbHtml}
      <div class="sh-badges-wrap">${badges.join("")}</div>
    </div>
    <div class="sh-card-body">
      <div class="sh-card-category" title="${escapeHtml(s.category)}">${escapeHtml(s.category)}</div>
      <h3 class="sh-card-title" title="${escapeHtml(s.name)}">${escapeHtml(s.name)}</h3>
      <div class="sh-card-footer">
        <div class="sh-card-stats">
          <span class="sh-stat-item" title="${s.views.toLocaleString()} views">
            <svg viewBox="0 0 16 16" fill="currentColor"><path d="M8 3.5C3.8 3.5 1.5 8 1.5 8s2.3 4.5 6.5 4.5 6.5-4.5 6.5-4.5-2.3-4.5-6.5-4.5zM8 10.5a2.5 2.5 0 1 1 0-5 2.5 2.5 0 0 1 0 5z"/></svg>
            <span>${formatNumber(s.views)}</span>
          </span>
          <span class="sh-stat-item" title="${s.likes.toLocaleString()} likes/executes">
            <svg viewBox="0 0 16 16" fill="currentColor"><path d="M8 13.5l-5.3-5.3a3.5 3.5 0 0 1 5-5L8 3.5l.3-.3a3.5 3.5 0 0 1 5 5z"/></svg>
            <span>${formatNumber(s.likes)}</span>
          </span>
        </div>
        <div class="sh-card-actions">
          <button class="sh-act-btn act-run" title="Run ${escapeHtml(s.name)}" aria-label="Run script">
            <svg viewBox="0 0 16 16" fill="currentColor"><path d="M4.5 2.8v10.4l8.3-5.2z"/></svg>
          </button>
          <button class="sh-act-btn act-open" title="Open ${escapeHtml(s.name)} in editor" aria-label="Open script">
            <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.3"><path d="M2 4.4c0-.6.4-1 1-1h3.1l1.5 1.5H13c.6 0 1 .4 1 1v6.6c0 .6-.4 1-1 1H3c-.6 0-1-.4-1-1z"/></svg>
          </button>
        </div>
      </div>
    </div>
  `;

  card.querySelector(".act-run")?.addEventListener("click", (e) => {
    e.stopPropagation();
    runLibraryScript(s, e.currentTarget);
  });

  card.querySelector(".act-open")?.addEventListener("click", (e) => {
    e.stopPropagation();
    openLibraryScript(s);
  });

  card.addEventListener("click", () => {
    openLibraryScript(s);
  });

  return card;
}

function renderScriptHub() {
  const featGrid = $("#sh-featured-grid");
  const commGrid = $("#sh-community-grid");
  const featSection = $("#sh-featured-section");
  const featCount = $("#sh-featured-count");
  const totalCountEl = $("#sh-results-count");

  if (!commGrid) return;

  let list = [...allFetchedScripts];

  if (sortBy === "views") {
    list.sort((a, b) => b.views - a.views);
  } else if (sortBy === "likes") {
    list.sort((a, b) => b.likes - a.likes);
  }

  if (filterVerified) list = list.filter((s) => s.verified);
  if (filterNoKey) list = list.filter((s) => !s.hasKey);
  if (filterNotPatched) list = list.filter((s) => s.notPatched);

  if (commGrid) commGrid.innerHTML = "";
  if (featGrid) featGrid.innerHTML = "";

  if (list.length === 0) {
    if (featSection) featSection.style.display = "none";
    commGrid.innerHTML = `
      <div style="grid-column: 1 / -1; padding: 48px; text-align: center; color: #71717a;">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="36" height="36" style="margin: 0 auto 12px; display: block; opacity: 0.5;">
          <circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>
        </svg>
        <p style="font-size: 13px;">No scripts found matching your filters.</p>
      </div>`;
    if (totalCountEl) totalCountEl.textContent = "0 results";
    return;
  }

  if (query) {
    if (featSection) featSection.style.display = "none";
    for (const s of list) {
      commGrid.appendChild(createCard(s));
    }
  } else {

    const featured = list.slice(0, 6);
    const community = list.slice(6);

    if (featSection && featGrid && featured.length > 0) {
      featSection.style.display = "";
      if (featCount) featCount.textContent = featured.length;
      for (const s of featured) {
        featGrid.appendChild(createCard({ ...s, featured: true }));
      }
    } else if (featSection) {
      featSection.style.display = "none";
    }

    for (const s of (community.length > 0 ? community : featured)) {
      commGrid.appendChild(createCard(s));
    }
  }

  if (totalCountEl) {
    totalCountEl.textContent = `${list.length} results`;
  }

  const scrollBody = document.querySelector(".sh-scroll-body");
  if (scrollBody && !query) {
    scrollBody.scrollTop = 0;
  }
}

async function loadScripts() {
  if (isLoading) return;
  isLoading = true;

  const commGrid = $("#sh-community-grid");
  const featSection = $("#sh-featured-section");
  const totalCountEl = $("#sh-results-count");

  if (totalCountEl) totalCountEl.textContent = "Fetching live scripts…";

  if (commGrid) {
    commGrid.innerHTML = Array(10)
      .fill(
        `<div class="sh-card" style="pointer-events: none; opacity: 0.5;">
          <div class="sh-card-thumb" style="background: #181820; animation: pulse 1.5s infinite ease-in-out;"></div>
          <div class="sh-card-body" style="padding: 10px;">
            <div style="height: 10px; width: 50%; background: #27272a; border-radius: 3px; margin-bottom: 8px;"></div>
            <div style="height: 14px; width: 85%; background: #27272a; border-radius: 3px;"></div>
          </div>
        </div>`
      )
      .join("");
  }

  try {
    const rawScripts = await fetchRealScripts();
    allFetchedScripts = rawScripts.map((s, idx) => normalizeScript(s, idx));
  } catch (err) {
    console.error("[Script Hub] Load error:", err);
  } finally {
    isLoading = false;
    renderScriptHub();
  }
}

export function focusLibrarySearch() {
  const s = $("#sh-search-input");
  if (s) {
    s.focus();
    s.select();
  }
}

export function initLibrary() {
  const sourceButtons = $$("#sh-sources-list .sh-nav-btn");
  const searchInput = $("#sh-search-input");

  sourceButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      sourceButtons.forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      activeSource = btn.dataset.source || "rscripts";
      const srcName = btn.querySelector("span")?.textContent || "scripts";
      if (searchInput) searchInput.placeholder = `Search ${srcName}...`;
      loadScripts();
    });
  });

  $("#sh-filter-verified")?.addEventListener("change", (e) => {
    filterVerified = e.target.checked;
    loadScripts();
  });
  $("#sh-filter-nokey")?.addEventListener("change", (e) => {
    filterNoKey = e.target.checked;
    loadScripts();
  });
  $("#sh-filter-notpatched")?.addEventListener("change", (e) => {
    filterNotPatched = e.target.checked;
    loadScripts();
  });

  $$('input[name="sh-sort"]').forEach((radio) => {
    radio.addEventListener("change", (e) => {
      sortBy = e.target.value;
      renderScriptHub();
    });
  });

  if (searchInput) {
    const runSearch = debounce(() => {
      query = searchInput.value.trim();
      loadScripts();
    }, 350);

    searchInput.addEventListener("input", runSearch);
    searchInput.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        e.stopPropagation();
        if (searchInput.value) {
          searchInput.value = "";
          query = "";
          loadScripts();
        } else {
          searchInput.blur();
        }
      }
      if (e.key === "Enter") {
        query = searchInput.value.trim();
        loadScripts();
      }
    });
  }

  $("#sh-featured-toggle")?.addEventListener("click", () => {
    $("#sh-featured-section")?.classList.toggle("collapsed");
  });

  loadScripts();
}

export function libraryRows() {
  return $$(".sh-card");
}
