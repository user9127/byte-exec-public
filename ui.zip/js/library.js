import { $, $$, debounce, escapeHtml } from "./dom.js";
import { runScript } from "./actions.js";
import { openInNewTab } from "./editor.js";
import { goToPage } from "./nav.js";
import { toast } from "./toast.js";
import { isStandalone } from "./bridge.js";

const SB_BASE = "https://scriptblox.com";

export const LIBRARY = [
  {
    id: "iy",
    name: "Infinite Yield",
    category: "Universal / Admin",
    featured: true,
    hasKey: false,
    verified: true,
    notPatched: true,
    views: 892100,
    likes: 8920,
    source: "scriptblox",
    imageUrl: "https://scriptblox.com/images/script/0-1786720891617.png",
    code: `loadstring(game:HttpGet("https://raw.githubusercontent.com/edgeiy/infiniteyield/master/source", true))()`
  },
  {
    id: "dex",
    name: "Dex Explorer",
    category: "Universal / Debugger",
    featured: true,
    hasKey: false,
    verified: true,
    notPatched: true,
    views: 325400,
    likes: 3180,
    source: "scriptblox",
    imageUrl: "https://scriptblox.com/images/script/0-1790359540636.jpg",
    code: `loadstring(game:HttpGet("https://raw.githubusercontent.com/peyton2465/Dex/master/out.lua"))()`
  },
  {
    id: "qo",
    name: "Quantum Onyx Project",
    category: "Universal",
    featured: true,
    hasKey: false,
    verified: false,
    notPatched: true,
    views: 412848,
    likes: 405,
    source: "rscripts",
    imageUrl: "https://scriptblox.com/images/script/-1-1790125848725.png",
    code: `loadstring(game:HttpGet("https://raw.githubusercontent.com/QuantumOnyx/Loader/main/source.lua"))()`
  },
  {
    id: "skysaken",
    name: 'Forsaken new script "Skysaken"',
    category: "Universal",
    featured: true,
    hasKey: false,
    verified: false,
    notPatched: true,
    views: 42948,
    likes: 484,
    source: "rscripts",
    imageUrl: "https://scriptblox.com/images/script/18687417158-1789721518787.png",
    code: `loadstring(game:HttpGet("https://raw.githubusercontent.com/Skysaken/Forsaken/main/loader.lua"))()`
  },
  {
    id: "sirmeme",
    name: "Sir Meme Hub Premium Script",
    category: "Universal",
    featured: true,
    hasKey: false,
    verified: false,
    notPatched: true,
    views: 317,
    likes: 5,
    source: "rscripts",
    imageUrl: "https://scriptblox.com/images/script/77463332823746-1788444130974.png",
    code: `loadstring(game:HttpGet("https://raw.githubusercontent.com/SirMeme/SirMemeHub/main/loader.lua"))()`
  },
  {
    id: "rendex",
    name: "Rendex Hub Keyless Free Script",
    category: "Jailbreak",
    featured: true,
    hasKey: false,
    verified: false,
    notPatched: true,
    views: 775,
    likes: 3,
    source: "rscripts",
    imageUrl: "https://scriptblox.com/images/script/-1-1781532607378.png",
    code: `loadstring(game:HttpGet("https://raw.githubusercontent.com/RendexHub/Jailbreak/main/loader.lua"))()`
  },
  {
    id: "aimbot404",
    name: "KEYLESS Best Universal Aimbot",
    category: "Universal Script 📌",
    featured: false,
    hasKey: false,
    verified: false,
    notPatched: true,
    views: 33750,
    likes: 0,
    source: "rscripts",
    imageUrl: "https://scriptblox.com/images/script/0-1783804467465.png",
    code: `loadstring(game:HttpGet("https://raw.githubusercontent.com/Exunys/Aimbot-V3/main/src/Aimbot.lua"))()`
  },
  {
    id: "byteuniv",
    name: "Byte Universal",
    category: "Byte Exclusive",
    featured: false,
    hasKey: false,
    verified: true,
    notPatched: true,
    views: 120400,
    likes: 1450,
    source: "robloxscripts",
    imageUrl: "https://scriptblox.com/images/script/0-1776305687740.png",
    code: `loadstring(game:HttpGet("https://raw.githubusercontent.com/user9127/byte-public/refs/heads/main/Byte-universal.lua", true))()`
  }
];

const RIXEL_BASE = "https://script.rixeldev.lol/api/v1";
export const RIXEL_LOADER = 'loadstring(game:HttpGet("https://raw.githubusercontent.com/NotRainYuu/RixelDev/main/loader.lua"))()';

const KNOWN_ROBLOX_ICONS = {
  155615604: "https://tr.rbxcdn.com/180DAY-fee67c1f98361eac15c13f80b03592ae/512/512/Image/Png/noFilter",
  2753915549: "https://tr.rbxcdn.com/180DAY-774ec14539b264f85fdb6e8a34dfa344/512/512/Image/Png/noFilter",
  142823291: "https://tr.rbxcdn.com/180DAY-1a6659f136faad9824c139db03c05423/512/512/Image/Png/noFilter",
  16732694052: "https://tr.rbxcdn.com/180DAY-dbde69d2d079ec6582d8ac76faf036fd/512/512/Image/Png/noFilter",
  6872265039: "https://tr.rbxcdn.com/180DAY-7641e74828f27422284278b2036e7f01/512/512/Image/Png/noFilter",
  17017769292: "https://tr.rbxcdn.com/180DAY-2ef69e4e4d0be01a2b12ecb16536d54f/512/512/Image/Png/noFilter",
  286090429: "https://tr.rbxcdn.com/180DAY-29023c3f115f5eac513c836ef674fd42/512/512/Image/Png/noFilter",
  13772394625: "https://tr.rbxcdn.com/180DAY-4ff6f1b3e9a7e6ec33c3a9fbf1b3a4c5/512/512/Image/Png/noFilter",
  17625359962: "https://tr.rbxcdn.com/180DAY-cb3db0a4eb4d0b1ea4c94f54e4f61f73/512/512/Image/Png/noFilter",
  8737899170: "https://tr.rbxcdn.com/180DAY-a5ba2e4c84db8a2b53f65b4c4ba8b6f5/512/512/Image/Png/noFilter",
  12552538292: "https://tr.rbxcdn.com/180DAY-e8e3bc7c68ba01b7a6e114ba52f75fb1/512/512/Image/Png/noFilter",
  2788229376: "https://tr.rbxcdn.com/180DAY-c7be93822ba91ec1b1e6264d1f2b67f1/512/512/Image/Png/noFilter",
  9872472334: "https://tr.rbxcdn.com/180DAY-9ea5ec76495be1c6a0bb6c8a709214b6/512/512/Image/Png/noFilter",
  1962086868: "https://tr.rbxcdn.com/180DAY-31b017b2b5f6393b5a76e9389283f5fb/512/512/Image/Png/noFilter",
  3475397644: "https://tr.rbxcdn.com/180DAY-ba2402d2d5bc384d2497a9676e070fca/512/512/Image/Png/noFilter",
  0: "https://tr.rbxcdn.com/180DAY-fee67c1f98361eac15c13f80b03592ae/512/512/Image/Png/noFilter"
};

const RIXEL_SCRIPTS_DATA = [
  {
    placeId: 155615604,
    name: "Prison Life",
    category: "Prison Life",
    slug: "prison-life",
    thumbnail: "https://tr.rbxcdn.com/180DAY-fee67c1f98361eac15c13f80b03592ae/512/512/Image/Png/noFilter",
    status: "Operational",
    verified: true,
    requiresKey: false,
    features: ["Silent Aim", "Gun Mod", "Auto Escape", "Kill Aura", "WalkSpeed"],
    loader: RIXEL_LOADER,
    views: 452100,
    likes: 8930
  },
  {
    placeId: 2753915549,
    name: "Blox Fruits",
    category: "Blox Fruits",
    slug: "blox-fruits",
    thumbnail: "https://tr.rbxcdn.com/180DAY-774ec14539b264f85fdb6e8a34dfa344/512/512/Image/Png/noFilter",
    status: "Operational",
    verified: true,
    requiresKey: false,
    features: ["Auto Farm Level", "Fruit Mastery", "Auto Raid", "Teleports", "ESP"],
    loader: RIXEL_LOADER,
    views: 1250000,
    likes: 24100
  },
  {
    placeId: 13772394625,
    name: "Blade Ball",
    category: "Blade Ball",
    slug: "blade-ball",
    thumbnail: "https://tr.rbxcdn.com/180DAY-38e75c9ff1051ad6ca868f39be2cf095/512/512/Image/Png/noFilter",
    status: "Operational",
    verified: true,
    requiresKey: false,
    features: ["Auto Parry", "Manual Curve", "Spam Block", "Visualizer", "Auto Skills"],
    loader: RIXEL_LOADER,
    views: 890000,
    likes: 15400
  },
  {
    placeId: 17625359962,
    name: "Rivals",
    category: "Rivals",
    slug: "rivals",
    thumbnail: "https://tr.rbxcdn.com/180DAY-b2b718b190726ac0e498f3fd3afc30d9/512/512/Image/Png/noFilter",
    status: "Operational",
    verified: true,
    requiresKey: false,
    features: ["Silent Aim", "Hitbox Expander", "ESP", "Weapon Mod", "Fast Reload"],
    loader: RIXEL_LOADER,
    views: 620000,
    likes: 11200
  },
  {
    placeId: 4924922222,
    name: "Brookhaven 🏡RP",
    category: "Brookhaven RP",
    slug: "brookhaven-rp",
    thumbnail: "https://tr.rbxcdn.com/180DAY-245d78e6940e8cce07af3874cb58f021/512/512/Image/Png/noFilter",
    status: "Operational",
    verified: true,
    requiresKey: false,
    features: ["Unlock All Gamepasses", "Rainbow Car", "House Spawner", "Fly", "Troll Tools"],
    loader: RIXEL_LOADER,
    views: 940000,
    likes: 18500
  },
  {
    placeId: 2788229376,
    name: "Da Hood",
    category: "Da Hood",
    slug: "da-hood",
    thumbnail: "https://tr.rbxcdn.com/180DAY-f231e4a78fc6736aa5e1a360f7f613fc/512/512/Image/Png/noFilter",
    status: "Operational",
    verified: true,
    requiresKey: false,
    features: ["CamLock", "Target Strafe", "Auto Stomp", "Anti-Lock", "Macro Speed"],
    loader: RIXEL_LOADER,
    views: 710000,
    likes: 13900
  },
  {
    placeId: 4520749081,
    name: "King Legacy",
    category: "King Legacy",
    slug: "king-legacy",
    thumbnail: "https://tr.rbxcdn.com/180DAY-8d0a42cbf6f6c05180a90b8f99a5eb72/512/512/Image/Png/noFilter",
    status: "Operational",
    verified: true,
    requiresKey: false,
    features: ["Auto Farm", "Sea Beast Auto", "Fast Attack", "Dungeon", "Fruit Sniper"],
    loader: RIXEL_LOADER,
    views: 530000,
    likes: 9800
  },
  {
    placeId: 8737899170,
    name: "Pet Simulator 99",
    category: "Pet Simulator 99",
    slug: "pet-simulator-99",
    thumbnail: "https://tr.rbxcdn.com/180DAY-e42ef6e926279c8265b931c9b335c41d/512/512/Image/Png/noFilter",
    status: "Operational",
    verified: true,
    requiresKey: false,
    features: ["Auto Farm Coins", "Auto Hatch", "Area Unlocker", "Pet Dupe Glitch", "ESP"],
    loader: RIXEL_LOADER,
    views: 680000,
    likes: 12400
  },
  {
    placeId: 142823291,
    name: "Murder Mystery 2",
    category: "Murder Mystery 2",
    slug: "murder-mystery-2",
    thumbnail: "https://tr.rbxcdn.com/180DAY-3ac5af325970a745b0156a5358174169/512/512/Image/Png/noFilter",
    status: "Operational",
    verified: true,
    requiresKey: false,
    features: ["Sheriff Aim", "Gun ESP", "Coin Auto Farm", "Grab Gun", "Role Revealer"],
    loader: RIXEL_LOADER,
    views: 810000,
    likes: 16700
  },
  {
    placeId: 16732694052,
    name: "Fisch",
    category: "Fisch",
    slug: "fisch",
    thumbnail: "https://tr.rbxcdn.com/180DAY-dbde69d2d079ec6582d8ac76faf036fd/512/512/Image/Png/noFilter",
    status: "Operational",
    verified: true,
    requiresKey: false,
    features: ["Auto Shake", "Auto Reel", "Instant Catch", "Fish Radar", "Infinite Oxygen"],
    loader: RIXEL_LOADER,
    views: 740000,
    likes: 14300
  },
  {
    placeId: 6872265039,
    name: "BedWars",
    category: "BedWars",
    slug: "bedwars",
    thumbnail: "https://tr.rbxcdn.com/180DAY-7641e74828f27422284278b2036e7f01/512/512/Image/Png/noFilter",
    status: "Operational",
    verified: true,
    requiresKey: false,
    features: ["Killaura", "Speed Fly", "Bed Nuker", "Chest Stealer", "Auto Win"],
    loader: RIXEL_LOADER,
    views: 490000,
    likes: 8600
  },
  {
    placeId: 17017769292,
    name: "Anime Defenders",
    category: "Anime Defenders",
    slug: "anime-defenders",
    thumbnail: "https://tr.rbxcdn.com/180DAY-2ef69e4e4d0be01a2b12ecb16536d54f/512/512/Image/Png/noFilter",
    status: "Operational",
    verified: true,
    requiresKey: false,
    features: ["Macro Auto Story", "Infinite Challenge", "Auto Place", "Auto Upgrade", "Reroll"],
    loader: RIXEL_LOADER,
    views: 430000,
    likes: 7900
  },
  {
    placeId: 286090429,
    name: "Arsenal",
    category: "Arsenal",
    slug: "arsenal",
    thumbnail: "https://tr.rbxcdn.com/180DAY-29023c3f115f5eac513c836ef674fd42/512/512/Image/Png/noFilter",
    status: "Operational",
    verified: true,
    requiresKey: false,
    features: ["Aimbot", "Wallbang", "Silent Aim", "Infinite Ammo", "Fast Fire"],
    loader: RIXEL_LOADER,
    views: 920000,
    likes: 19800
  },
  {
    placeId: 0,
    name: "Rixel Hub Multi-Game Loader",
    category: "Universal / 377+ Games",
    slug: "rixel-hub-universal",
    thumbnail: "https://tr.rbxcdn.com/180DAY-fee67c1f98361eac15c13f80b03592ae/512/512/Image/Png/noFilter",
    status: "Operational",
    verified: true,
    requiresKey: false,
    features: ["Auto Detect Game", "Auto Load Features", "Multi-Game Hub Support", "Bypass System"],
    loader: RIXEL_LOADER,
    views: 1890000,
    likes: 38200
  }
];

let activeSource = "rixel";
let query = "";
let filterVerified = false;
let filterNoKey = false;
let filterNotPatched = true;
let sortBy = "latest";
let currentPage = 1;
let isLoading = false;
let allFetchedScripts = [...LIBRARY];

function getScriptImage(s) {
  let img = s.image || s.thumbnail;
  if (!img || img === "/images/no-script.webp") {
    img = s.game?.imageUrl;
  }
  if (!img || img === "/images/no-script.webp") return null;
  if (img.startsWith("http://") || img.startsWith("https://")) return img;
  if (img.startsWith("/")) return SB_BASE + img;
  return SB_BASE + "/" + img;
}

function formatNumber(num) {
  const n = Number(num) || 0;
  if (n >= 1000000) return (n / 1000000).toFixed(1) + "M";
  if (n >= 1000) return (n / 1000).toFixed(1) + "k";
  return n.toLocaleString();
}

function slug(name) {
  return (name || "script")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "") + ".lua";
}

async function fetchRealScripts() {
  if (activeSource === "rixel") {
    const params = new URLSearchParams();
    params.set("page", "1");
    params.set("limit", "100");
    if (query && query.trim()) {
      params.set("q", query.trim());
    }

    try {
      const res = await fetch(`${RIXEL_BASE}/scripts?${params}`, {
        headers: { Accept: "application/json" }
      });
      if (res.ok) {
        const text = await res.text();
        let data = null;
        try {
          data = JSON.parse(text);
        } catch {
          data = null;
        }
        if (data && data.success && Array.isArray(data.data) && data.data.length > 0) {
          let scripts = [...data.data];

          // 如果没有特定搜索词，且总页数大于 1，自动并发拉取剩余页面，聚合出全部 377+ 款游戏！
          const totalPages = data.totalPages || (data.total ? Math.ceil(data.total / 100) : 1);
          if (!query && totalPages > 1) {
            const pagePromises = [];
            for (let p = 2; p <= totalPages; p++) {
              const pParams = new URLSearchParams();
              pParams.set("page", String(p));
              pParams.set("limit", "100");
              pagePromises.push(
                fetch(`${RIXEL_BASE}/scripts?${pParams}`, {
                  headers: { Accept: "application/json" }
                })
                  .then((r) => r.json())
                  .then((d) => (d?.success && Array.isArray(d.data) ? d.data : []))
                  .catch(() => [])
              );
            }
            const extraPages = await Promise.all(pagePromises);
            for (const pageScripts of extraPages) {
              scripts = scripts.concat(pageScripts);
            }
          }

          // 1. 优先使用已知热门游戏的官方 CDN 高清直链
          for (const s of scripts) {
            if (s.placeId && KNOWN_ROBLOX_ICONS[s.placeId]) {
              s.thumbnail = KNOWN_ROBLOX_ICONS[s.placeId];
            }
          }

          // 2. 批量解析剩余未直接命中的 Roblox 游戏真实直链
          const placeIdsToFetch = scripts
            .map((s) => s.placeId)
            .filter((id) => Boolean(id) && id > 0 && !KNOWN_ROBLOX_ICONS[id]);

          if (placeIdsToFetch.length > 0) {
            try {
              const uniqueIds = Array.from(new Set(placeIdsToFetch));
              const chunks = [];
              for (let i = 0; i < uniqueIds.length; i += 50) {
                chunks.push(uniqueIds.slice(i, i + 50));
              }
              const iconMaps = await Promise.all(
                chunks.map(async (chunk) => {
                  try {
                    const endpoint = isStandalone
                      ? `/roblox-icons?placeIds=${chunk.join(",")}`
                      : `https://thumbnails.roproxy.com/v1/places/gameicons?placeIds=${chunk.join(",")}&size=512x512&format=Png&isCircular=false`;
                    const iconRes = await fetch(endpoint, { signal: AbortSignal.timeout(4000) });
                    if (!iconRes.ok) return {};
                    const iconData = await iconRes.json();
                    const map = {};
                    if (Array.isArray(iconData?.data)) {
                      for (const item of iconData.data) {
                        if (item.targetId && item.imageUrl) {
                          map[item.targetId] = item.imageUrl;
                        }
                      }
                    }
                    return map;
                  } catch {
                    return {};
                  }
                })
              );
              const mergedMap = Object.assign({}, ...iconMaps);
              for (const s of scripts) {
                if (s.placeId && mergedMap[s.placeId]) {
                  s.thumbnail = mergedMap[s.placeId];
                } else if (typeof s.thumbnail === "string" && s.thumbnail.includes("/places/gameicons")) {
                  s.thumbnail = null;
                }
              }
            } catch (iconErr) {
              console.warn("[Script Hub] Failed to batch resolve Roblox icons:", iconErr);
            }
          }

          return scripts;
        }
      }
    } catch (err) {
      console.warn("[Script Hub] Rixel API fetch failed, using curated dataset:", err);
    }

    // Fallback: curated Rixel Hub scripts with search and filters
    const q = (query || "").toLowerCase().trim();
    let list = [...RIXEL_SCRIPTS_DATA];
    if (q) {
      list = list.filter((item) => {
        return (
          item.name.toLowerCase().includes(q) ||
          item.category.toLowerCase().includes(q) ||
          String(item.placeId).includes(q) ||
          (Array.isArray(item.features) && item.features.some((f) => f.toLowerCase().includes(q)))
        );
      });
    }
    return list;
  }

  const params = new URLSearchParams();
  params.set("page", String(currentPage));
  params.set("max", "20");

  if (filterVerified) params.set("verified", "1");
  if (filterNoKey) params.set("key", "0");
  if (filterNotPatched) params.set("patched", "0");

  if (activeSource === "robloxscripts") {
    params.set("universal", "1");
  }

  let url;
  if (query && query.trim()) {
    params.set("q", query.trim());
    url = `${SB_BASE}/api/script/search?${params}`;
  } else if (activeSource === "rscripts" || activeSource === "haxhell") {
    url = `${SB_BASE}/api/script/trending?${params}`;
  } else {
    url = `${SB_BASE}/api/script/fetch?${params}`;
  }

  try {
    const res = await fetch(url);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    return data?.result?.scripts || [];
  } catch (err) {
    console.warn("[Script Hub] Fetch failed, retrying with fallback endpoint:", err);
    try {
      const fallbackUrl = `${SB_BASE}/api/script/fetch?page=1&max=20`;
      const res = await fetch(fallbackUrl);
      const data = await res.json();
      return data?.result?.scripts || [];
    } catch (e2) {
      console.error("[Script Hub] Both fetch attempts failed:", e2);
      return [];
    }
  }
}

function normalizeScript(s, index = 0) {
  const isRixel = activeSource === "rixel" || Boolean(s.loader) || Boolean(s.placeId !== undefined);
  const title = s.title || (isRixel ? (s.name?.startsWith("Rixel") ? s.name : `Rixel Hub - ${s.name}`) : s.name) || "Untitled Script";
  const gameName = s.category || (s.placeId ? `${s.name || "Game"} [${s.placeId}]` : (s.game?.name || (s.isUniversal ? "Universal Script 📌" : "Universal")));
  const code = s.loader || s.script || (s.slug ? `loadstring(game:HttpGet("https://rawscripts.net/raw/${s.slug}"))()` : "");

  let img = s.thumbnail || getScriptImage(s);
  if (typeof img === "string" && img.includes("/places/gameicons")) {
    img = (s.placeId && KNOWN_ROBLOX_ICONS[s.placeId]) || null;
  }

  return {
    id: s.placeId !== undefined ? `rixel-${s.placeId}` : (s._id || String(index)),
    placeId: s.placeId,
    name: title,
    category: gameName,
    featured: (activeSource === "rixel" ? index < 12 : index < 6) && !query,
    // Rixel scripts are keyless; the Byte license gate is separate.
    hasKey: isRixel ? false : Boolean(s.requiresKey ?? (s.key && !s.keyless)),
    verified: Boolean(s.verified ?? true),
    notPatched: s.status ? s.status.toLowerCase() === "operational" : !s.isPatched,
    isUniversal: Boolean(s.isUniversal || s.placeId === 0),
    views: Number(s.views) || (isRixel ? 245000 - index * 620 : 0),
    likes: Number(s.likeCount || s.likes || s.executes) || (isRixel ? 2840 - index * 6 : 0),
    imageUrl: img,
    code: code
  };
}

export async function runLibraryScript(s, button = null) {
  return runScript(s.code, { label: s.name, button });
}

export async function openLibraryScript(s) {
  try {
    const { recordRecent } = await import("./home.js");
    recordRecent({ name: s.name, libraryName: s.name, content: s.code });
  } catch (e) {
    console.warn("recordRecent failed:", e);
  }
  openInNewTab(slug(s.name), s.code);
  goToPage("execution");
  toast(`${s.name} opened in a new tab.`, "ok", 2000);
}

function createCard(s) {
  const card = document.createElement("div");
  card.className = "sh-card";
  card.dataset.id = s.id;

  const badges = [];
  if (s.featured) badges.push(`<span class="sh-badge badge-featured">★ Featured</span>`);
  if (s.hasKey) badges.push(`<span class="sh-badge badge-key">🔑 Key</span>`);
  if (s.verified) badges.push(`<span class="sh-badge badge-verified">✓ Verified</span>`);
  if (s.isUniversal) badges.push(`<span class="sh-badge badge-univ">Universal</span>`);

  const rawName = (s.name || "Game").replace(/^Rixel Hub - /, "");
  const initials = escapeHtml(rawName.slice(0, 2).toUpperCase());

  const thumbHtml = s.imageUrl
    ? `<img class="sh-thumb-img" src="${escapeHtml(s.imageUrl)}" alt="${escapeHtml(s.name)}" loading="lazy" onerror="this.style.display='none';if(this.nextElementSibling)this.nextElementSibling.style.display='grid';" /><div class="sh-thumb-placeholder" style="display:none"><span class="sh-thumb-initial">${initials}</span></div>`
    : `<div class="sh-thumb-placeholder"><span class="sh-thumb-initial">${initials}</span></div>`;

  card.innerHTML = `
    <div class="sh-card-thumb">
      ${thumbHtml}
      <div class="sh-badges-wrap">${badges.join("")}</div>
    </div>
    <div class="sh-card-body">
      <div class="sh-card-category" title="${escapeHtml(s.category)}">${escapeHtml(s.category)}</div>
      <h3 class="sh-card-title" title="${escapeHtml(s.name)}">${escapeHtml(s.name)}</h3>
      <div class="sh-card-footer">
        <div class="sh-card-stats">
          <span class="sh-stat-item" title="${s.views.toLocaleString()} views">
            <svg viewBox="0 0 16 16" fill="currentColor"><path d="M8 3.5C3.8 3.5 1.5 8 1.5 8s2.3 4.5 6.5 4.5 6.5-4.5 6.5-4.5-2.3-4.5-6.5-4.5zM8 10.5a2.5 2.5 0 1 1 0-5 2.5 2.5 0 0 1 0 5z"/></svg>
            <span>${formatNumber(s.views)}</span>
          </span>
          <span class="sh-stat-item" title="${s.likes.toLocaleString()} likes/executes">
            <svg viewBox="0 0 16 16" fill="currentColor"><path d="M8 13.5l-5.3-5.3a3.5 3.5 0 0 1 5-5L8 3.5l.3-.3a3.5 3.5 0 0 1 5 5z"/></svg>
            <span>${formatNumber(s.likes)}</span>
          </span>
        </div>
        <div class="sh-card-actions">
          <button class="sh-act-btn act-run" title="Run ${escapeHtml(s.name)}" aria-label="Run script">
            <svg viewBox="0 0 16 16" fill="currentColor"><path d="M4.5 2.8v10.4l8.3-5.2z"/></svg>
          </button>
          <button class="sh-act-btn act-open" title="Open ${escapeHtml(s.name)} in editor" aria-label="Open script">
            <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.3"><path d="M2 4.4c0-.6.4-1 1-1h3.1l1.5 1.5H13c.6 0 1 .4 1 1v6.6c0 .6-.4 1-1 1H3c-.6 0-1-.4-1-1z"/></svg>
          </button>
        </div>
      </div>
    </div>
  `;

  card.querySelector(".act-run")?.addEventListener("click", (e) => {
    e.stopPropagation();
    runLibraryScript(s, e.currentTarget);
  });

  card.querySelector(".act-open")?.addEventListener("click", (e) => {
    e.stopPropagation();
    openLibraryScript(s);
  });

  card.addEventListener("click", () => {
    openLibraryScript(s);
  });

  return card;
}

function renderScriptHub() {
  const featGrid = $("#sh-featured-grid");
  const commGrid = $("#sh-community-grid");
  const featSection = $("#sh-featured-section");
  const featCount = $("#sh-featured-count");
  const totalCountEl = $("#sh-results-count");

  if (!commGrid) return;

  let list = [...allFetchedScripts];

  if (sortBy === "views") {
    list.sort((a, b) => b.views - a.views);
  } else if (sortBy === "likes") {
    list.sort((a, b) => b.likes - a.likes);
  }

  if (filterVerified) list = list.filter((s) => s.verified);
  if (filterNoKey) list = list.filter((s) => !s.hasKey);
  if (filterNotPatched) list = list.filter((s) => s.notPatched);

  if (commGrid) commGrid.innerHTML = "";
  if (featGrid) featGrid.innerHTML = "";

  if (list.length === 0) {
    if (featSection) featSection.style.display = "none";
    const emptyMsg = activeSource === "rixel" 
      ? (query ? `No Rixel scripts found for "${escapeHtml(query)}".` : "No scripts available in Rixel scripts.") 
      : "No scripts found matching your filters.";
    commGrid.innerHTML = `
      <div style="grid-column: 1 / -1; padding: 48px; text-align: center; color: #71717a;">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="36" height="36" style="margin: 0 auto 12px; display: block; opacity: 0.5;">
          <circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>
        </svg>
        <p style="font-size: 13px;">${emptyMsg}</p>
      </div>`;
    if (totalCountEl) totalCountEl.textContent = "0 results";
    return;
  }

  if (query) {
    if (featSection) featSection.style.display = "none";
    for (const s of list) {
      commGrid.appendChild(createCard(s));
    }
  } else {
    const featLimit = activeSource === "rixel" ? 12 : 6;
    const featured = list.slice(0, featLimit);
    const community = list.slice(featLimit);

    if (featSection && featGrid && featured.length > 0) {
      featSection.style.display = "";
      if (featCount) featCount.textContent = featured.length;
      for (const s of featured) {
        featGrid.appendChild(createCard({ ...s, featured: true }));
      }
    } else if (featSection) {
      featSection.style.display = "none";
    }

    for (const s of (community.length > 0 ? community : featured)) {
      commGrid.appendChild(createCard(s));
    }
  }

  if (totalCountEl) {
    totalCountEl.textContent = `${list.length} results`;
  }

  const scrollBody = document.querySelector(".sh-scroll-body");
  if (scrollBody && !query) {
    scrollBody.scrollTop = 0;
  }
}

async function loadScripts() {
  if (isLoading) return;
  isLoading = true;

  const commGrid = $("#sh-community-grid");
  const featSection = $("#sh-featured-section");
  const totalCountEl = $("#sh-results-count");

  if (totalCountEl) totalCountEl.textContent = "Fetching live scripts…";

  if (commGrid) {
    commGrid.innerHTML = Array(10)
      .fill(
        `<div class="sh-card" style="pointer-events: none; opacity: 0.5;">
          <div class="sh-card-thumb" style="background: #181820; animation: pulse 1.5s infinite ease-in-out;"></div>
          <div class="sh-card-body" style="padding: 10px;">
            <div style="height: 10px; width: 50%; background: #27272a; border-radius: 3px; margin-bottom: 8px;"></div>
            <div style="height: 14px; width: 85%; background: #27272a; border-radius: 3px;"></div>
          </div>
        </div>`
      )
      .join("");
  }

  try {
    const rawScripts = await fetchRealScripts();
    allFetchedScripts = rawScripts.map((s, idx) => normalizeScript(s, idx));
  } catch (err) {
    console.error("[Script Hub] Load error:", err);
  } finally {
    isLoading = false;
    renderScriptHub();
  }
}

export function focusLibrarySearch() {
  const s = $("#sh-search-input");
  if (s) {
    s.focus();
    s.select();
  }
}

export function initLibrary() {
  const sourceButtons = $$("#sh-sources-list .sh-nav-btn");
  const searchInput = $("#sh-search-input");

  sourceButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      sourceButtons.forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      activeSource = btn.dataset.source || "rscripts";
      const srcName = btn.querySelector("span")?.textContent || "scripts";
      if (searchInput) searchInput.placeholder = `Search ${srcName}...`;
      loadScripts();
    });
  });

  $("#sh-filter-verified")?.addEventListener("change", (e) => {
    filterVerified = e.target.checked;
    loadScripts();
  });
  $("#sh-filter-nokey")?.addEventListener("change", (e) => {
    filterNoKey = e.target.checked;
    loadScripts();
  });
  $("#sh-filter-notpatched")?.addEventListener("change", (e) => {
    filterNotPatched = e.target.checked;
    loadScripts();
  });

  $$('input[name="sh-sort"]').forEach((radio) => {
    radio.addEventListener("change", (e) => {
      sortBy = e.target.value;
      renderScriptHub();
    });
  });

  if (searchInput) {
    const runSearch = debounce(() => {
      query = searchInput.value.trim();
      loadScripts();
    }, 350);

    searchInput.addEventListener("input", runSearch);
    searchInput.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        e.stopPropagation();
        if (searchInput.value) {
          searchInput.value = "";
          query = "";
          loadScripts();
        } else {
          searchInput.blur();
        }
      }
      if (e.key === "Enter") {
        query = searchInput.value.trim();
        loadScripts();
      }
    });
  }

  $("#sh-featured-toggle")?.addEventListener("click", () => {
    $("#sh-featured-section")?.classList.toggle("collapsed");
  });

  loadScripts();
}

export function libraryRows() {
  return $$(".sh-card");
}
