/* Script library: a dense table (favourite, name + description, category,
   actions) with category filter, favourites and search highlighting. */

import { $, $$, icon, highlight, debounce } from "./dom.js";
import { store } from "./store.js";
import { runScript } from "./actions.js";
import { openInNewTab } from "./editor.js";
import { goToPage } from "./nav.js";
import { toast } from "./toast.js";
import { initSeg, setSeg } from "./seg.js";
import { on } from "./bus.js";

export const LIBRARY = [
  { name: "Infinite Yield", icon: "IY", category: "utility", desc: "Admin command suite. Prefix commands with ;",
    code: `loadstring(game:HttpGet("https://raw.githubusercontent.com/edgeiy/infiniteyield/master/source", true))()` },
  { name: "Byte Universal", icon: "BU", category: "byte", desc: "Universal script for most games",
    code: `loadstring(game:HttpGet("https://raw.githubusercontent.com/user9127/byte-public/refs/heads/main/Byte-universal.lua", true))()` },
  { name: "Byte Da Hood", icon: "DH", category: "byte", desc: "Da Hood loader",
    code: `loadstring(game:HttpGet("https://raw.githubusercontent.com/user9127/byte-public/refs/heads/main/Byte-dahood.lua", true))()` },
  { name: "Byte Hypershot", icon: "HS", category: "byte", desc: "Hypershot loader",
    code: `loadstring(game:HttpGet("https://raw.githubusercontent.com/user9127/byte-public/refs/heads/main/Byte-hypershot.lua", true))()` },
  { name: "Byte Rivals", icon: "RV", category: "byte", desc: "Rivals loader",
    code: `loadstring(game:HttpGet("https://raw.githubusercontent.com/user9127/byte-public/refs/heads/main/Byte-rivals.lua", true))()` },
  { name: "Dex Explorer", icon: "DX", category: "utility", desc: "Live game explorer and property editor",
    code: `loadstring(game:HttpGet("https://raw.githubusercontent.com/peyton2465/Dex/master/out.lua"))()` },
  { name: "UNC Test", icon: "UT", category: "utility", desc: "Report which executor APIs are supported",
    code: `loadstring(game:HttpGet("https://raw.githubusercontent.com/unified-naming-convention/NamingStandard/refs/heads/main/UNCCheckEnv.lua", true))()` },
  { name: "Print Env", icon: "PE", category: "utility", desc: "Dump the contents of getgenv()",
    code: `for k,v in pairs(getgenv()) do print(k, "=", tostring(v)) end` }
];

const CATEGORY_LABEL = { byte: "Byte", utility: "Utility" };
const rows = new Map(); // name -> element
let filter = "all";
let query = "";
let favorites = new Set();

function slug(name) {
  return name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") + ".lua";
}

export async function runLibraryScript(s, button = null) {
  return runScript(s.code, { label: s.name, button });
}

export function openLibraryScript(s) {
  openInNewTab(slug(s.name), s.code);
  goToPage("execution");
  toast(`${s.name} opened in a new tab.`, "ok", 2000);
}

function favLabel(s, on) {
  return `${on ? "Remove" : "Add"} ${s.name} ${on ? "from" : "to"} favorites`;
}

function toggleFavorite(s, btn) {
  const on = !favorites.has(s.name);
  if (on) favorites.add(s.name); else favorites.delete(s.name);
  store.set("library.favs", Array.from(favorites));
  btn.setAttribute("aria-pressed", String(on));
  btn.setAttribute("aria-label", favLabel(s, on));
  if (filter === "favorites") apply();
}

function buildRow(s) {
  const r = document.createElement("div");
  r.className = `lib-row ${s.category}`;
  r.setAttribute("role", "row");
  const fav = favorites.has(s.name);
  r.innerHTML = `
    <span role="cell"><button class="lib-fav" aria-pressed="${fav}" aria-label="${favLabel(s, fav)}">${icon("star")}</button></span>
    <span role="cell" class="lib-name">
      <span class="lib-ic" aria-hidden="true">${s.icon}</span>
      <span class="lib-text"><h3></h3><p></p></span>
    </span>
    <span role="cell" class="lib-cat"><span class="tag${s.category === "byte" ? " ac" : ""}">${CATEGORY_LABEL[s.category]}</span></span>
    <span role="cell" class="lib-actions">
      <button class="btn ghost sm" aria-label="Open ${s.name} in a new tab">${icon("edit")}<span class="btn-label">Open</span></button>
      <button class="btn sm lib-run" aria-label="Run ${s.name}">${icon("play")}<span class="btn-label">Run</span></button>
    </span>`;
  r.querySelector(".lib-fav").addEventListener("click", (e) => toggleFavorite(s, e.currentTarget));
  const [openBtn, runBtn] = r.querySelectorAll(".lib-actions .btn");
  openBtn.addEventListener("click", () => openLibraryScript(s));
  runBtn.addEventListener("click", (e) => runLibraryScript(s, e.currentTarget));
  return r;
}

function matches(s) {
  if (filter === "favorites" && !favorites.has(s.name)) return false;
  if ((filter === "byte" || filter === "utility") && s.category !== filter) return false;
  if (!query) return true;
  return `${s.name} ${s.desc} ${CATEGORY_LABEL[s.category]}`.toLowerCase().includes(query);
}

function emptyState() {
  const fav = filter === "favorites" && !query;
  return `<div class="empty">
    <div class="glyph">${icon(fav ? "star" : "search")}</div>
    <h3>${fav ? "No favorites yet" : "No matching scripts"}</h3>
    <p>${fav ? "Star a script to pin it here." : "Nothing matches that search. Try another word or clear the filter."}</p>
  </div>`;
}

function apply() {
  const body = $("#library-grid");
  const visible = LIBRARY.filter(matches);
  body.querySelector(".empty")?.remove();
  for (const [name, el] of rows) {
    if (!visible.some((s) => s.name === name)) el.remove();
  }
  for (const s of visible) {
    const el = rows.get(s.name);
    el.querySelector("h3").innerHTML = highlight(s.name, query);
    el.querySelector("p").innerHTML = highlight(s.desc, query);
    body.appendChild(el);
  }
  if (!visible.length) body.insertAdjacentHTML("beforeend", emptyState());
  const n = visible.length;
  $("#library-count").textContent = n === LIBRARY.length ? `${n} scripts` : `${n} of ${LIBRARY.length} scripts`;
}

export function focusLibrarySearch() {
  const s = $("#library-search");
  s.focus();
  s.select();
}

export function initLibrary() {
  favorites = new Set((store.get("library.favs", []) || []).filter((x) => typeof x === "string"));
  const saved = store.get("library.filter", "all");
  filter = ["all", "favorites", "byte", "utility"].includes(saved) ? saved : "all";

  for (const s of LIBRARY) rows.set(s.name, buildRow(s));
  apply();

  const search = $("#library-search");
  const wrap = $("#library-search-wrap");
  const run = debounce(() => {
    query = search.value.trim().toLowerCase();
    wrap.classList.toggle("has-value", !!search.value);
    apply();
  }, 60);
  search.addEventListener("input", run);
  search.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      e.stopPropagation();
      if (search.value) { search.value = ""; run.flush(); }
      else search.blur();
    }
  });

  const seg = $("#library-filter");
  initSeg(seg, filter, (v) => { filter = v; store.set("library.filter", v); apply(); });
  on("prefs-reset", () => { filter = "all"; setSeg(seg, "all"); apply(); });
}

export function libraryRows() { return $$(".lib-row"); }
