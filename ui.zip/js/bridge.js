import { state } from "./state.js";
import { emit } from "./bus.js";

export const BRIDGE = location.protocol.startsWith("http") ? location.origin : "http://127.0.0.1:8734";
export const isStandalone = location.protocol.startsWith("http") && Boolean(location.port) && location.port !== "8734";

function mockResponse(path) {
  if (path.startsWith("/status")) {
    return {
      ok: true,
      version: "1.0.14",
      supportedHash: "version-11f155f3450f4c8e",
      robloxPids: [1337],
      pids: [1337],
      activePid: 1337,
      robloxHashes: ["version-11f155f3450f4c8e"],
      injectorAvailable: true,
      injected: true
    };
  }
  if (path.startsWith("/output")) {
    return { ok: true, logs: [] };
  }
  if (path.startsWith("/accounts")) {
    return {
      ok: true,
      multiInstance: true,
      accounts: [
        {
          id: "acc-1",
          userId: 12345678,
          username: "ByteVIP_Player",
          displayName: "Byte VIP",
          avatarUrl: "",
          note: "Main Account",
          running: true,
          pid: 1337
        }
      ]
    };
  }
  if (path.startsWith("/auth/state")) {
    return { ok: true, authed: true, licenseKey: "BYTE-VIP-PREVIEW", tier: "VIP" };
  }
  if (path.startsWith("/versions")) {
    return {
      ok: true,
      supportedHash: "version-11f155f3450f4c8e",
      versions: [
        {
          hash: "version-11f155f3450f4c8e",
          version: "version-11f155f3450f4c8e",
          installed: true,
          isSupported: true,
          status: "supported",
          launcher: "roblox",
          launcherName: "Roblox Official",
          channel: "LIVE",
          path: "C:\\Users\\User\\AppData\\Local\\Roblox\\Versions\\version-11f155f3450f4c8e",
          size: "158 MB",
          needsSetup: false
        }
      ]
    };
  }
  return { ok: true };
}

// The native host refuses Roblox/account routes without an active license.
async function licenseRefused(r) {
  let j = null;
  try { j = await r.json(); } catch { }
  if (j && j.error === "license_required") {
    emit("license-required");
    return { ok: false, error: "No active license. Sign in or enter a key.", licenseRequired: true };
  }
  return { ok: false, error: (j && j.error) || "unauthorized" };
}

function setOnline(v) {
  if (state.bridgeOnline === v) return;
  state.bridgeOnline = v;
  emit("bridge", v);
}

function signalFor(timeout) {
  if (!timeout) return undefined;
  try { return AbortSignal.timeout(timeout); } catch { return undefined; }
}

export async function bridgeGet(path, { timeout = 8000, measure = false } = {}) {
  if (isStandalone) {
    setOnline(true);
    return mockResponse(path);
  }
  const t0 = performance.now();
  try {
    const r = await fetch(BRIDGE + path, { cache: "no-store", signal: signalFor(timeout) });
    if (measure) state.latency = performance.now() - t0;
    setOnline(r.ok || r.status === 401);
    if (r.status === 401) await licenseRefused(r);
    return r.ok ? await r.json() : null;
  } catch {
    if (measure) state.latency = null;
    setOnline(false);
    return null;
  }
}

export async function bridgeProbe(path) {
  try {
    const r = await fetch(BRIDGE + path, { cache: "no-store", signal: signalFor(4000) });
    if (!r.ok) return null;
    return await r.json();
  } catch {
    return null;
  }
}

async function send(method, path, body, contentType, timeout, signal) {
  if (isStandalone) {
    setOnline(true);
    return { ok: true };
  }
  try {
    const r = await fetch(BRIDGE + path, {
      method,
      headers: body !== undefined ? { "content-type": contentType } : undefined,
      body,
      // Caller-supplied signal (e.g. a Cancel button) wins over the timeout
      // signal; without a caller signal we fall back to the per-call timeout.
      signal: signal || signalFor(timeout)
    });
    setOnline(true);

    if (r.status === 401) return await licenseRefused(r);
    try { return await r.json(); } catch { return { ok: r.ok }; }
  } catch (e) {
    if (e && e.name === "AbortError") {
      // Distinguish user-cancel from a plain timeout so callers can respond
      // to each (the updater uses this to keep the banner out of a stale state).
      return { ok: false, error: signal?.aborted ? "aborted" : "timed out", aborted: !!signal?.aborted };
    }
    if (e && e.name === "TimeoutError") return { ok: false, error: "timed out" };
    setOnline(false);
    return { ok: false, error: "bridge offline" };
  }
}

export function bridgePost(path, body, { timeout = 0, signal } = {}) {
  return send("POST", path, body !== undefined ? JSON.stringify(body) : undefined, "application/json", timeout, signal);
}

export function bridgePostRaw(path, text, { timeout = 0, signal } = {}) {
  return send("POST", path, text, "text/plain; charset=utf-8", timeout, signal);
}

export function bridgePut(path, body, { timeout = 8000, signal } = {}) {
  return send("PUT", path, JSON.stringify(body), "application/json", timeout, signal);
}

export async function bridgeWindow(action) {
  try { await fetch(BRIDGE + "/window/" + action, { method: "POST" }); } catch {  }
}
