/* Loopback HTTP bridge to Byte.exe (127.0.0.1:8734). Endpoint contract and
   payloads match ByteUI.cpp exactly; this layer only adds timeouts, latency
   measurement and an online/offline signal. */

import { state } from "./state.js";
import { emit } from "./bus.js";

// The host serves this UI from the bridge itself, so the page origin is the bridge.
// file:// (opening index.html directly) falls back to the default port.
export const BRIDGE = location.protocol.startsWith("http") ? location.origin : "http://127.0.0.1:8734";

function setOnline(v) {
  if (state.bridgeOnline === v) return;
  state.bridgeOnline = v;
  emit("bridge", v);
}

function signalFor(timeout) {
  if (!timeout) return undefined;
  try { return AbortSignal.timeout(timeout); } catch { return undefined; }
}

/* GET returning parsed JSON, or null on any failure (network, non-2xx, bad JSON). */
export async function bridgeGet(path, { timeout = 8000, measure = false } = {}) {
  const t0 = performance.now();
  try {
    const r = await fetch(BRIDGE + path, { cache: "no-store", signal: signalFor(timeout) });
    if (measure) state.latency = performance.now() - t0;
    setOnline(r.ok);
    return r.ok ? await r.json() : null;
  } catch {
    if (measure) state.latency = null;
    setOnline(false);
    return null;
  }
}

/* GET that distinguishes "endpoint missing" (older host) from offline. */
export async function bridgeProbe(path) {
  try {
    const r = await fetch(BRIDGE + path, { cache: "no-store", signal: signalFor(4000) });
    if (!r.ok) return null;
    return await r.json();
  } catch {
    return null;
  }
}

async function send(method, path, body, contentType, timeout) {
  try {
    const r = await fetch(BRIDGE + path, {
      method,
      headers: body !== undefined ? { "content-type": contentType } : undefined,
      body,
      signal: signalFor(timeout)
    });
    setOnline(true);
    // the host replies JSON on error codes too (401 status, 425 tooEarly), so parse regardless
    try { return await r.json(); } catch { return { ok: r.ok }; }
  } catch (e) {
    if (e && (e.name === "TimeoutError" || e.name === "AbortError")) return { ok: false, error: "timed out" };
    setOnline(false);
    return { ok: false, error: "bridge offline" };
  }
}

export function bridgePost(path, body, { timeout = 0 } = {}) {
  return send("POST", path, body !== undefined ? JSON.stringify(body) : undefined, "application/json", timeout);
}

export function bridgePostRaw(path, text, { timeout = 0 } = {}) {
  return send("POST", path, text, "text/plain; charset=utf-8", timeout);
}

export function bridgePut(path, body, { timeout = 8000 } = {}) {
  return send("PUT", path, JSON.stringify(body), "application/json", timeout);
}

export async function bridgeWindow(action) {
  try { await fetch(BRIDGE + "/window/" + action, { method: "POST" }); } catch { /* host gone; nothing to do */ }
}
