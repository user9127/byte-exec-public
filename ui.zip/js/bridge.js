import { state } from "./state.js";
import { emit } from "./bus.js";

export const BRIDGE = location.protocol.startsWith("http") ? location.origin : "http://127.0.0.1:8734";

function setOnline(v) {
  if (state.bridgeOnline === v) return;
  state.bridgeOnline = v;
  emit("bridge", v);
}

function signalFor(timeout) {
  if (!timeout) return undefined;
  try { return AbortSignal.timeout(timeout); } catch { return undefined; }
}

export async function bridgeGet(path, { timeout = 8000, measure = false } = {}) {
  const t0 = performance.now();
  try {
    const r = await fetch(BRIDGE + path, { cache: "no-store", signal: signalFor(timeout) });
    if (measure) state.latency = performance.now() - t0;
    setOnline(r.ok);
    return r.ok ? await r.json() : null;
  } catch {
    if (measure) state.latency = null;
    setOnline(false);
    return null;
  }
}

export async function bridgeProbe(path) {
  try {
    const r = await fetch(BRIDGE + path, { cache: "no-store", signal: signalFor(4000) });
    if (!r.ok) return null;
    return await r.json();
  } catch {
    return null;
  }
}

async function send(method, path, body, contentType, timeout, signal) {
  try {
    const r = await fetch(BRIDGE + path, {
      method,
      headers: body !== undefined ? { "content-type": contentType } : undefined,
      body,
      // Caller-supplied signal (e.g. a Cancel button) wins over the timeout
      // signal; without a caller signal we fall back to the per-call timeout.
      signal: signal || signalFor(timeout)
    });
    setOnline(true);

    try { return await r.json(); } catch { return { ok: r.ok }; }
  } catch (e) {
    if (e && e.name === "AbortError") {
      // Distinguish user-cancel from a plain timeout so callers can respond
      // to each (the updater uses this to keep the banner out of a stale state).
      return { ok: false, error: signal?.aborted ? "aborted" : "timed out", aborted: !!signal?.aborted };
    }
    if (e && e.name === "TimeoutError") return { ok: false, error: "timed out" };
    setOnline(false);
    return { ok: false, error: "bridge offline" };
  }
}

export function bridgePost(path, body, { timeout = 0, signal } = {}) {
  return send("POST", path, body !== undefined ? JSON.stringify(body) : undefined, "application/json", timeout, signal);
}

export function bridgePostRaw(path, text, { timeout = 0, signal } = {}) {
  return send("POST", path, text, "text/plain; charset=utf-8", timeout, signal);
}

export function bridgePut(path, body, { timeout = 8000, signal } = {}) {
  return send("PUT", path, JSON.stringify(body), "application/json", timeout, signal);
}

export async function bridgeWindow(action) {
  try { await fetch(BRIDGE + "/window/" + action, { method: "POST" }); } catch {  }
}
