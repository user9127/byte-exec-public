export const DISCORD_INVITE = "https://discord.gg/test";

export const state = {

  pids: [],
  robloxPids: [],
  injectorAvailable: false,
  activePid: null,
  attachedAt: null,
  outputCursor: 0,

  authed: false,
  tier: null,
  hwid: null,
  discord: null,
  licenseKey: null,
  bridgeReachable: true,

  version: "0.0.0",
  latestVersion: null,

  bridgeOnline: false,
  latency: null,

  page: "execution",
  windowActive: true,
  gateOpen: false,

  settings: {
    autoInject: false,
    autoUpdate: true,
    tabSize: 4,
    wordWrap: false,
    minimap: false,
    fontSize: 13
  }
};

export function canInject() {
  return state.robloxPids.length > 0 && state.pids.length === 0 && state.injectorAvailable;
}
