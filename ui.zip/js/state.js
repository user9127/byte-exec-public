/* Shared runtime state. Field names that mirror the native bridge keep the
   same spelling as ByteUI.cpp / ByteUIExtras.cpp JSON. */

export const DISCORD_INVITE = "https://discord.gg/xbyte";
/* Byte accounts live on the website; the launcher signs in to the same account. */
export const ACCOUNT_URL = "https://projectbyte.cc/account";

export const state = {
  // process / session (from GET /status)
  pids: [],
  robloxPids: [],
  injectorAvailable: false,
  activePid: null,
  attachedAt: null,
  outputCursor: 0,

  // license (from GET /auth/state)
  authed: false,
  tier: null,
  hwid: null,
  discord: null,
  licenseKey: null,
  account: null,          // { username } when signed in with a Byte account
  licenseStatus: null,    // "active" | "expired" | "disabled" when the server said so
  expiresAt: null,
  // Server-computed subscription tier: "lifetime" | "monthly" | "weekly" | "free" | "none"
  subscription: null,
  subscriptionLabel: null,
  accountManager: false,  // Roblox Account Manager perk gate (monthly/lifetime)
  dailyGenLimit: 0,       // per-24h Roblox account generation count
  bridgeReachable: true,

  // build / update
  version: "0.0.0",
  latestVersion: null,

  // bridge health
  bridgeOnline: false,
  latency: null,

  // ui
  page: "execution",
  windowActive: true,
  gateOpen: false,

  // persisted through the bridge (tabSize, autoInject, autoUpdate) or locally (rest)
  settings: {
    autoInject: false,
    autoUpdate: true,
    tabSize: 4,
    wordWrap: false,
    minimap: false,
    fontSize: 13
  }
};

export function canInject() {
  return state.robloxPids.length > 0 && state.pids.length === 0 && state.injectorAvailable;
}
