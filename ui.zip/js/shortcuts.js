/* Keyboard shortcut reference (dialog). The bindings themselves live in
   app.js; keep this table in sync when adding one. */

import { $, escapeHtml } from "./dom.js";
import { openOverlay } from "./dialog.js";

export const SHORTCUT_GROUPS = [
  {
    group: "General",
    items: [
      ["Command palette", "Ctrl+K"],
      ["Command palette from the editor", "Ctrl+P"],
      ["Go to page", "Ctrl+1-5"],
      ["Toggle sidebar", "Ctrl+B"],
      ["Keyboard shortcuts", "?"],
      ["Close dialog or menu", "Esc"]
    ]
  },
  {
    group: "Executor",
    items: [
      ["Run script", "Ctrl+Enter"],
      ["Inject", "Ctrl+Shift+Enter"],
      ["New tab", "Ctrl+T"],
      ["Close tab", "Ctrl+W"],
      ["Next tab", "Ctrl+Tab"],
      ["Previous tab", "Ctrl+Shift+Tab"],
      ["Rename tab", "F2"],
      ["Open file", "Ctrl+O"],
      ["Save to file", "Ctrl+S"]
    ]
  },
  {
    group: "Console and library",
    items: [
      ["Clear console", "Ctrl+L"],
      ["Search library", "/"],
      ["Focus page search", "Ctrl+F"]
    ]
  }
];

function keys(combo) {
  const parts = combo === "Ctrl+1-5" ? ["Ctrl", "1-5"] : combo.split("+");
  return parts.map((k) => `<kbd class="kbd">${escapeHtml(k === "Enter" ? "↵" : k)}</kbd>`).join("");
}

let rendered = false;
function render() {
  if (rendered) return;
  rendered = true;
  $("#shortcut-grid").innerHTML = SHORTCUT_GROUPS.map((g) =>
    `<div class="sc-group">${escapeHtml(g.group)}</div>` +
    g.items.map(([label, combo]) => `<div class="sc-row"><span>${escapeHtml(label)}</span><span class="sc-keys">${keys(combo)}</span></div>`).join("")
  ).join("");
}

export function openShortcuts() {
  render();
  openOverlay($("#shortcuts"));
}
