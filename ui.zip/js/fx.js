/* Interaction feedback: button outcome states, invalid-input shake, copy
   confirmation, and window focus tracking (dims the titlebar like native
   Windows chrome when Byte is not the foreground window). */

import { icon, restartClass } from "./dom.js";
import { state } from "./state.js";

const timers = new WeakMap();

/* Swap the button's content for "check + Done" briefly; failures shake. */
export function buttonFeedback(btn, kind = "success", ms = 900) {
  if (!btn) return;
  clearTimeout(timers.get(btn));
  btn.querySelector(":scope > .btn-feedback")?.remove();
  btn.classList.remove("is-success", "is-fail");
  if (kind === "fail") {
    restartClass(btn, "is-shake");
    return;
  }
  const fb = document.createElement("span");
  fb.className = "btn-feedback";
  fb.setAttribute("aria-hidden", "true");
  fb.innerHTML = `${icon("check")}<span>Done</span>`;
  btn.appendChild(fb);
  btn.classList.add("is-success");
  timers.set(btn, setTimeout(() => {
    btn.classList.remove("is-success");
    btn.querySelector(":scope > .btn-feedback")?.remove();
  }, ms));
}

export function shake(el) {
  if (el) restartClass(el, "is-shake");
}

export function flashCopied(btn, ms = 1200) {
  if (!btn) return;
  btn.classList.add("copied");
  clearTimeout(timers.get(btn));
  timers.set(btn, setTimeout(() => btn.classList.remove("copied"), ms));
}

export function setWindowActive(active) {
  if (state.windowActive === active) return;
  state.windowActive = active;
  document.documentElement.classList.toggle("win-inactive", !active);
}

export function initFx() {
  // fallbacks for hosts that do not push WM_ACTIVATE state
  window.addEventListener("blur", () => setWindowActive(false));
  window.addEventListener("focus", () => setWindowActive(true));
}
