/* Segmented control (role=radiogroup) with a gliding thumb. Arrow keys move
   the selection, roving tabindex keeps one stop in the tab order. A
   ResizeObserver re-seats the thumb when the control first becomes visible
   (pages start display:none, where offsets read as zero). */

import { $$ } from "./dom.js";
import { glide } from "./motion.js";

const controls = new WeakMap();

function seat(el, instant) {
  const thumb = el.querySelector(".seg-thumb");
  const on = el.querySelector('[role=radio][aria-checked="true"]');
  if (thumb && on) glide(thumb, on, { axis: "x", instant });
}

export function setSeg(el, value, { instant = false } = {}) {
  if (!el) return;
  for (const b of $$("[role=radio]", el)) {
    const on = b.dataset.value === String(value);
    b.setAttribute("aria-checked", String(on));
    b.tabIndex = on ? 0 : -1;
  }
  seat(el, instant);
}

export function getSeg(el) {
  return el?.querySelector('[role=radio][aria-checked="true"]')?.dataset.value ?? null;
}

export function initSeg(el, value, onChange) {
  if (!el || controls.has(el)) return;
  controls.set(el, onChange);
  setSeg(el, value, { instant: true });

  el.addEventListener("click", (e) => {
    const b = e.target.closest("[role=radio]");
    if (!b || b.getAttribute("aria-checked") === "true") return;
    setSeg(el, b.dataset.value);
    controls.get(el)?.(b.dataset.value);
  });
  el.addEventListener("keydown", (e) => {
    const buttons = $$("[role=radio]", el);
    const i = buttons.findIndex((b) => b.getAttribute("aria-checked") === "true");
    let n = -1;
    if (e.key === "ArrowRight" || e.key === "ArrowDown") n = (i + 1) % buttons.length;
    else if (e.key === "ArrowLeft" || e.key === "ArrowUp") n = (i - 1 + buttons.length) % buttons.length;
    else if (e.key === "Home") n = 0;
    else if (e.key === "End") n = buttons.length - 1;
    if (n < 0) return;
    e.preventDefault();
    setSeg(el, buttons[n].dataset.value);
    buttons[n].focus();
    controls.get(el)?.(buttons[n].dataset.value);
  });

  let lastW = 0;
  new ResizeObserver(() => {
    const w = el.offsetWidth;
    if (w && w !== lastW) seat(el, true);
    lastW = w;
  }).observe(el);
}
