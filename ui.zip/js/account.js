/* Account page + sidebar identity: Byte account, license key reveal, copy
   actions, Discord linking with live pickup, sign out. */

import { $, copyText } from "./dom.js";
import { state, ACCOUNT_URL } from "./state.js";
import { bridgeGet, bridgePost } from "./bridge.js";
import { toast } from "./toast.js";
import { flashCopied, buttonFeedback } from "./fx.js";
import { confirmDialog } from "./dialog.js";
import { emit, on } from "./bus.js";

let revealed = false;
let discordPoll = 0;

function maskKey(k) {
  if (!k) return "not activated";
  if (k.length <= 8) return "•".repeat(k.length);
  return k.slice(0, 5) + "•".repeat(Math.max(4, k.length - 9)) + k.slice(-4);
}

function initial() {
  if (state.account?.username) return state.account.username[0].toUpperCase();
  if (state.discord?.username) return state.discord.username[0].toUpperCase();
  if (state.tier) return state.tier[0].toUpperCase();
  return "B";
}

export function renderAccount() {
  const keyEl = $("#account-key");
  const keyText = revealed ? (state.licenseKey || "not activated") : maskKey(state.licenseKey);
  keyEl.textContent = keyText;
  keyEl.classList.toggle("masked", !revealed);
  $("#btn-key-reveal").setAttribute("aria-pressed", String(revealed));
  $("#btn-key-reveal").setAttribute("aria-label", revealed ? "Hide key" : "Show key");

  // Prefer the server-computed subscription label (Lifetime / Monthly /
  // Weekly / Free) over the raw licenses.tier string. Keep the raw tier as a
  // fallback so pre-sync frames still show something sensible.
  const tier = state.subscriptionLabel || prettyTier(state.tier);
  $("#account-tier").textContent = tier;
  $("#account-tier-desc").textContent = state.authed ? subscriptionDescription() : "No active license";
  $("#account-hwid").textContent = state.hwid || "unbound";
  $("#account-expires").textContent = expiryText();

  const account = state.account?.username || null;
  const dName = state.discord?.username || null;
  const dState = $("#account-discord");
  dState.classList.toggle("linked", !!dName);
  dState.querySelector("span").textContent = dName ? `Linked as ${dName}` : "Discord not linked";
  $("#account-name").textContent = account || dName || (state.authed ? "Byte Member" : "Not signed in");
  $("#account-avatar").textContent = initial();
  // An account's Discord is the one it signed up with; it isn't relinked from here.
  $("#btn-discord-link").hidden = !!account;
  $("#btn-discord-label").textContent = dName ? "Reconnect Discord" : "Connect Discord";
  $("#account-login").textContent = account ? `Signed in as ${account}` : "Not signed in (license key only)";
  $("#signout-desc").textContent = account
    ? "Sign this PC out of your Byte account. It also drops off the device list on projectbyte.cc."
    : "Remove the local license file from this machine. You will need your key to sign back in.";

  $("#sidebar-avatar").textContent = initial();
  $("#sidebar-name").textContent = account || dName || (state.authed ? "Licensed" : "Not signed in");
  $("#sidebar-tier").textContent = tier;
  $("#sb-tier").textContent = tier;
}

function prettyTier(raw) {
  if (!raw) return "Free";
  // Capitalise 'user'/'beta'/'vip' etc so the pre-sync frame doesn't look lowercase.
  return raw.charAt(0).toUpperCase() + raw.slice(1);
}

function subscriptionDescription() {
  const parts = [];
  if (state.subscription && state.subscription !== "none") {
    parts.push(`${state.subscriptionLabel || prettyTier(state.subscription)} plan`);
  } else {
    parts.push("Active license");
  }
  if (state.dailyGenLimit > 0) parts.push(`${state.dailyGenLimit}/day account gens`);
  if (state.accountManager) parts.push("Roblox Account Manager");
  return parts.join(" · ");
}

function expiryText() {
  if (!state.licenseKey) return "No key";
  if (state.licenseStatus === "expired") return "Expired";
  if (!state.expiresAt) return state.account ? "Never (lifetime)" : "Unknown";
  const d = new Date(state.expiresAt);
  return Number.isNaN(d.getTime()) ? "Unknown" : d.toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" });
}

function applyAuthState(s) {
  state.authed = !!s.authed;
  state.tier = s.tier || null;
  state.hwid = s.hwid || null;
  state.discord = s.discord || null;
  state.licenseKey = s.license_key || null;
  state.account = s.account || null;
  state.licenseStatus = s.license_status || null;
  state.expiresAt = s.expires_at || null;
  state.subscription = s.subscription || null;
  state.subscriptionLabel = s.subscription_label || null;
  state.accountManager = !!s.account_manager;
  state.dailyGenLimit = Number.isFinite(s.daily_gen_limit) ? s.daily_gen_limit : 0;
}

/* after "Connect Discord", watch /auth/state so the link shows up without a restart */
function watchDiscordLink() {
  clearInterval(discordPoll);
  const before = state.discord?.id || null;
  const deadline = Date.now() + 3 * 60 * 1000;
  discordPoll = setInterval(async () => {
    if (Date.now() > deadline) { clearInterval(discordPoll); return; }
    const s = await bridgeGet("/auth/state");
    if (!s || !s.discord?.id || s.discord.id === before) return;
    clearInterval(discordPoll);
    applyAuthState(s);
    renderAccount();
    toast(`Discord linked as ${s.discord.username}.`, "ok", 4000);
  }, 3000);
}

export function initAccount() {
  $("#btn-key-reveal").addEventListener("click", () => {
    revealed = !revealed;
    renderAccount();
  });

  $("#btn-copy-key").addEventListener("click", async (e) => {
    const btn = e.currentTarget;
    if (!state.licenseKey) { toast("No key to copy.", "warn"); return; }
    if (await copyText(state.licenseKey)) { flashCopied(btn); toast("License key copied.", "ok", 1800); }
    else toast("Clipboard access denied.", "err");
  });

  $("#btn-copy-hwid").addEventListener("click", async (e) => {
    const btn = e.currentTarget;
    if (!state.hwid) { toast("No hardware ID bound yet.", "warn"); return; }
    if (await copyText(state.hwid)) { flashCopied(btn); toast("Hardware ID copied.", "ok", 1800); }
    else toast("Clipboard access denied.", "err");
  });

  $("#btn-discord-link").addEventListener("click", async (e) => {
    const btn = e.currentTarget;
    btn.classList.add("loading");
    const r = await bridgePost("/discord/link");
    btn.classList.remove("loading");
    if (r?.ok) {
      toast("Opened Discord in your browser. Authorize, then come back.", "ok", 4200);
      watchDiscordLink();
    } else {
      buttonFeedback(btn, "fail");
      toast(`Could not open browser: ${r?.error || "unknown"}`, "err");
    }
  });

  $("#btn-manage-account").addEventListener("click", async () => {
    const r = await bridgePost("/open-url", { url: ACCOUNT_URL });
    if (!r?.ok) toast("Could not open the browser.", "err");
  });

  $("#btn-signout").addEventListener("click", async () => {
    const ok = await confirmDialog({
      title: "Sign out of Byte?",
      message: state.account
        ? "This PC is signed out of your Byte account. Sign back in with your username and password."
        : "The local license file is removed from this machine. You will need your key to sign back in.",
      confirmLabel: "Sign out",
      danger: true,
      iconName: "logout"
    });
    if (!ok) return;
    await bridgePost("/auth/signout");
    state.authed = false;
    state.licenseKey = null;
    state.tier = null;
    state.discord = null;
    state.account = null;
    state.licenseStatus = null;
    state.subscription = null;
    state.subscriptionLabel = null;
    state.accountManager = false;
    state.dailyGenLimit = 0;
    state.expiresAt = null;
    revealed = false;
    clearInterval(discordPoll);
    renderAccount();
    emit("signed-out");
  });

  on("auth", renderAccount);
  renderAccount();
}

export { applyAuthState };
