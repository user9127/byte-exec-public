import { $, copyText } from "./dom.js";
import { state } from "./state.js";
import { bridgeGet, bridgePost } from "./bridge.js";
import { toast } from "./toast.js";
import { flashCopied, buttonFeedback } from "./fx.js";
import { confirmDialog } from "./dialog.js";
import { emit, on } from "./bus.js";

let revealed = false;
let discordPoll = 0;

function maskKey(k) {
  if (!k) return "not activated";
  if (k.length <= 8) return "•".repeat(k.length);
  return k.slice(0, 5) + "•".repeat(Math.max(4, k.length - 9)) + k.slice(-4);
}

function initial() {
  if (state.discord?.username) return state.discord.username[0].toUpperCase();
  if (state.tier) return state.tier[0].toUpperCase();
  return "B";
}

export function renderAccount() {
  const keyEl = $("#account-key");
  if (keyEl) {
    const keyText = revealed ? (state.licenseKey || "not activated") : maskKey(state.licenseKey);
    keyEl.textContent = keyText;
    keyEl.classList.toggle("masked", !revealed);
  }
  const btnKey = $("#btn-key-reveal");
  if (btnKey) {
    btnKey.setAttribute("aria-pressed", String(revealed));
    btnKey.setAttribute("aria-label", revealed ? "Hide key" : "Show key");
  }

  const tier = state.tier || "Free";
  const acTier = $("#account-tier");
  if (acTier) acTier.textContent = tier;
  const acTierDesc = $("#account-tier-desc");
  if (acTierDesc) acTierDesc.textContent = state.authed ? `${tier} license` : "No active license";
  const acHwid = $("#account-hwid");
  if (acHwid) acHwid.textContent = state.hwid || "unbound";

  const dName = state.discord?.username || null;
  const dState = $("#account-discord");
  if (dState) {
    dState.classList.toggle("linked", !!dName);
    const span = dState.querySelector("span");
    if (span) span.textContent = dName ? `Linked as ${dName}` : "Discord not linked";
  }
  const acName = $("#account-name");
  if (acName) acName.textContent = dName || (state.authed ? "Byte Member" : "Not signed in");
  const acAv = $("#account-avatar");
  if (acAv) acAv.textContent = initial();
  const dLabel = $("#btn-discord-label");
  if (dLabel) dLabel.textContent = dName ? "Reconnect Discord" : "Connect Discord";

  const sbAv = $("#sidebar-avatar");
  if (sbAv) sbAv.textContent = initial();
  const sbName = $("#sidebar-name");
  if (sbName) sbName.textContent = dName || (state.authed ? "Licensed" : "Not signed in");
  const sTier = $("#sidebar-tier");
  if (sTier) sTier.textContent = tier;
  const sbTier = $("#sb-tier");
  if (sbTier) sbTier.textContent = state.tier || "Free";
}

function applyAuthState(s) {
  state.authed = !!s.authed;
  state.tier = s.tier || null;
  state.hwid = s.hwid || null;
  state.discord = s.discord || null;
  state.licenseKey = s.license_key || null;
}

function watchDiscordLink() {
  clearInterval(discordPoll);
  const before = state.discord?.id || null;
  const deadline = Date.now() + 3 * 60 * 1000;
  discordPoll = setInterval(async () => {
    if (Date.now() > deadline) { clearInterval(discordPoll); return; }
    const s = await bridgeGet("/auth/state");
    if (!s || !s.discord?.id || s.discord.id === before) return;
    clearInterval(discordPoll);
    applyAuthState(s);
    renderAccount();
    toast(`Discord linked as ${s.discord.username}.`, "ok", 4000);
  }, 3000);
}

export function initAccount() {
  $("#btn-key-reveal")?.addEventListener("click", () => {
    revealed = !revealed;
    renderAccount();
  });

  $("#btn-copy-key")?.addEventListener("click", async (e) => {
    const btn = e.currentTarget;
    if (!state.licenseKey) { toast("No key to copy.", "warn"); return; }
    if (await copyText(state.licenseKey)) { flashCopied(btn); toast("License key copied.", "ok", 1800); }
    else toast("Clipboard access denied.", "err");
  });

  $("#btn-copy-hwid")?.addEventListener("click", async (e) => {
    const btn = e.currentTarget;
    if (!state.hwid) { toast("No hardware ID bound yet.", "warn"); return; }
    if (await copyText(state.hwid)) { flashCopied(btn); toast("Hardware ID copied.", "ok", 1800); }
    else toast("Clipboard access denied.", "err");
  });

  $("#btn-discord-link")?.addEventListener("click", async (e) => {
    const btn = e.currentTarget;
    btn.classList.add("loading");
    const r = await bridgePost("/discord/link");
    btn.classList.remove("loading");
    if (r?.ok) {
      toast("Opened Discord in your browser. Authorize, then come back.", "ok", 4200);
      watchDiscordLink();
    } else {
      buttonFeedback(btn, "fail");
      toast(`Could not open browser: ${r?.error || "unknown"}`, "err");
    }
  });

  $("#btn-signout")?.addEventListener("click", async () => {
    const ok = await confirmDialog({
      title: "Sign out of Byte?",
      message: "The local license file is removed from this machine. You will need your key to sign back in.",
      confirmLabel: "Sign out",
      danger: true,
      iconName: "logout"
    });
    if (!ok) return;
    await bridgePost("/auth/signout");
    state.authed = false;
    state.licenseKey = null;
    state.tier = null;
    state.discord = null;
    revealed = false;
    clearInterval(discordPoll);
    renderAccount();
    emit("signed-out");
  });

  on("auth", renderAccount);
  renderAccount();
}

export { applyAuthState };
