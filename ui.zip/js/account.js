import { $, copyText } from "./dom.js";
import { state } from "./state.js";
import { bridgeGet, bridgePost } from "./bridge.js";
import { toast } from "./toast.js";
import { flashCopied, buttonFeedback } from "./fx.js";
import { confirmDialog } from "./dialog.js";
import { emit, on } from "./bus.js";

const WORKINK_TIMEOUT_MS = 10 * 60 * 1000;

// Same host the launcher's native code activates keys against. Answers
// /v1/license/info only for this key on this HWID; text/plain keeps the call
// a CORS "simple request" (no preflight).
const LICENSE_API = "https://byte-license.bitofbyte.workers.dev";
const LICENSE_INFO_TTL_MS = 60 * 1000;
const EXPIRING_SOON_MS = 24 * 60 * 60 * 1000;

let licenseInfo = null; // { key, at, data } from /v1/license/info
let licenseInfoBusy = false;
let licenseTicker = 0;

let revealed = false;
let discordPoll = 0;
let settingsWorkinkPoll = 0;
let settingsWorkinkClock = 0;
let settingsWorkinkStart = 0;

function maskKey(k) {
  if (!k) return "not activated";
  if (k.length <= 8) return "•".repeat(k.length);
  return k.slice(0, 5) + "•".repeat(Math.max(4, k.length - 9)) + k.slice(-4);
}

function initial() {
  if (state.discord?.username) return state.discord.username[0].toUpperCase();
  if (state.tier) return state.tier[0].toUpperCase();
  return "B";
}

export function renderAccount() {
  const keyEl = $("#account-key");
  if (keyEl) {
    const keyText = revealed ? (state.licenseKey || "not activated") : maskKey(state.licenseKey);
    keyEl.textContent = keyText;
    keyEl.classList.toggle("masked", !revealed);
  }
  const btnKey = $("#btn-key-reveal");
  if (btnKey) {
    btnKey.setAttribute("aria-pressed", String(revealed));
    btnKey.setAttribute("aria-label", revealed ? "Hide key" : "Show key");
  }

  const tier = state.tier || "Free";
  const acTier = $("#account-tier");
  if (acTier) acTier.textContent = tier;
  const acTierDesc = $("#account-tier-desc");
  if (acTierDesc) acTierDesc.textContent = state.authed ? `${tier} license` : "No active license";
  const acHwid = $("#account-hwid");
  if (acHwid) acHwid.textContent = state.hwid || "unbound";

  const dName = state.discord?.username || null;
  const dState = $("#account-discord");
  if (dState) {
    dState.classList.toggle("linked", !!dName);
    const span = dState.querySelector("span");
    if (span) span.textContent = dName ? `Linked as ${dName}` : "Discord not linked";
  }
  const acName = $("#account-name");
  if (acName) acName.textContent = dName || (state.authed ? "Byte Member" : "Not signed in");
  const acAv = $("#account-avatar");
  if (acAv) acAv.textContent = initial();
  const dLabel = $("#btn-discord-label");
  if (dLabel) dLabel.textContent = dName ? "Reconnect Discord" : "Connect Discord";

  const sbAv = $("#sidebar-avatar");
  if (sbAv) sbAv.textContent = initial();
  const sbName = $("#sidebar-name");
  if (sbName) sbName.textContent = dName || (state.authed ? "Licensed" : "Not signed in");
  const sTier = $("#sidebar-tier");
  if (sTier) sTier.textContent = tier;
  const sbTier = $("#sb-tier");
  if (sbTier) sbTier.textContent = state.tier || "Free";

  renderLicenseTime();
}

// --- License time ("ACCOUNT TIME" on Home) -----------------------------------
// Mirrors projectbyte.cc's license card: "12d 4h left", "Lifetime", "Expired".
// The worker is the source of truth; the bridge's expires_at (filled by the
// account sync) covers the gap while offline.

function formatRemaining(ms) {
  const s = Math.floor(ms / 1000);
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  if (d > 0) return `${d}d ${h}h`;
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m ${s % 60}s`;
  return `${s}s`;
}

function durationText(days) {
  if (days % 365 === 0) return `${days / 365} year${days === 365 ? "" : "s"}`;
  if (days % 30 === 0) return `${days / 30} month${days === 30 ? "" : "s"}`;
  if (days % 7 === 0) return `${days / 7} week${days === 7 ? "" : "s"}`;
  return `${days} day${days === 1 ? "" : "s"}`;
}

function licenseTime() {
  if (!state.authed || !state.licenseKey) return { kind: "none" };
  const info = licenseInfo?.key === state.licenseKey ? licenseInfo.data : null;
  if (info?.lifetime) return { kind: "lifetime" };
  if (info?.starts_on_activation) return { kind: "pending", days: info.duration_days };
  const expires = info ? info.expires_at : state.licenseExpires;
  if (expires) {
    const at = Date.parse(expires);
    const ms = at - Date.now();
    return ms > 0 ? { kind: "left", ms, at } : { kind: "expired", at };
  }
  // No expiry anywhere: an account sync reports lifetime keys exactly like
  // this, while a bare key can't be told apart until the worker answers.
  if (info || state.hasAccount) return { kind: "lifetime" };
  return { kind: "unknown" };
}

function renderLicenseTime() {
  const el = $("#hab-time");
  if (!el) return;
  const t = licenseTime();
  let text = "Active";
  let title = "";
  if (t.kind === "none") text = "No active key";
  else if (t.kind === "lifetime") { text = "Lifetime"; title = "Lifetime key, never expires"; }
  else if (t.kind === "pending") { text = `${durationText(t.days)}, not started`; title = "The timer starts the first time this key is activated."; }
  else if (t.kind === "left") { text = `${formatRemaining(t.ms)} left`; title = `Expires ${new Date(t.at).toLocaleString()}`; }
  else if (t.kind === "expired") { text = "Expired"; title = `Ended ${new Date(t.at).toLocaleString()}`; }
  else if (t.kind === "unknown") text = "Checking…";
  if (el.textContent !== text) el.textContent = text;
  el.title = title;
  el.classList.toggle("soon", t.kind === "left" && t.ms < EXPIRING_SOON_MS);
  el.classList.toggle("ended", t.kind === "expired" || t.kind === "none");
}

async function refreshLicenseInfo(force = false) {
  const key = state.licenseKey;
  const hwid = state.hwid;
  if (!state.authed || !key || !hwid) { licenseInfo = null; renderLicenseTime(); return; }
  const fresh = licenseInfo?.key === key && Date.now() - licenseInfo.at < LICENSE_INFO_TTL_MS;
  if ((fresh && !force) || licenseInfoBusy) return;
  licenseInfoBusy = true;
  try {
    const r = await fetch(`${LICENSE_API}/v1/license/info`, {
      method: "POST",
      headers: { "content-type": "text/plain" },
      body: JSON.stringify({ key, hwid_hash: hwid }),
      cache: "no-store"
    });
    const d = await r.json();
    licenseInfo = { key, at: Date.now(), data: d?.status === "ok" ? d : null };
  } catch {
    // Offline or blocked: keep the previous answer and the bridge fallback.
  } finally {
    licenseInfoBusy = false;
  }
  renderLicenseTime();
}

function applyAuthState(s) {
  state.authed = !!s.authed;
  state.tier = s.tier || null;
  state.hwid = s.hwid || null;
  state.discord = s.discord || null;
  state.licenseKey = s.license_key || null;
  state.licenseExpires = s.expires_at || null;
  state.licenseStatus = s.license_status || null;
  state.hasAccount = !!s.account;
  // The kill-switch rides on every /auth/state response. Flip the overlay
  // based on whatever the server last reported; "up" (or missing) hides it,
  // anything else blocks the entire UI with the admin's message.
  applyServiceState(s.service);
}

/* Full-screen overlay that lands above the gate AND the app. Shown whenever
   the server says Byte is anything but 'up'. The launcher's native code polls
   /v1/service/status every 30s even without an account, and bundles the state
   into /auth/state, so a flip in the admin dashboard propagates automatically. */
function applyServiceState(svc) {
  const el = document.getElementById("service-overlay");
  if (!el) return;
  const status = svc?.status || "up";
  const message = svc?.message || "";
  state.serviceStatus = status;
  state.serviceMessage = message;
  const down = status !== "up";
  el.hidden = !down;
  if (down) {
    const sub = document.getElementById("service-overlay-message");
    if (sub) {
      sub.textContent = message && message.trim().length > 0
        ? message
        : "We're performing maintenance. Byte will come back automatically once it's back online.";
    }
    document.documentElement.classList.add("service-down");
  } else {
    document.documentElement.classList.remove("service-down");
  }
}

function watchDiscordLink() {
  clearInterval(discordPoll);
  const before = state.discord?.id || null;
  const deadline = Date.now() + 3 * 60 * 1000;
  discordPoll = setInterval(async () => {
    if (Date.now() > deadline) { clearInterval(discordPoll); return; }
    const s = await bridgeGet("/auth/state");
    if (!s || !s.discord?.id || s.discord.id === before) return;
    clearInterval(discordPoll);
    applyAuthState(s);
    renderAccount();
    toast(`Discord linked as ${s.discord.username}.`, "ok", 4000);
  }, 3000);
}

export function initAccount() {
  $("#btn-key-reveal")?.addEventListener("click", () => {
    revealed = !revealed;
    renderAccount();
  });

  $("#btn-copy-key")?.addEventListener("click", async (e) => {
    const btn = e.currentTarget;
    if (!state.licenseKey) { toast("No key to copy.", "warn"); return; }
    if (await copyText(state.licenseKey)) { flashCopied(btn); toast("License key copied.", "ok", 1800); }
    else toast("Clipboard access denied.", "err");
  });

  $("#btn-copy-hwid")?.addEventListener("click", async (e) => {
    const btn = e.currentTarget;
    if (!state.hwid) { toast("No hardware ID bound yet.", "warn"); return; }
    if (await copyText(state.hwid)) { flashCopied(btn); toast("Hardware ID copied.", "ok", 1800); }
    else toast("Clipboard access denied.", "err");
  });

  $("#btn-discord-link")?.addEventListener("click", async (e) => {
    const btn = e.currentTarget;
    btn.classList.add("loading");
    const r = await bridgePost("/discord/link");
    btn.classList.remove("loading");
    if (r?.ok) {
      toast("Opened Discord in your browser. Authorize, then come back.", "ok", 4200);
      watchDiscordLink();
    } else {
      buttonFeedback(btn, "fail");
      toast(`Could not open browser: ${r?.error || "unknown"}`, "err");
    }
  });

  $("#btn-signout")?.addEventListener("click", async () => {
    const ok = await confirmDialog({
      title: "Sign out of Byte?",
      message: "The local license file is removed from this machine. You will need your key to sign back in.",
      confirmLabel: "Sign out",
      danger: true,
      iconName: "logout"
    });
    if (!ok) return;
    await bridgePost("/auth/signout");
    state.authed = false;
    state.licenseKey = null;
    state.licenseExpires = null;
    state.tier = null;
    state.discord = null;
    licenseInfo = null;
    revealed = false;
    clearInterval(discordPoll);
    renderAccount();
    emit("signed-out");
  });

  wireSettingsWorkink();

  on("auth", () => { renderAccount(); refreshLicenseInfo(); });
  renderAccount();
  refreshLicenseInfo(true);

  // Countdown: re-render every second (cheap, text only changes when it
  // should) and re-ask the worker at most once a minute via the auth poll.
  clearInterval(licenseTicker);
  licenseTicker = setInterval(renderLicenseTime, 1000);
}

// --- Settings-page work.ink (mid-session key renewal) ---------------------
// A paid user never needs this; a free user whose key expired mid-session is
// the whole reason it lives in Settings. The flow mirrors the gate panel
// version: /workink/start opens the browser, /workink/state is polled.
function fmtDuration(ms) {
  const t = Math.max(0, Math.floor(ms / 1000));
  const m = Math.floor(t / 60);
  const s = t % 60;
  return `${m}:${s.toString().padStart(2, "0")}`;
}

function setSettingsWorkinkStatus(text, kind) {
  const el = $("#settings-workink-status");
  if (!el) return;
  if (!text) {
    el.hidden = true;
    const txt = el.querySelector(".sl-text");
    if (txt) txt.textContent = "";
    return;
  }
  el.hidden = false;
  el.className = `signin-status ${kind || ""}`;
  const txt = el.querySelector(".sl-text");
  if (txt) txt.textContent = text;
}

function stopSettingsWorkink() {
  clearInterval(settingsWorkinkPoll);
  clearInterval(settingsWorkinkClock);
  settingsWorkinkPoll = 0;
  settingsWorkinkClock = 0;
  const prog = $("#settings-workink-progress");
  if (prog) prog.hidden = true;
}

function resetSettingsWorkink(msg, kind) {
  stopSettingsWorkink();
  const btn = $("#btn-settings-getkey");
  if (btn) { btn.disabled = false; btn.classList.remove("loading"); }
  setSettingsWorkinkStatus(msg || "", kind || "");
}

async function startSettingsWorkink() {
  const btn = $("#btn-settings-getkey");
  if (!btn || btn.classList.contains("loading")) return;
  btn.classList.add("loading");
  btn.disabled = true;
  setSettingsWorkinkStatus("Opening work.ink in your browser…", "working");

  const r = await bridgePost("/workink/start");
  if (!r?.ok) {
    resetSettingsWorkink(`Could not open browser: ${r?.error || "unknown"}`, "err");
    return;
  }
  setSettingsWorkinkStatus("Complete one checkpoint in your browser. Your account picks up the new key automatically.", "working");
  const prog = $("#settings-workink-progress");
  if (prog) prog.hidden = false;
  settingsWorkinkStart = Date.now();
  const elapsed = $("#settings-workink-elapsed");
  if (elapsed) elapsed.textContent = "0:00";
  settingsWorkinkClock = setInterval(() => {
    if (elapsed) elapsed.textContent = fmtDuration(Date.now() - settingsWorkinkStart);
  }, 1000);
  settingsWorkinkPoll = setInterval(async () => {
    if (Date.now() - settingsWorkinkStart > WORKINK_TIMEOUT_MS) {
      resetSettingsWorkink("Timed out. Click again to retry.", "err");
      return;
    }
    const s = await bridgeGet("/workink/state");
    if (!s) return;
    if (s.phase === 2) setSettingsWorkinkStatus("Verifying your checkpoint…", "working");
    else if (s.phase === 3) {
      stopSettingsWorkink();
      setSettingsWorkinkStatus("New key received. Updating your account…", "ok");
      const fresh = await bridgeGet("/auth/state");
      if (fresh) {
        applyAuthState(fresh);
        emit("auth");
      }
      const btn2 = $("#btn-settings-getkey");
      if (btn2) { btn2.disabled = false; btn2.classList.remove("loading"); }
      toast("Your account picked up a new 24-hour key.", "ok", 3200);
    } else if (s.phase === 4) {
      resetSettingsWorkink(s.error || "Redemption failed. Click again to retry.", "err");
    }
  }, 1500);
}

function wireSettingsWorkink() {
  $("#btn-settings-getkey")?.addEventListener("click", startSettingsWorkink);
  $("#settings-workink-cancel")?.addEventListener("click", () =>
    resetSettingsWorkink("", ""));
}

export { applyAuthState };
