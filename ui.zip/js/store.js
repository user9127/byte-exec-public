const NS = "byte.";

export const store = {
  get(key, fallback = null) {
    try {
      const raw = localStorage.getItem(NS + key);
      if (raw === null) return fallback;
      return JSON.parse(raw);
    } catch {
      return fallback;
    }
  },
  set(key, value) {
    try {
      localStorage.setItem(NS + key, JSON.stringify(value));
      return true;
    } catch {
      return false; 
    }
  },
  remove(key) {
    try { localStorage.removeItem(NS + key); } catch {  }
  }
};

export const PREF_KEYS = [
  "wordWrap", "minimap", "fontSize", "motion", "sidebar",
  "layout.outH", "console.ts", "console.wrap", "library.filter", "console.filter"
];
