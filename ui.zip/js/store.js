/* Namespaced localStorage. Every access is guarded: WebView2 profiles can be
   read-only or wiped, and the UI must render correctly without persistence. */

const NS = "byte.";

export const store = {
  get(key, fallback = null) {
    try {
      const raw = localStorage.getItem(NS + key);
      if (raw === null) return fallback;
      return JSON.parse(raw);
    } catch {
      return fallback;
    }
  },
  set(key, value) {
    try {
      localStorage.setItem(NS + key, JSON.stringify(value));
      return true;
    } catch {
      return false; // quota exceeded or storage disabled
    }
  },
  remove(key) {
    try { localStorage.removeItem(NS + key); } catch { /* storage unavailable */ }
  }
};

/* Preference keys that "Reset interface" clears. Scripts (tabs.v1) and
   favourites are user data, not layout, so they survive a reset. */
export const PREF_KEYS = [
  "wordWrap", "minimap", "fontSize", "motion", "sidebar",
  "layout.outH", "console.ts", "console.wrap", "library.filter", "console.filter"
];
