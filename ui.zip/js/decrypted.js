export function animateDecryptedText({
  element,
  text = "",
  speed = 100,
  maxIterations = 10,
  sequential = true,
  revealDirection = "start",
  useOriginalCharsOnly = false,
  characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz!@#$%^&*()_+",
  className = "decrypted-revealed",
  parentClassName = "decrypted-text",
  encryptedClassName = "decrypted-encrypted",
  onProgress = null,
} = {}) {
  return new Promise((resolve) => {
    if (!element) {
      resolve();
      return;
    }

    const availableChars = useOriginalCharsOnly
      ? Array.from(new Set(text.split(""))).filter((c) => c !== " ")
      : characters.split("");

    const computeOrder = (len) => {
      const order = [];
      if (len <= 0) return order;
      if (revealDirection === "start") {
        for (let i = 0; i < len; i++) order.push(i);
        return order;
      }
      if (revealDirection === "end") {
        for (let i = len - 1; i >= 0; i--) order.push(i);
        return order;
      }

      const middle = Math.floor(len / 2);
      let offset = 0;
      while (order.length < len) {
        if (offset % 2 === 0) {
          const idx = middle + offset / 2;
          if (idx >= 0 && idx < len) order.push(idx);
        } else {
          const idx = middle - Math.ceil(offset / 2);
          if (idx >= 0 && idx < len) order.push(idx);
        }
        offset++;
      }
      return order.slice(0, len);
    };

    const textLength = text.length;
    const revealedIndices = new Set();
    const order = computeOrder(textLength);
    let pointer = 0;
    let iteration = 0;

    const render = (revealedSet) => {
      const chars = text.split("").map((origChar, idx) => {
        if (origChar === " ") {
          return '<span class="decrypted-space"> </span>';
        }
        if (revealedSet.has(idx)) {
          return `<span class="${className}">${origChar}</span>`;
        }
        const randChar = availableChars[Math.floor(Math.random() * availableChars.length)] || "#";
        return `<span class="${encryptedClassName}">${randChar}</span>`;
      });

      element.innerHTML = `<span class="${parentClassName}" aria-label="${text}"><span aria-hidden="true">${chars.join("")}</span></span>`;
    };

    render(revealedIndices);

    const interval = setInterval(() => {
      if (sequential) {
        if (pointer < order.length) {
          revealedIndices.add(order[pointer]);
          pointer++;
          render(revealedIndices);
          if (typeof onProgress === "function") {
            onProgress(pointer / order.length);
          }
        } else {
          clearInterval(interval);
          render(new Set(Array.from({ length: textLength }, (_, i) => i)));
          if (typeof onProgress === "function") onProgress(1);
          resolve();
        }
      } else {
        iteration++;
        render(revealedIndices);
        if (typeof onProgress === "function") {
          onProgress(iteration / maxIterations);
        }
        if (iteration >= maxIterations) {
          clearInterval(interval);
          render(new Set(Array.from({ length: textLength }, (_, i) => i)));
          if (typeof onProgress === "function") onProgress(1);
          resolve();
        }
      }
    }, Math.max(16, speed));
  });
}
