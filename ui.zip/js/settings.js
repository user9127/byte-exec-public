import { $ } from "./dom.js";
import { state } from "./state.js";
import { store, PREF_KEYS } from "./store.js";
import { bridgeGet, bridgePost, bridgePut, BRIDGE } from "./bridge.js";
import { initSeg, setSeg } from "./seg.js";
import { applyEditorOptions } from "./editor.js";
import { setSidebarPref } from "./nav.js";
import { killRoblox, openDiscord } from "./actions.js";
import { openShortcuts } from "./shortcuts.js";
import { confirmDialog } from "./dialog.js";
import { toast } from "./toast.js";
import { emit, on } from "./bus.js";

const html = document.documentElement;
const FONT_MIN = 11;
const FONT_MAX = 20;

export function applyLocalPrefs() {
  const motion = store.get("motion", "system");
  html.dataset.motion = ["system", "reduced", "full"].includes(motion) ? motion : "system";
  state.settings.wordWrap = !!store.get("wordWrap", false);
  state.settings.minimap = !!store.get("minimap", false);
  const fs = Number(store.get("fontSize", 13));
  state.settings.fontSize = Number.isFinite(fs) ? Math.min(FONT_MAX, Math.max(FONT_MIN, Math.round(fs))) : 13;
}

function syncSwitch(sel, on) {
  const el = $(sel);
  if (!el) return;
  el.classList.toggle("on", !!on);
  el.setAttribute("aria-checked", on ? "true" : "false");
}

function syncSlider() {
  const r = $("#range-fontsize");
  r.value = String(state.settings.fontSize);
  r.style.setProperty("--p", `${((state.settings.fontSize - FONT_MIN) / (FONT_MAX - FONT_MIN)) * 100}%`);
  $("#fontsize-val").textContent = String(state.settings.fontSize);
}

function syncAll() {
  syncSwitch("#switch-autoinject", state.settings.autoInject);
  syncSwitch("#switch-autoupdate", state.settings.autoUpdate);
  syncSwitch("#switch-forceupdate", state.settings.forceUpdate);
  syncSwitch("#switch-wordwrap", state.settings.wordWrap);
  syncSwitch("#switch-minimap", state.settings.minimap);
  syncSwitch("#switch-compact", store.get("sidebar", "expanded") === "collapsed");
  setSeg($("#seg-tabsize"), String(state.settings.tabSize));
  setSeg($("#seg-motion"), html.dataset.motion);
  syncSlider();
}

function renderVersion() {
  for (const id of ["#settings-version", "#sb-version", "#sidebar-version"]) {
    const el = $(id);
    if (el) el.textContent = state.version;
  }
}

export async function loadSettings() {
  const s = await bridgeGet("/settings");
  if (!s) { syncAll(); return false; }
  state.settings.autoInject = !!s.autoInject;
  state.settings.autoUpdate = s.autoUpdate !== false;
  state.settings.forceUpdate = !!s.forceUpdate;
  if (typeof s.tabSize === "number" && s.tabSize > 0) state.settings.tabSize = s.tabSize;
  if (s.version) { state.version = s.version; renderVersion(); }
  syncAll();
  applyEditorOptions();
  emit("settings");
  return true;
}

async function putSetting(patch, revert) {
  const r = await bridgePut("/settings", patch);
  if (r && r.ok === false) {
    revert();
    syncAll();
    toast("Could not save that setting. Is Byte.exe still running?", "err");
  }
}

function bindToggle(sel, fn) {
  $(sel).addEventListener("click", fn);
}

async function resetInterface() {
  const ok = await confirmDialog({
    title: "Reset the interface?",
    message: "Layout, appearance and editor display settings go back to their defaults. Open scripts and favorites are kept.",
    confirmLabel: "Reset",
    iconName: "reset"
  });
  if (!ok) return;
  PREF_KEYS.forEach((k) => store.remove(k));
  applyLocalPrefs();
  setSidebarPref(false);
  emit("motion");
  emit("prefs-reset");
  applyEditorOptions();
  syncAll();
  toast("Interface reset to defaults.", "ok");
}

export function initSettings() {
  bindToggle("#switch-autoinject", () => {
    state.settings.autoInject = !state.settings.autoInject;
    syncSwitch("#switch-autoinject", state.settings.autoInject);
    putSetting({ autoInject: state.settings.autoInject }, () => { state.settings.autoInject = !state.settings.autoInject; });
  });
  bindToggle("#switch-autoupdate", () => {
    state.settings.autoUpdate = !state.settings.autoUpdate;
    syncSwitch("#switch-autoupdate", state.settings.autoUpdate);
    putSetting({ autoUpdate: state.settings.autoUpdate }, () => { state.settings.autoUpdate = !state.settings.autoUpdate; });
  });
  // When "force update" is on, the boot flow silently kicks off the Roblox
  // installer the moment it detects the user isn't on the supported version
  // (no prompt). Off = ask every boot with a confirmDialog.
  $("#switch-forceupdate")?.addEventListener("click", () => {
    state.settings.forceUpdate = !state.settings.forceUpdate;
    syncSwitch("#switch-forceupdate", state.settings.forceUpdate);
    putSetting({ forceUpdate: state.settings.forceUpdate }, () => { state.settings.forceUpdate = !state.settings.forceUpdate; });
  });
  bindToggle("#switch-wordwrap", () => {
    state.settings.wordWrap = !state.settings.wordWrap;
    store.set("wordWrap", state.settings.wordWrap);
    syncSwitch("#switch-wordwrap", state.settings.wordWrap);
    applyEditorOptions();
  });
  bindToggle("#switch-minimap", () => {
    state.settings.minimap = !state.settings.minimap;
    store.set("minimap", state.settings.minimap);
    syncSwitch("#switch-minimap", state.settings.minimap);
    applyEditorOptions();
  });
  bindToggle("#switch-compact", () => {
    const collapsed = store.get("sidebar", "expanded") !== "collapsed";
    setSidebarPref(collapsed);
    syncSwitch("#switch-compact", collapsed);
  });

  initSeg($("#seg-tabsize"), String(state.settings.tabSize), (v) => {
    const prev = state.settings.tabSize;
    state.settings.tabSize = parseInt(v, 10) || 4;
    applyEditorOptions();
    putSetting({ tabSize: state.settings.tabSize }, () => { state.settings.tabSize = prev; applyEditorOptions(); });
  });
  initSeg($("#seg-motion"), html.dataset.motion, (v) => {
    html.dataset.motion = v;
    store.set("motion", v);
    emit("motion");
  });

  const range = $("#range-fontsize");
  range.addEventListener("input", () => {
    state.settings.fontSize = parseInt(range.value, 10) || 13;
    syncSlider();
    applyEditorOptions();
  });
  range.addEventListener("change", () => store.set("fontSize", state.settings.fontSize));

  $("#btn-kill-roblox").addEventListener("click", killRoblox);
  $("#btn-show-shortcuts").addEventListener("click", openShortcuts);
  $("#btn-settings-discord").addEventListener("click", openDiscord);
  $("#btn-reset-ui").addEventListener("click", resetInterface);
  $("#btn-fix-files")?.addEventListener("click", runFixFiles);
  $("#settings-bridge").textContent = BRIDGE;

  on("sidebar", () => syncSwitch("#switch-compact", store.get("sidebar", "expanded") === "collapsed"));
  syncAll();
  renderVersion();
}

// Fix Files: posts /fix-files, host re-verifies every artifact and re-pulls
// anything missing or hash-mismatched. Shows a toast with the counts and a
// badge on the Maintenance card.
async function runFixFiles() {
  const btn = $("#btn-fix-files");
  const badge = $("#fix-files-badge");
  const badgeText = $("#fix-files-badge-text");
  const lastEl = $("#fix-files-last");
  if (!btn || btn.classList.contains("loading")) return;

  btn.classList.add("loading");
  btn.disabled = true;
  if (badge) badge.hidden = true;
  toast("Verifying Byte files…", "info", 2000);

  const r = await bridgePost("/fix-files", {}, { timeout: 120000 });

  btn.classList.remove("loading");
  btn.disabled = false;
  const now = new Date().toLocaleTimeString();
  if (lastEl) lastEl.textContent = now;

  if (r?.ok) {
    const fixed = r.fixed || 0;
    const kind = fixed === 0 ? "ok" : "ok";
    if (badge) {
      badge.hidden = false;
      badge.className = "badge ok";
    }
    if (badgeText) badgeText.textContent = fixed === 0 ? "All good" : `${fixed} fixed`;
    toast(fixed === 0 ? "All files are in place." : `Fixed ${fixed} file${fixed === 1 ? "" : "s"}.`, kind, 3000);
  } else {
    if (badge) {
      badge.hidden = false;
      badge.className = "badge err";
    }
    if (badgeText) badgeText.textContent = "Failed";
    toast(r?.error || "Could not fix files. Check your connection.", "err", 3500);
  }
}
