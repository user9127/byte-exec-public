/* Settings page. Bridge-backed: autoInject, autoUpdate, tabSize (shared with
   the native launcher). Local: editor wrap/minimap/font size, motion,
   compact sidebar. */

import { $ } from "./dom.js";
import { state } from "./state.js";
import { store, PREF_KEYS } from "./store.js";
import { bridgeGet, bridgePut, BRIDGE } from "./bridge.js";
import { initSeg, setSeg } from "./seg.js";
import { applyEditorOptions } from "./editor.js";
import { setSidebarPref } from "./nav.js";
import { killRoblox, openDiscord } from "./actions.js";
import { openShortcuts } from "./shortcuts.js";
import { confirmDialog } from "./dialog.js";
import { toast } from "./toast.js";
import { emit, on } from "./bus.js";

const html = document.documentElement;
const FONT_MIN = 11;
const FONT_MAX = 20;

/* runs before first paint so the app never flashes the wrong motion mode */
export function applyLocalPrefs() {
  const motion = store.get("motion", "system");
  html.dataset.motion = ["system", "reduced", "full"].includes(motion) ? motion : "system";
  state.settings.wordWrap = !!store.get("wordWrap", false);
  state.settings.minimap = !!store.get("minimap", false);
  const fs = Number(store.get("fontSize", 13));
  state.settings.fontSize = Number.isFinite(fs) ? Math.min(FONT_MAX, Math.max(FONT_MIN, Math.round(fs))) : 13;
}

function syncSwitch(sel, on) {
  const el = $(sel);
  if (!el) return;
  el.classList.toggle("on", !!on);
  el.setAttribute("aria-checked", on ? "true" : "false");
}

function syncSlider() {
  const r = $("#range-fontsize");
  r.value = String(state.settings.fontSize);
  r.style.setProperty("--p", `${((state.settings.fontSize - FONT_MIN) / (FONT_MAX - FONT_MIN)) * 100}%`);
  $("#fontsize-val").textContent = String(state.settings.fontSize);
}

function syncAll() {
  syncSwitch("#switch-autoinject", state.settings.autoInject);
  syncSwitch("#switch-autoupdate", state.settings.autoUpdate);
  syncSwitch("#switch-wordwrap", state.settings.wordWrap);
  syncSwitch("#switch-minimap", state.settings.minimap);
  syncSwitch("#switch-compact", store.get("sidebar", "expanded") === "collapsed");
  setSeg($("#seg-tabsize"), String(state.settings.tabSize));
  setSeg($("#seg-motion"), html.dataset.motion);
  syncSlider();
}

function renderVersion() {
  for (const id of ["#settings-version", "#sb-version", "#sidebar-version"]) {
    const el = $(id);
    if (el) el.textContent = state.version;
  }
}

export async function loadSettings() {
  const s = await bridgeGet("/settings");
  if (!s) { syncAll(); return false; }
  state.settings.autoInject = !!s.autoInject;
  state.settings.autoUpdate = s.autoUpdate !== false;
  if (typeof s.tabSize === "number" && s.tabSize > 0) state.settings.tabSize = s.tabSize;
  if (s.version) { state.version = s.version; renderVersion(); }
  syncAll();
  applyEditorOptions();
  emit("settings");
  return true;
}

async function putSetting(patch, revert) {
  const r = await bridgePut("/settings", patch);
  if (r && r.ok === false) {
    revert();
    syncAll();
    toast("Could not save that setting. Is Byte.exe still running?", "err");
  }
}

function bindToggle(sel, fn) {
  $(sel).addEventListener("click", fn);
}

async function resetInterface() {
  const ok = await confirmDialog({
    title: "Reset the interface?",
    message: "Layout, appearance and editor display settings go back to their defaults. Open scripts and favorites are kept.",
    confirmLabel: "Reset",
    iconName: "reset"
  });
  if (!ok) return;
  PREF_KEYS.forEach((k) => store.remove(k));
  applyLocalPrefs();
  setSidebarPref(false);
  emit("motion");
  emit("prefs-reset");
  applyEditorOptions();
  syncAll();
  toast("Interface reset to defaults.", "ok");
}

export function initSettings() {
  bindToggle("#switch-autoinject", () => {
    state.settings.autoInject = !state.settings.autoInject;
    syncSwitch("#switch-autoinject", state.settings.autoInject);
    putSetting({ autoInject: state.settings.autoInject }, () => { state.settings.autoInject = !state.settings.autoInject; });
  });
  bindToggle("#switch-autoupdate", () => {
    state.settings.autoUpdate = !state.settings.autoUpdate;
    syncSwitch("#switch-autoupdate", state.settings.autoUpdate);
    putSetting({ autoUpdate: state.settings.autoUpdate }, () => { state.settings.autoUpdate = !state.settings.autoUpdate; });
  });
  bindToggle("#switch-wordwrap", () => {
    state.settings.wordWrap = !state.settings.wordWrap;
    store.set("wordWrap", state.settings.wordWrap);
    syncSwitch("#switch-wordwrap", state.settings.wordWrap);
    applyEditorOptions();
  });
  bindToggle("#switch-minimap", () => {
    state.settings.minimap = !state.settings.minimap;
    store.set("minimap", state.settings.minimap);
    syncSwitch("#switch-minimap", state.settings.minimap);
    applyEditorOptions();
  });
  bindToggle("#switch-compact", () => {
    const collapsed = store.get("sidebar", "expanded") !== "collapsed";
    setSidebarPref(collapsed);
    syncSwitch("#switch-compact", collapsed);
  });

  initSeg($("#seg-tabsize"), String(state.settings.tabSize), (v) => {
    const prev = state.settings.tabSize;
    state.settings.tabSize = parseInt(v, 10) || 4;
    applyEditorOptions();
    putSetting({ tabSize: state.settings.tabSize }, () => { state.settings.tabSize = prev; applyEditorOptions(); });
  });
  initSeg($("#seg-motion"), html.dataset.motion, (v) => {
    html.dataset.motion = v;
    store.set("motion", v);
    emit("motion");
  });

  const range = $("#range-fontsize");
  range.addEventListener("input", () => {
    state.settings.fontSize = parseInt(range.value, 10) || 13;
    syncSlider();
    applyEditorOptions();
  });
  range.addEventListener("change", () => store.set("fontSize", state.settings.fontSize));

  $("#btn-kill-roblox").addEventListener("click", killRoblox);
  $("#btn-show-shortcuts").addEventListener("click", openShortcuts);
  $("#btn-settings-discord").addEventListener("click", openDiscord);
  $("#btn-reset-ui").addEventListener("click", resetInterface);
  $("#settings-bridge").textContent = BRIDGE;

  on("sidebar", () => syncSwitch("#switch-compact", store.get("sidebar", "expanded") === "collapsed"));
  syncAll();
  renderVersion();
}
