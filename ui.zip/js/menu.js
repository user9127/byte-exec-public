import { $, icon, escapeHtml } from "./dom.js";
import { kbdHtml, hideTooltip } from "./tooltip.js";

let menu = null;
let items = [];
let active = -1;
let returnFocus = null;
let cleanup = null;

export function isMenuOpen() {
  return !!menu && !menu.hidden;
}

function setActive(i) {
  const buttons = Array.from(menu.querySelectorAll(".ctx-item"));
  if (!buttons.length) return;
  const n = buttons.length;
  let next = ((i % n) + n) % n;

  for (let guard = 0; guard < n && buttons[next].disabled; guard++) next = (next + (i >= active ? 1 : -1) + n) % n;
  buttons.forEach((b, j) => b.classList.toggle("active", j === next));
  active = next;
  buttons[next].focus({ preventScroll: true });
}

export function closeMenu({ restore = true } = {}) {
  if (!isMenuOpen()) return;
  cleanup?.();
  cleanup = null;
  menu.hidden = true;
  menu.innerHTML = "";
  if (restore && returnFocus?.isConnected) returnFocus.focus({ preventScroll: true });
  returnFocus = null;
}

export function openMenu(x, y, entries, { focusFirst = false } = {}) {
  menu = menu || $("#ctx-menu");
  if (!menu) return;
  closeMenu({ restore: false });
  hideTooltip();
  returnFocus = document.activeElement;
  items = entries.filter(Boolean);
  active = -1;

  menu.innerHTML = items
    .map((it, i) => {
      if (it === "sep") return `<div class="ctx-sep" role="separator"></div>`;
      return `<button class="ctx-item${it.danger ? " danger" : ""}" role="menuitem" tabindex="-1" data-i="${i}"${it.disabled ? " disabled" : ""}>
        ${it.icon ? icon(it.icon) : '<span style="width:14px"></span>'}
        <span>${escapeHtml(it.label)}</span>
        ${it.kbd ? `<span class="ck">${kbdHtml(it.kbd)}</span>` : ""}
      </button>`;
    })
    .join("");

  menu.hidden = false;
  menu.style.left = "0px";
  menu.style.top = "0px";
  const w = menu.offsetWidth;
  const h = menu.offsetHeight;
  const vw = window.innerWidth;
  const vh = window.innerHeight;
  const flipX = x + w > vw - 8;
  const flipY = y + h > vh - 8;
  const left = Math.max(8, flipX ? x - w : x);
  const top = Math.max(8, flipY ? y - h : y);
  menu.style.left = `${left}px`;
  menu.style.top = `${top}px`;
  menu.style.setProperty("--ox", flipX ? "100%" : "0");
  menu.style.setProperty("--oy", flipY ? "100%" : "0");

  const run = (i) => {
    const it = items[i];
    if (!it || it === "sep" || it.disabled) return;
    closeMenu();

    requestAnimationFrame(() => it.run?.());
  };

  const onClick = (e) => {
    const b = e.target.closest(".ctx-item");
    if (b) run(+b.dataset.i);
  };
  const onMove = (e) => {
    const b = e.target.closest(".ctx-item");
    if (!b || b.disabled) return;
    const all = Array.from(menu.querySelectorAll(".ctx-item"));
    all.forEach((x) => x.classList.toggle("active", x === b));
    active = all.indexOf(b);
  };
  const onKey = (e) => {
    const buttons = Array.from(menu.querySelectorAll(".ctx-item"));
    switch (e.key) {
      case "ArrowDown": e.preventDefault(); setActive(active + 1); break;
      case "ArrowUp": e.preventDefault(); setActive(active < 0 ? buttons.length - 1 : active - 1); break;
      case "Home": e.preventDefault(); setActive(0); break;
      case "End": e.preventDefault(); setActive(buttons.length - 1); break;
      case "Enter":
      case " ": e.preventDefault(); if (active >= 0) run(+buttons[active].dataset.i); break;
      case "Escape": e.preventDefault(); e.stopPropagation(); closeMenu(); break;
      case "Tab": e.preventDefault(); closeMenu(); break;
      default: break;
    }
  };
  const onOutside = (e) => { if (!menu.contains(e.target)) closeMenu({ restore: false }); };
  const onLeave = () => closeMenu({ restore: false });

  menu.addEventListener("click", onClick);
  menu.addEventListener("pointermove", onMove);
  menu.addEventListener("keydown", onKey);
  document.addEventListener("pointerdown", onOutside, true);
  window.addEventListener("blur", onLeave);
  window.addEventListener("resize", onLeave);
  cleanup = () => {
    menu.removeEventListener("click", onClick);
    menu.removeEventListener("pointermove", onMove);
    menu.removeEventListener("keydown", onKey);
    document.removeEventListener("pointerdown", onOutside, true);
    window.removeEventListener("blur", onLeave);
    window.removeEventListener("resize", onLeave);
  };

  if (focusFirst) setActive(0);
  else {

    menu.tabIndex = -1;
    menu.focus({ preventScroll: true });
  }
}
