/* Accounts page: lightweight UI over the native /accounts/* endpoints that
   port the Byte Multi Account Manager into the launcher. The cookie never
   crosses this boundary — it lives DPAPI-encrypted in the launcher's data
   dir. The UI only ever sees {id, userId, username, displayName, avatarUrl,
   note, running, pid}. */

import { $, $$ } from "./dom.js";
import { bridgeGet, bridgePost } from "./bridge.js";
import { toast } from "./toast.js";
import { confirmDialog } from "./dialog.js";

const PLACE_RE = /roblox\.com\/(?:games|game-pass|share)\/(\d+)/i;
const BARE_ID_RE = /^\d{3,}$/;

const state = {
  rows: [],         // AccountRow[] from /accounts/list
  selected: new Set(),
  multi: false,
  pollTimer: 0,
};

function parsePlace(input) {
  const s = (input || "").trim();
  if (!s) return 0;
  const m = s.match(PLACE_RE);
  if (m) return Number(m[1]);
  if (BARE_ID_RE.test(s)) return Number(s);
  return 0;
}

function fmtAvatar(a) {
  if (a.avatarUrl) {
    return `<img class="acc-avatar" src="${a.avatarUrl}" alt="" referrerpolicy="no-referrer" />`;
  }
  const init = (a.displayName || a.username || "?")[0].toUpperCase();
  return `<span class="acc-avatar fallback">${init}</span>`;
}

function render() {
  const list = $("#accounts-list");
  const empty = $("#accounts-empty");
  if (state.rows.length === 0) {
    if (empty) empty.hidden = false;
    for (const n of $$(".acc-card", list)) n.remove();
    updateLaunchButton();
    return;
  }
  if (empty) empty.hidden = true;
  const existing = new Map();
  for (const n of $$(".acc-card", list)) existing.set(n.dataset.id, n);
  for (const a of state.rows) {
    let card = existing.get(a.id);
    const selected = state.selected.has(a.id);
    const running = !!a.running;
    const html = `
      <label class="acc-sel">
        <input type="checkbox" ${selected ? "checked" : ""} data-id="${a.id}" />
      </label>
      ${fmtAvatar(a)}
      <div class="acc-who">
        <div class="acc-name">${escapeHtml(a.displayName || a.username || "?")}
          <span class="acc-user">@${escapeHtml(a.username || "?")}</span>
        </div>
        <div class="acc-meta">
          ${running ? `<span class="acc-pill ok">Running${a.pid ? ` · pid ${a.pid}` : ""}</span>` : `<span class="acc-pill">Ready</span>`}
          <span class="acc-id">id ${a.userId}</span>
          ${a.note ? `<span class="acc-note">${escapeHtml(a.note)}</span>` : ""}
        </div>
      </div>
      <div class="acc-actions">
        <button class="btn sm" data-act="launch" data-id="${a.id}">Launch</button>
        <button class="btn sm ghost" data-act="note" data-id="${a.id}">Note</button>
        <button class="btn sm danger" data-act="remove" data-id="${a.id}">Remove</button>
      </div>`;
    if (!card) {
      card = document.createElement("div");
      card.className = "acc-card";
      card.dataset.id = a.id;
      list.appendChild(card);
    }
    if (card.innerHTML !== html) card.innerHTML = html;
    existing.delete(a.id);
  }
  for (const n of existing.values()) n.remove();
  updateLaunchButton();
}

function updateLaunchButton() {
  const btn = $("#btn-acc-launch-selected");
  if (btn) btn.disabled = state.selected.size === 0;
}

function escapeHtml(s) {
  return String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

async function refresh() {
  const r = await bridgeGet("/accounts/list");
  if (!r || !r.ok) return;
  state.rows = Array.isArray(r.accounts) ? r.accounts : [];
  state.multi = !!r.multiInstance;
  const sw = $("#switch-multi");
  if (sw) sw.setAttribute("aria-checked", String(state.multi));
  // drop selections that no longer exist
  const ids = new Set(state.rows.map((a) => a.id));
  for (const id of [...state.selected]) if (!ids.has(id)) state.selected.delete(id);
  render();
}

async function doAdd() {
  const cookie = await promptCookie();
  if (!cookie) return;
  const btn = $("#btn-acc-add");
  btn.disabled = true;
  const r = await bridgePost("/accounts/add", { cookie, note: "" }, { timeout: 25000 });
  btn.disabled = false;
  if (!r?.ok) {
    toast(`Could not add account: ${r?.error || "unknown"}`, "err");
    return;
  }
  toast(r.replaced ? "Account updated." : "Account added.", "ok");
  refresh();
}

async function doLaunch(ids) {
  if (ids.length === 0) return;
  const placeStr = $("#acc-place")?.value || "";
  const placeId = parsePlace(placeStr);
  const delayMs = Math.max(200, parseInt($("#acc-delay")?.value || "1200", 10) || 1200);
  // Ensure the multi-instance mutex is held when launching more than one.
  if (ids.length > 1 && !state.multi) {
    const r = await bridgePost("/accounts/multi-instance", { enabled: true });
    if (r?.ok) state.multi = !!r.enabled;
  }
  toast(`Launching ${ids.length} account${ids.length === 1 ? "" : "s"}…`, "info");
  const r = await bridgePost("/accounts/launch", {
    ids: ids.join(","), placeId, jobId: "", delayMs,
  }, { timeout: 60000 + delayMs * ids.length });
  if (!r?.ok) {
    toast("Launch failed.", "err");
    return;
  }
  const ok = (r.results || []).filter((x) => x.ok).length;
  const bad = (r.results || []).filter((x) => !x.ok);
  toast(`Launched ${ok}/${ids.length}.${bad.length ? ` ${bad.length} failed.` : ""}`, bad.length ? "warn" : "ok");
  refresh();
}

async function doRemove(id) {
  const row = state.rows.find((a) => a.id === id);
  if (!row) return;
  const ok = await confirmDialog({
    title: `Remove ${row.displayName || row.username}?`,
    message: "The cookie is deleted from this PC. This cannot be undone.",
    confirmLabel: "Remove",
    danger: true,
  });
  if (!ok) return;
  const r = await bridgePost("/accounts/remove", { id });
  if (!r?.ok) { toast("Remove failed.", "err"); return; }
  state.selected.delete(id);
  refresh();
}

async function doNote(id) {
  const row = state.rows.find((a) => a.id === id);
  if (!row) return;
  const next = window.prompt(`Note for ${row.displayName || row.username}:`, row.note || "");
  if (next == null) return;
  const r = await bridgePost("/accounts/note", { id, note: next });
  if (!r?.ok) { toast("Could not save the note.", "err"); return; }
  refresh();
}

async function toggleMulti() {
  const want = !state.multi;
  const r = await bridgePost("/accounts/multi-instance", { enabled: want });
  if (r?.ok) {
    state.multi = !!r.enabled;
    const sw = $("#switch-multi");
    if (sw) sw.setAttribute("aria-checked", String(state.multi));
    toast(state.multi ? "Multi-instance on." : "Multi-instance off.", "ok");
  }
}

async function killAll() {
  const ok = await confirmDialog({
    title: "Kill every Roblox client?",
    message: "Every running RobloxPlayerBeta on this PC will be terminated.",
    confirmLabel: "Kill all",
    danger: true,
  });
  if (!ok) return;
  const r = await bridgePost("/accounts/kill-all");
  toast(`Terminated ${r?.killed ?? 0} client${(r?.killed ?? 0) === 1 ? "" : "s"}.`, "ok");
  refresh();
}

async function promptCookie() {
  // A minimal in-page prompt — no overlay dialog machinery needed. The
  // browser prompt() is wide enough to paste a full cookie.
  const raw = window.prompt(
    "Paste the .ROBLOSECURITY cookie value for the Roblox account.\n\n" +
    "In Chrome: F12 → Application → Cookies → .ROBLOSECURITY → Value",
    ""
  );
  return (raw || "").trim();
}

export function initAccounts() {
  $("#btn-acc-add")?.addEventListener("click", doAdd);
  $("#btn-acc-kill-all")?.addEventListener("click", killAll);
  $("#btn-acc-launch-selected")?.addEventListener("click", () => doLaunch([...state.selected]));
  $("#switch-multi")?.addEventListener("click", toggleMulti);

  const list = $("#accounts-list");
  list?.addEventListener("change", (e) => {
    const t = e.target;
    if (t.matches('input[type="checkbox"][data-id]')) {
      if (t.checked) state.selected.add(t.dataset.id);
      else state.selected.delete(t.dataset.id);
      updateLaunchButton();
    }
  });
  list?.addEventListener("click", (e) => {
    const btn = e.target.closest("button[data-act]");
    if (!btn) return;
    const id = btn.dataset.id;
    switch (btn.dataset.act) {
      case "launch": doLaunch([id]); break;
      case "remove": doRemove(id); break;
      case "note":   doNote(id); break;
    }
  });

  refresh();
  // Refresh every 10s so a Running pill flips off when the user closes Roblox.
  state.pollTimer = window.setInterval(refresh, 10000);
}
