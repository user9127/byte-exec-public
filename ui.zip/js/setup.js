// Byte auto-setup flow: starts /setup-roblox, polls /setup-status every ~300ms,
// drives the #setup-progress overlay. Resolves when the overlay closes.
// The native side owns the download + copy; this is only presentation + polling.

import { $ } from "./dom.js";
import { bridgeGet, bridgePost } from "./bridge.js";
import { openOverlay, closeOverlay } from "./dialog.js";
import { toast } from "./toast.js";
import { log } from "./console.js";

const POLL_MS = 300;

const STEP_LABEL = {
  idle:        "Preparing…",
  starting:    "Preparing…",
  downloading: "Downloading patched Roblox client…",
  copying:     "Installing Byte files…",
  done:        "Setup complete.",
  error:       "Setup failed.",
};

function mb(n) {
  const v = Number(n) || 0;
  return (v / 1024 / 1024).toFixed(1);
}

function render(status) {
  const overlay = $("#setup-progress");
  const fill = $("#setup-fill");
  const step = $("#setup-step");
  const detail = $("#setup-detail");
  const close = $("#setup-close");
  if (!overlay) return;

  overlay.classList.remove("err", "done");

  const label = STEP_LABEL[status.step] || "Working…";
  step.textContent = label;

  const pct = Math.max(0, Math.min(100, Number(status.percent) || 0));
  fill.style.width = pct + "%";

  // Download step: show MB; copy/done/error: show different sub-line.
  if (status.step === "downloading" || status.step === "starting" || status.step === "idle") {
    const totalMb = Number(status.bytesTotal) > 0 ? `${mb(status.bytesDone)} / ${mb(status.bytesTotal)} MB` : "preparing…";
    detail.textContent = totalMb;
  } else if (status.step === "copying") {
    detail.textContent = "Copying Module.dll into the Roblox folder…";
  } else if (status.step === "done") {
    overlay.classList.add("done");
    detail.textContent = status.targetHash
      ? `Ready. Roblox ${status.targetHash} is set up for Byte.`
      : "Ready.";
  } else if (status.step === "error") {
    overlay.classList.add("err");
    detail.textContent = status.error ? `Error: ${status.error}` : "Error.";
  }

  if (status.done) {
    close.hidden = false;
  } else {
    close.hidden = true;
  }
}

export function startSetup(hash) {
  const overlay = $("#setup-progress");
  const close = $("#setup-close");
  if (!overlay) {
    toast("Setup UI missing — please update Byte.", "err", 3500);
    return Promise.resolve({ ok: false, error: "overlay_missing" });
  }

  // Reset state before showing.
  render({ step: "starting", bytesDone: 0, bytesTotal: 0, percent: 0, done: false, error: "", targetHash: hash });

  return new Promise((resolve) => {
    let pollTimer = 0;
    let done = false;
    let lastStatus = null;

    const stop = (ok, err) => {
      if (done) return;
      done = true;
      clearInterval(pollTimer);
      close.onclick = () => closeOverlay(overlay, "close");
      resolve({ ok, error: err, status: lastStatus });
    };

    const onClose = () => {
      close.onclick = null;
      // If setup is still running when the user tries to close, don't let them —
      // the Close button is hidden mid-run so this is only reachable post-done.
    };

    openOverlay(overlay, { initialFocus: null, dismissible: false, onClose });

    (async () => {
      const start = await bridgePost("/setup-roblox", { hash });
      if (!start?.ok) {
        const err = start?.error || "could not start setup";
        log(`Setup kickoff failed: ${err}`, "err");
        render({ step: "error", error: err, done: true, bytesDone: 0, bytesTotal: 0, percent: 0, targetHash: hash });
        close.onclick = () => { closeOverlay(overlay, "close"); stop(false, err); };
        close.hidden = false;
        return;
      }

      log(`Setup started for ${hash}`, "info");

      pollTimer = setInterval(async () => {
        const s = await bridgeGet("/setup-status");
        if (!s?.ok) return; // transient bridge blip, keep polling
        lastStatus = s;
        render(s);
        if (s.done) {
          clearInterval(pollTimer);
          if (s.step === "done") {
            log(`Setup complete for ${s.targetHash || hash}.`, "ok");
            close.onclick = () => { closeOverlay(overlay, "close"); stop(true); };
          } else {
            log(`Setup failed: ${s.error || "unknown"}`, "err");
            close.onclick = () => { closeOverlay(overlay, "close"); stop(false, s.error); };
          }
          close.hidden = false;
        }
      }, POLL_MS);
    })();
  });
}
