/* Editor: Monaco (CDN) with a textarea fallback, persistent tabs (survive
   restarts), drag-to-reorder, inline rename, context menu, status line,
   file open/save, drag-and-drop, and the resizable output splitter. */

import { $, icon, clamp, debounce, formatBytes, saveTextFile } from "./dom.js";
import { store } from "./store.js";
import { state } from "./state.js";
import { reducedMotion } from "./motion.js";
import { toast } from "./toast.js";
import { openMenu } from "./menu.js";
import { confirmDialog } from "./dialog.js";
import { hideTooltip } from "./tooltip.js";
import { on } from "./bus.js";

const MONACO_BASE = "https://cdn.jsdelivr.net/npm/monaco-editor@0.52.0/min/vs";
const TABS_KEY = "tabs.v1";
const MAX_FILE = 4 * 1024 * 1024; // matches kMaxScriptSize in ByteUI.cpp
const FALLBACK_AFTER_MS = 3000;
const OUT_MIN = 38;
const EDITOR_MIN = 220;

const ed = { monaco: null, editor: null, fallback: false, tabs: [], activeId: 1 };
let suppressClick = false;

/* ------------------------------------------------------------- tab storage */
function loadTabs() {
  const saved = store.get(TABS_KEY);
  if (saved && Array.isArray(saved.tabs) && saved.tabs.length) {
    const seen = new Set();
    let maxId = 0;
    ed.tabs = saved.tabs
      .filter((t) => t && typeof t.name === "string")
      .map((t, i) => {
        let id = Number.isInteger(t.id) && t.id > 0 ? t.id : i + 1;
        while (seen.has(id)) id += 1000;
        seen.add(id);
        maxId = Math.max(maxId, id);
        return { id, name: t.name.slice(0, 80) || "untitled.lua", value: typeof t.value === "string" ? t.value : "", dirty: false, model: null, view: null };
      });
    ed.activeId = ed.tabs.some((t) => t.id === saved.active) ? saved.active : ed.tabs[0].id;
  }
  if (!ed.tabs.length) {
    ed.tabs = [{ id: 1, name: "untitled.lua", value: "", dirty: false, model: null, view: null }];
    ed.activeId = 1;
  }
}

const nextId = () => Math.max(0, ...ed.tabs.map((t) => t.id)) + 1;
const activeTab = () => ed.tabs.find((t) => t.id === ed.activeId) || ed.tabs[0];
const usingMonaco = () => !!ed.editor && !ed.fallback;
const tabEl = (id) => $(`.editor-tab[data-tabid="${id}"]`);

function syncFromEditor() {
  if (usingMonaco()) {
    for (const t of ed.tabs) if (t.model) t.value = t.model.getValue();
  } else {
    const t = activeTab();
    if (t) t.value = $("#fallback-editor").value;
  }
}

const persist = debounce(() => {
  syncFromEditor();
  const ok = store.set(TABS_KEY, { tabs: ed.tabs.map(({ id, name, value }) => ({ id, name, value })), active: ed.activeId });
  if (!ok && !persist.warned) {
    persist.warned = true;
    toast("Scripts are too large to keep between sessions. Save them to files.", "warn", 5000);
  }
}, 500);

export function flushPersist() { persist.flush(); }

function uniqueName(wanted = "untitled.lua") {
  const names = new Set(ed.tabs.map((t) => t.name.toLowerCase()));
  if (!names.has(wanted.toLowerCase())) return wanted;
  const dot = wanted.lastIndexOf(".");
  const base = dot > 0 ? wanted.slice(0, dot) : wanted;
  const ext = dot > 0 ? wanted.slice(dot) : "";
  for (let n = 2; ; n++) {
    const candidate = `${base}${n}${ext}`;
    if (!names.has(candidate.toLowerCase())) return candidate;
  }
}

/* ------------------------------------------------------------------ Monaco */
function defineTheme(monaco) {
  // matches the --bg/--bd/--tx scale in styles.css; syntax hues are kept
  // apart so code is not a single wash of violet
  monaco.editor.defineTheme("byte", {
    base: "vs-dark",
    inherit: true,
    rules: [
      { token: "", foreground: "e3e1ea" },
      { token: "comment", foreground: "5c5870", fontStyle: "italic" },
      { token: "keyword", foreground: "b5a2ff" },
      { token: "string", foreground: "8fcf9f" },
      { token: "string.escape", foreground: "c7e6a8" },
      { token: "number", foreground: "e3b26d" },
      { token: "number.hex", foreground: "e3b26d" },
      { token: "number.float", foreground: "e3b26d" },
      { token: "delimiter", foreground: "78738a" },
      { token: "delimiter.bracket", foreground: "aaa6b8" },
      { token: "operator", foreground: "aaa6b8" },
      { token: "type", foreground: "7cc4e4" }
    ],
    colors: {
      "editor.background": "#07060b",
      "editor.foreground": "#e3e1ea",
      "editorLineNumber.foreground": "#3a3448",
      "editorLineNumber.activeForeground": "#aaa6b8",
      "editorCursor.foreground": "#b5a2ff",
      "editor.lineHighlightBackground": "#0e0c14",
      "editor.lineHighlightBorder": "#00000000",
      "editor.selectionBackground": "#2c2450",
      "editor.inactiveSelectionBackground": "#201b33",
      "editor.selectionHighlightBackground": "#1f1a33",
      "editor.wordHighlightBackground": "#1f1a33",
      "editor.findMatchBackground": "#3b2a75",
      "editor.findMatchHighlightBackground": "#241c45",
      "editorIndentGuide.background1": "#16131d",
      "editorIndentGuide.activeBackground1": "#2b2638",
      "editorBracketMatch.background": "#1f1a33",
      "editorBracketMatch.border": "#5a2ce6",
      "editorBracketHighlight.foreground1": "#c9c5d6",
      "editorBracketHighlight.foreground2": "#9d98b0",
      "editorBracketHighlight.foreground3": "#b5a2ff",
      "editorGutter.background": "#07060b",
      "editorWidget.background": "#110e18",
      "editorWidget.border": "#282233",
      "editorSuggestWidget.background": "#110e18",
      "editorSuggestWidget.border": "#282233",
      "editorSuggestWidget.selectedBackground": "#201b29",
      "editorSuggestWidget.highlightForeground": "#b5a2ff",
      "editorSuggestWidget.focusHighlightForeground": "#d4c8ff",
      "editorHoverWidget.background": "#110e18",
      "editorHoverWidget.border": "#282233",
      "list.hoverBackground": "#18141f",
      "list.activeSelectionBackground": "#201b29",
      "list.focusOutline": "#00000000",
      "menu.background": "#110e18",
      "menu.foreground": "#e3e1ea",
      "menu.selectionBackground": "#201b29",
      "menu.border": "#282233",
      "menu.separatorBackground": "#1c1825",
      "scrollbarSlider.background": "#28223380",
      "scrollbarSlider.hoverBackground": "#3a3348",
      "scrollbarSlider.activeBackground": "#5a2ce6",
      "scrollbar.shadow": "#00000000",
      "focusBorder": "#6d3bff",
      "input.background": "#0b0910",
      "input.border": "#282233",
      "inputOption.activeBorder": "#6d3bff",
      "editorOverviewRuler.border": "#00000000",
      "minimap.background": "#07060b",
      "minimapSlider.background": "#28223360",
      "editorStickyScroll.background": "#0b0910",
      "editorStickyScrollHover.background": "#110e18",
      "editorWhitespace.foreground": "#2b2638",
      "editorError.foreground": "#f2555a",
      "editorWarning.foreground": "#f0b429"
    }
  });
}

function editorOptions() {
  const s = state.settings;
  const reduced = reducedMotion();
  return {
    fontFamily: '"Geist Mono Variable", ui-monospace, "Cascadia Code", Consolas, monospace',
    fontLigatures: true,
    fontSize: s.fontSize,
    lineHeight: Math.round(s.fontSize * 1.6),
    tabSize: s.tabSize,
    insertSpaces: true,
    wordWrap: s.wordWrap ? "on" : "off",
    minimap: { enabled: s.minimap, renderCharacters: false, showSlider: "mouseover", scale: 1 },
    cursorSmoothCaretAnimation: reduced ? "off" : "on",
    smoothScrolling: !reduced
  };
}

function ensureModel(tab) {
  if (tab.model || !ed.monaco) return;
  tab.model = ed.monaco.editor.createModel(tab.value || "", "lua");
  tab.model.updateOptions({ tabSize: state.settings.tabSize, insertSpaces: true });
  tab.model.onDidChangeContent(() => {
    if (!tab.dirty) { tab.dirty = true; tabEl(tab.id)?.classList.add("dirty"); }
    persist();
    if (tab.id === ed.activeId) updateStatus();
  });
}

function mountMonaco(monaco) {
  if (ed.editor) return;
  ed.monaco = monaco;
  defineTheme(monaco);

  // anything typed into the fallback while Monaco loaded carries over
  if (ed.fallback) {
    const t = activeTab();
    if (t) t.value = $("#fallback-editor").value;
  }
  for (const t of ed.tabs) ensureModel(t);

  ed.editor = monaco.editor.create($("#monaco-host"), {
    model: activeTab().model,
    language: "lua",
    theme: "byte",
    automaticLayout: true,
    scrollBeyondLastLine: false,
    lineNumbers: "on",
    renderLineHighlight: "all",
    roundedSelection: true,
    padding: { top: 14, bottom: 14 },
    folding: true,
    cursorBlinking: "smooth",
    bracketPairColorization: { enabled: true },
    guides: { bracketPairs: "active", indentation: true },
    stickyScroll: { enabled: true },
    fixedOverflowWidgets: true,
    dropIntoEditor: { enabled: false },
    overviewRulerBorder: false,
    hideCursorInOverviewRuler: true,
    renderWhitespace: "selection",
    scrollbar: { verticalScrollbarSize: 10, horizontalScrollbarSize: 10, useShadows: false },
    ...editorOptions()
  });

  ed.fallback = false;
  $("#fallback-editor").style.display = "none";
  $("#monaco-host").classList.add("ready");
  $("#editor-loading").classList.add("done");

  ed.editor.onDidChangeCursorSelection(updateCursor);
  ed.editor.onDidChangeModel(() => { updateStatus(); updateCursor(); });
  // Geist Mono arrives after Monaco measures; remeasure or the caret drifts
  document.fonts?.ready.then(() => monaco.editor.remeasureFonts()).catch(() => {});
  updateStatus();
  updateCursor();
}

function loadMonaco() {
  // Monaco spawns its worker from the CDN; cross-origin workers need a same-origin bootstrap
  window.MonacoEnvironment = {
    getWorkerUrl() {
      const src = `self.MonacoEnvironment={baseUrl:'${MONACO_BASE}/../'};importScripts('${MONACO_BASE}/base/worker/workerMain.js');`;
      return `data:text/javascript;charset=utf-8,${encodeURIComponent(src)}`;
    }
  };
  const s = document.createElement("script");
  s.src = `${MONACO_BASE}/loader.js`;
  s.onload = () => {
    try {
      window.require.config({ paths: { vs: MONACO_BASE } });
      window.require(["vs/editor/editor.main"], () => mountMonaco(window.monaco), activateFallback);
    } catch {
      activateFallback();
    }
  };
  s.onerror = activateFallback;
  document.head.appendChild(s);
}

/* ---------------------------------------------------------------- fallback */
function activateFallback() {
  if (ed.editor || ed.fallback) return;
  ed.fallback = true;
  const fb = $("#fallback-editor");
  fb.style.display = "block";
  fb.value = activeTab().value || "";
  $("#editor-loading").classList.add("done");
  applyEditorOptions();
  updateStatus();
}

function bindFallback() {
  const fb = $("#fallback-editor");
  fb.addEventListener("input", () => {
    const t = activeTab();
    if (t && !t.dirty) { t.dirty = true; tabEl(t.id)?.classList.add("dirty"); }
    persist();
    updateStatus();
    updateCursor();
  });
  fb.addEventListener("keydown", (e) => {
    if (e.key === "Tab" && !e.ctrlKey && !e.altKey && !e.shiftKey) {
      e.preventDefault();
      // execCommand keeps the native undo stack intact
      document.execCommand("insertText", false, " ".repeat(state.settings.tabSize));
    }
  });
  for (const ev of ["keyup", "click", "select"]) fb.addEventListener(ev, updateCursor);
}

/* ------------------------------------------------------------- status line */
const updateSize = debounce(() => {
  const bytes = new TextEncoder().encode(currentScript()).length;
  $("#es-size").textContent = formatBytes(bytes);
}, 160);

function updateStatus() {
  let lines = 1;
  if (usingMonaco()) lines = ed.editor.getModel()?.getLineCount() ?? 1;
  else {
    const v = $("#fallback-editor").value;
    lines = v ? v.split("\n").length : 1;
  }
  $("#es-lines").textContent = `${lines} line${lines === 1 ? "" : "s"}`;
  $("#es-indent").textContent = `Spaces: ${state.settings.tabSize}`;
  updateSize();
}

function updateCursor() {
  let ln = 1;
  let col = 1;
  let sel = 0;
  if (usingMonaco()) {
    const p = ed.editor.getPosition();
    const s = ed.editor.getSelection();
    if (p) { ln = p.lineNumber; col = p.column; }
    if (s && !s.isEmpty()) sel = ed.editor.getModel().getValueInRange(s).length;
  } else {
    const fb = $("#fallback-editor");
    const before = fb.value.slice(0, fb.selectionStart);
    const parts = before.split("\n");
    ln = parts.length;
    col = parts[parts.length - 1].length + 1;
    sel = Math.abs(fb.selectionEnd - fb.selectionStart);
  }
  $("#es-pos").textContent = `Ln ${ln}, Col ${col}`;
  const selEl = $("#es-sel");
  selEl.hidden = sel === 0;
  if (sel) selEl.textContent = `${sel} selected`;
}

/* --------------------------------------------------------------- options */
export function applyEditorOptions() {
  if (usingMonaco()) {
    ed.editor.updateOptions(editorOptions());
    for (const t of ed.tabs) t.model?.updateOptions({ tabSize: state.settings.tabSize, insertSpaces: true });
  } else {
    const fb = $("#fallback-editor");
    fb.style.tabSize = String(state.settings.tabSize);
    fb.style.whiteSpace = state.settings.wordWrap ? "pre-wrap" : "pre";
    fb.style.fontSize = `${state.settings.fontSize}px`;
  }
  updateStatus();
}

/* -------------------------------------------------------------------- tabs */
function updateFades() {
  const bar = $("#editor-tabs");
  const max = bar.scrollWidth - bar.clientWidth;
  bar.classList.toggle("fade-l", bar.scrollLeft > 2);
  bar.classList.toggle("fade-r", max - bar.scrollLeft > 2);
}

function renderTabs() {
  const bar = $("#editor-tabs");
  bar.querySelectorAll(".editor-tab").forEach((n) => n.remove());
  for (const t of ed.tabs) {
    const el = document.createElement("div");
    const active = t.id === ed.activeId;
    el.className = `editor-tab${active ? " active" : ""}${t.dirty ? " dirty" : ""}`;
    el.id = `tab-${t.id}`;
    el.dataset.tabid = String(t.id);
    el.dataset.tip = t.name;
    el.dataset.tipPos = "bottom";
    el.setAttribute("role", "tab");
    el.setAttribute("aria-selected", String(active));
    el.setAttribute("aria-controls", "editor-host");
    el.tabIndex = active ? 0 : -1;
    el.innerHTML =
      `${icon("code", "tab-ic")}<span class="tab-name"></span>` +
      `<span class="tab-dot" aria-hidden="true"></span>` +
      `<span class="tab-close" role="button" tabindex="-1" aria-label="Close tab">${icon("x")}</span>`;
    el.querySelector(".tab-name").textContent = t.name;
    el.querySelector(".tab-close").setAttribute("aria-label", `Close ${t.name}`);
    bar.appendChild(el);
  }
  bar.classList.toggle("multi", ed.tabs.length > 1);
  $("#editor-host").setAttribute("aria-labelledby", `tab-${ed.activeId}`);
  requestAnimationFrame(() => {
    updateFades();
    tabEl(ed.activeId)?.scrollIntoView({ block: "nearest", inline: "nearest" });
  });
}

function refreshActiveClasses() {
  for (const el of document.querySelectorAll(".editor-tab")) {
    const on = +el.dataset.tabid === ed.activeId;
    el.classList.toggle("active", on);
    el.setAttribute("aria-selected", String(on));
    el.tabIndex = on ? 0 : -1;
  }
  $("#editor-host").setAttribute("aria-labelledby", `tab-${ed.activeId}`);
  tabEl(ed.activeId)?.scrollIntoView({ block: "nearest", inline: "nearest" });
}

export function switchTab(id, { focus = true } = {}) {
  if (id === ed.activeId) return;
  const next = ed.tabs.find((t) => t.id === id);
  if (!next) return;
  if (usingMonaco()) {
    const cur = activeTab();
    if (cur) cur.view = ed.editor.saveViewState();
    ensureModel(next);
    ed.editor.setModel(next.model);
    if (next.view) ed.editor.restoreViewState(next.view);
    if (focus) ed.editor.focus();
  } else {
    const fb = $("#fallback-editor");
    const cur = activeTab();
    if (cur) cur.value = fb.value;
    fb.value = next.value || "";
  }
  ed.activeId = id;
  refreshActiveClasses();
  updateStatus();
  updateCursor();
  persist();
}

export function cycleTab(dir = 1) {
  if (ed.tabs.length < 2) return;
  const i = ed.tabs.findIndex((t) => t.id === ed.activeId);
  switchTab(ed.tabs[(i + dir + ed.tabs.length) % ed.tabs.length].id);
}

export function newTab({ name = null, value = "", focus = true } = {}) {
  const id = nextId();
  const tab = { id, name: uniqueName(name || "untitled.lua"), value, dirty: false, model: null, view: null };
  ed.tabs.push(tab);
  if (usingMonaco()) {
    const cur = activeTab();
    if (cur) cur.view = ed.editor.saveViewState();
    ensureModel(tab);
    ed.editor.setModel(tab.model);
    if (focus) ed.editor.focus();
  } else {
    const fb = $("#fallback-editor");
    const cur = activeTab();
    if (cur) cur.value = fb.value;
    fb.value = value;
    if (focus && ed.fallback) fb.focus();
  }
  ed.activeId = id;
  renderTabs();
  updateStatus();
  updateCursor();
  persist();
  return tab;
}

function removeTab(id) {
  const idx = ed.tabs.findIndex((t) => t.id === id);
  if (idx === -1) return null;
  const [t] = ed.tabs.splice(idx, 1);
  if (ed.activeId === id) {
    const next = ed.tabs[Math.max(0, idx - 1)];
    ed.activeId = next.id;
    if (usingMonaco()) {
      ensureModel(next);
      ed.editor.setModel(next.model);
      if (next.view) ed.editor.restoreViewState(next.view);
    } else {
      $("#fallback-editor").value = next.value || "";
    }
  }
  try { t.model?.dispose(); } catch { /* already disposed */ }
  return { tab: t, index: idx };
}

function reopen(snapshot) {
  const tab = newTab({ name: snapshot.name, value: snapshot.value });
  const i = ed.tabs.indexOf(tab);
  if (i !== -1 && snapshot.index < ed.tabs.length - 1) {
    ed.tabs.splice(i, 1);
    ed.tabs.splice(snapshot.index, 0, tab);
    renderTabs();
    persist();
  }
}

export function closeTab(id = ed.activeId) {
  if (ed.tabs.length <= 1) { toast("At least one tab has to stay open.", "warn"); return; }
  if (!ed.tabs.some((t) => t.id === id)) return;
  hideTooltip();
  syncFromEditor();
  const removed = removeTab(id);
  renderTabs();
  updateStatus();
  updateCursor();
  persist();
  if (removed && removed.tab.value.trim()) {
    const snap = { name: removed.tab.name, value: removed.tab.value, index: removed.index };
    toast(`Closed ${removed.tab.name}.`, "info", 4500, { action: { label: "Undo", run: () => reopen(snap) } });
  }
}

async function closeMany(ids) {
  syncFromEditor();
  const victims = ed.tabs.filter((t) => ids.includes(t.id));
  if (!victims.length) return;
  if (victims.some((t) => t.value.trim())) {
    const ok = await confirmDialog({
      title: `Close ${victims.length} tab${victims.length > 1 ? "s" : ""}?`,
      message: "Their contents will be removed from Byte. Save anything you want to keep first.",
      confirmLabel: "Close tabs",
      danger: true,
      iconName: "x"
    });
    if (!ok) return;
  }
  for (const t of victims) removeTab(t.id);
  renderTabs();
  updateStatus();
  persist();
}

function duplicateTab(id) {
  syncFromEditor();
  const t = ed.tabs.find((x) => x.id === id);
  if (!t) return;
  const dot = t.name.lastIndexOf(".");
  const copy = dot > 0 ? `${t.name.slice(0, dot)} copy${t.name.slice(dot)}` : `${t.name} copy`;
  newTab({ name: copy, value: t.value });
}

function beginRename(id) {
  const el = tabEl(id);
  const t = ed.tabs.find((x) => x.id === id);
  if (!el || !t || el.querySelector(".tab-rename")) return;
  hideTooltip();
  const nameEl = el.querySelector(".tab-name");
  const input = document.createElement("input");
  input.type = "text";
  input.className = "tab-rename";
  input.value = t.name;
  input.maxLength = 80;
  input.spellcheck = false;
  input.setAttribute("aria-label", "Tab name");
  nameEl.replaceWith(input);
  input.focus();
  const dot = t.name.lastIndexOf(".");
  input.setSelectionRange(0, dot > 0 ? dot : t.name.length);

  let done = false;
  const commit = (save) => {
    if (done) return;
    done = true;
    const v = input.value.trim();
    if (save && v && v !== t.name) {
      t.name = v;
      persist();
    }
    renderTabs();
    if (usingMonaco()) ed.editor.focus();
  };
  input.addEventListener("keydown", (e) => {
    e.stopPropagation();
    if (e.key === "Enter") { e.preventDefault(); commit(true); }
    else if (e.key === "Escape") { e.preventDefault(); commit(false); }
  });
  input.addEventListener("blur", () => commit(true));
  input.addEventListener("pointerdown", (e) => e.stopPropagation());
  input.addEventListener("click", (e) => e.stopPropagation());
}

export function renameActiveTab() { beginRename(ed.activeId); }

function tabMenu(e, id) {
  e.preventDefault();
  const idx = ed.tabs.findIndex((t) => t.id === id);
  const right = ed.tabs.slice(idx + 1).map((t) => t.id);
  const others = ed.tabs.filter((t) => t.id !== id).map((t) => t.id);
  openMenu(e.clientX, e.clientY, [
    { label: "Rename", icon: "edit", kbd: "F2", run: () => beginRename(id) },
    { label: "Duplicate", icon: "copy", run: () => duplicateTab(id) },
    { label: "Save to file", icon: "save", run: () => { switchTab(id, { focus: false }); saveActive(); } },
    "sep",
    { label: "Close", icon: "x", kbd: "Ctrl+W", disabled: ed.tabs.length <= 1, run: () => closeTab(id) },
    { label: "Close others", disabled: !others.length, run: () => closeMany(others) },
    { label: "Close to the right", disabled: !right.length, run: () => closeMany(right) }
  ]);
}

/* drag to reorder, with neighbours sliding out of the way */
function startTabDrag(e, el) {
  if (e.button !== 0 || e.target.closest(".tab-close, .tab-rename")) return;
  const bar = $("#editor-tabs");
  const els = Array.from(bar.querySelectorAll(".editor-tab"));
  const from = els.indexOf(el);
  if (from === -1 || els.length < 2) return;
  const rects = els.map((t) => ({ left: t.offsetLeft, width: t.offsetWidth }));
  const w = rects[from].width;
  const startX = e.clientX;
  let dragging = false;
  let to = from;

  const move = (ev) => {
    const dx = ev.clientX - startX;
    if (!dragging) {
      if (Math.abs(dx) < 6) return;
      dragging = true;
      hideTooltip();
      el.setPointerCapture?.(ev.pointerId);
      el.classList.add("dragging");
      bar.classList.add("reordering");
    }
    const minDx = rects[0].left - rects[from].left;
    const maxDx = rects[rects.length - 1].left + rects[rects.length - 1].width - (rects[from].left + w);
    const cdx = clamp(dx, minDx, maxDx);
    el.style.transform = `translateX(${cdx}px)`;
    const center = rects[from].left + w / 2 + cdx;
    to = 0;
    for (let i = 0; i < rects.length; i++) {
      if (i !== from && rects[i].left + rects[i].width / 2 < center) to++;
    }
    els.forEach((t, i) => {
      if (i === from) return;
      let shift = 0;
      if (from < to && i > from && i <= to) shift = -w;
      else if (to < from && i >= to && i < from) shift = w;
      t.style.transform = shift ? `translateX(${shift}px)` : "";
    });
  };
  const up = () => {
    window.removeEventListener("pointermove", move);
    window.removeEventListener("pointerup", up);
    window.removeEventListener("pointercancel", up);
    if (!dragging) return;
    suppressClick = true;
    setTimeout(() => { suppressClick = false; }, 0);
    els.forEach((t) => { t.style.transform = ""; });
    el.classList.remove("dragging");
    bar.classList.remove("reordering");
    if (to !== from) {
      const [m] = ed.tabs.splice(from, 1);
      ed.tabs.splice(to, 0, m);
      persist();
    }
    renderTabs();
  };
  window.addEventListener("pointermove", move);
  window.addEventListener("pointerup", up);
  window.addEventListener("pointercancel", up);
}

function bindTabBar() {
  const bar = $("#editor-tabs");
  bar.addEventListener("click", (e) => {
    if (suppressClick) return;
    const el = e.target.closest(".editor-tab");
    if (!el) return;
    const id = +el.dataset.tabid;
    if (e.target.closest(".tab-close")) closeTab(id);
    else switchTab(id);
  });
  bar.addEventListener("dblclick", (e) => {
    const el = e.target.closest(".editor-tab");
    if (el && !e.target.closest(".tab-close")) beginRename(+el.dataset.tabid);
  });
  bar.addEventListener("auxclick", (e) => {
    const el = e.target.closest(".editor-tab");
    if (el && e.button === 1) { e.preventDefault(); closeTab(+el.dataset.tabid); }
  });
  bar.addEventListener("contextmenu", (e) => {
    const el = e.target.closest(".editor-tab");
    if (el) tabMenu(e, +el.dataset.tabid);
  });
  bar.addEventListener("pointerdown", (e) => {
    const el = e.target.closest(".editor-tab");
    if (el) startTabDrag(e, el);
  });
  bar.addEventListener("keydown", (e) => {
    const el = e.target.closest(".editor-tab");
    if (!el || e.target.closest(".tab-rename")) return;
    const i = ed.tabs.findIndex((t) => t.id === +el.dataset.tabid);
    let n = -1;
    if (e.key === "ArrowRight") n = (i + 1) % ed.tabs.length;
    else if (e.key === "ArrowLeft") n = (i - 1 + ed.tabs.length) % ed.tabs.length;
    else if (e.key === "Home") n = 0;
    else if (e.key === "End") n = ed.tabs.length - 1;
    else if (e.key === "Delete") { e.preventDefault(); closeTab(+el.dataset.tabid); return; }
    else if (e.key === "F2") { e.preventDefault(); beginRename(+el.dataset.tabid); return; }
    if (n < 0) return;
    e.preventDefault();
    switchTab(ed.tabs[n].id, { focus: false });
    tabEl(ed.tabs[n].id)?.focus();
  });
  bar.addEventListener("wheel", (e) => {
    if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) {
      bar.scrollLeft += e.deltaY;
      e.preventDefault();
    }
  }, { passive: false });
  bar.addEventListener("scroll", updateFades, { passive: true });
  new ResizeObserver(updateFades).observe(bar);
  $("#tab-add").addEventListener("click", () => newTab());
}

/* ---------------------------------------------------------- script access */
export function currentScript() {
  return usingMonaco() ? ed.editor.getValue() : $("#fallback-editor").value;
}

export function activeTabName() {
  return activeTab()?.name || "script.lua";
}

export function markActiveClean() {
  const t = activeTab();
  if (t) { t.dirty = false; tabEl(t.id)?.classList.remove("dirty"); }
}

export function getTabs() {
  return ed.tabs.map(({ id, name }) => ({ id, name, active: id === ed.activeId }));
}

export function focusEditor() {
  if (usingMonaco()) ed.editor.focus();
  else $("#fallback-editor").focus();
}

function replaceAll(text) {
  if (usingMonaco()) {
    const m = ed.editor.getModel();
    ed.editor.pushUndoStop();
    ed.editor.executeEdits("byte", [{ range: m.getFullModelRange(), text, forceMoveMarkers: true }]);
    ed.editor.pushUndoStop();
    ed.editor.focus();
  } else {
    const fb = $("#fallback-editor");
    fb.focus();
    fb.select();
    const ok = text ? document.execCommand("insertText", false, text) : document.execCommand("delete");
    if (!ok) fb.value = text;
    fb.dispatchEvent(new Event("input"));
  }
}

export async function pasteFromClipboard() {
  let text = "";
  try { text = await navigator.clipboard.readText(); }
  catch { toast("Clipboard access denied.", "err"); return; }
  if (!text) { toast("Clipboard empty.", "warn"); return; }
  replaceAll(text);
  toast("Loaded from clipboard.", "ok", 1600);
}

export function clearEditor() {
  const before = currentScript();
  if (!before) { focusEditor(); return; }
  replaceAll("");
  toast("Editor cleared.", "info", 4500, { action: { label: "Undo", run: () => replaceAll(before) } });
}

export function openInNewTab(name, code) {
  return newTab({ name, value: code });
}

/* ------------------------------------------------------------ file in/out */
async function openFiles(files) {
  const list = files.slice(0, 8);
  let opened = 0;
  for (const f of list) {
    if (f.size > MAX_FILE) { toast(`${f.name} is larger than 4 MB.`, "warn", 3600); continue; }
    if (!/\.(lua|luau|txt)$/i.test(f.name) && f.type && !f.type.startsWith("text/")) {
      toast(`${f.name} is not a text script.`, "warn", 3600);
      continue;
    }
    try {
      const text = await f.text();
      newTab({ name: f.name, value: text });
      opened++;
    } catch {
      toast(`Could not read ${f.name}.`, "err");
    }
  }
  if (opened) toast(opened === 1 ? `Opened ${list[0].name}.` : `Opened ${opened} files.`, "ok", 2000);
  if (files.length > list.length) toast("Only the first 8 files were opened.", "warn");
}

export function openFileDialog() {
  $("#file-input").click();
}

export async function saveActive() {
  const t = activeTab();
  let name = t?.name || "script.lua";
  if (!/\.[a-z0-9]+$/i.test(name)) name += ".lua";
  const r = await saveTextFile(name, currentScript(), { description: "Lua script", extensions: [".lua", ".luau", ".txt"] });
  if (r === "saved") toast(`Saved ${name}.`, "ok", 2000);
  else if (r === "downloaded") toast(`Downloaded ${name}.`, "ok", 2000);
  else if (r === "failed") toast("Could not save the file.", "err");
}

function bindFiles() {
  const input = $("#file-input");
  input.addEventListener("change", async () => {
    const files = Array.from(input.files || []);
    input.value = "";
    if (files.length) await openFiles(files);
  });
  $("#btn-open-file").addEventListener("click", openFileDialog);
  $("#btn-save-file").addEventListener("click", saveActive);

  const shell = $("#editor-shell");
  const overlay = $("#drop-overlay");
  const hasFiles = (e) => Array.from(e.dataTransfer?.types || []).includes("Files");
  let depth = 0;
  shell.addEventListener("dragenter", (e) => {
    if (!hasFiles(e)) return;
    e.preventDefault();
    depth++;
    overlay.classList.add("show");
  }, true);
  shell.addEventListener("dragover", (e) => {
    if (!hasFiles(e)) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = "copy";
  }, true);
  shell.addEventListener("dragleave", (e) => {
    if (!hasFiles(e)) return;
    depth = Math.max(0, depth - 1);
    if (!depth) overlay.classList.remove("show");
  }, true);
  shell.addEventListener("drop", async (e) => {
    if (!hasFiles(e)) return;
    e.preventDefault();
    e.stopPropagation();
    depth = 0;
    overlay.classList.remove("show");
    await openFiles(Array.from(e.dataTransfer.files || []));
  }, true);
}

/* ---------------------------------------------------------------- splitter */
function bindSplitter() {
  const sp = $("#splitter");
  const panel = $("#output-panel");
  const ws = $("#workspace");
  const toolbar = ws.querySelector(".exec-toolbar");
  let desired = clamp(Number(store.get("layout.outH", 200)) || 200, OUT_MIN, 2000);
  let lastOpen = desired > OUT_MIN + 6 ? desired : 200;

  // the editor keeps priority: the output panel gives way first on short windows
  const maxH = () => Math.max(OUT_MIN, ws.clientHeight - EDITOR_MIN - toolbar.offsetHeight - sp.offsetHeight);
  const render = (animateIt = false) => {
    if (!ws.clientHeight) return; // page hidden; keep the user's size for later
    const h = clamp(desired, OUT_MIN, maxH());
    if (animateIt && !reducedMotion()) {
      panel.classList.add("animating");
      setTimeout(() => panel.classList.remove("animating"), 480);
    }
    panel.style.setProperty("--out-h", `${h}px`);
    panel.classList.toggle("collapsed", h <= OUT_MIN + 4);
    sp.setAttribute("aria-valuenow", String(Math.round((h / maxH()) * 100)));
  };
  const set = (v, { animateIt = false, save = true } = {}) => {
    desired = clamp(v, OUT_MIN, Math.max(OUT_MIN, maxH()));
    if (desired > OUT_MIN + 6) lastOpen = desired;
    render(animateIt);
    if (save) store.set("layout.outH", Math.round(desired));
  };
  const toggle = () => set(desired > OUT_MIN + 6 ? OUT_MIN : lastOpen, { animateIt: true });

  sp.addEventListener("pointerdown", (e) => {
    if (e.button !== 0) return;
    e.preventDefault();
    sp.setPointerCapture(e.pointerId);
    const startY = e.clientY;
    const startH = panel.getBoundingClientRect().height;
    document.body.classList.add("resizing-v");
    sp.classList.add("dragging");
    const move = (ev) => set(startH - (ev.clientY - startY), { save: false });
    const up = () => {
      sp.removeEventListener("pointermove", move);
      sp.removeEventListener("pointerup", up);
      sp.removeEventListener("pointercancel", up);
      document.body.classList.remove("resizing-v");
      sp.classList.remove("dragging");
      store.set("layout.outH", Math.round(desired));
    };
    sp.addEventListener("pointermove", move);
    sp.addEventListener("pointerup", up);
    sp.addEventListener("pointercancel", up);
  });
  sp.addEventListener("dblclick", toggle);
  sp.addEventListener("keydown", (e) => {
    const step = { ArrowUp: 16, ArrowDown: -16, PageUp: 64, PageDown: -64 }[e.key];
    if (step) { e.preventDefault(); set(desired + step); return; }
    if (e.key === "Home") { e.preventDefault(); set(maxH(), { animateIt: true }); }
    else if (e.key === "End") { e.preventDefault(); set(OUT_MIN, { animateIt: true }); }
    else if (e.key === "Enter") { e.preventDefault(); toggle(); }
  });
  new ResizeObserver(() => render()).observe(ws);
  on("prefs-reset", () => set(200, { animateIt: true }));
  render();
}

/* -------------------------------------------------------------------- init */
export function initEditor() {
  loadTabs();
  bindTabBar();
  bindFallback();
  bindFiles();
  bindSplitter();
  renderTabs();
  updateStatus();

  // dropping a file anywhere else would navigate the WebView away from Byte
  window.addEventListener("dragover", (e) => e.preventDefault());
  window.addEventListener("drop", (e) => e.preventDefault());
  window.addEventListener("pagehide", () => persist.flush());
  window.addEventListener("beforeunload", () => persist.flush());

  loadMonaco();
  setTimeout(() => { if (!ed.editor) activateFallback(); }, FALLBACK_AFTER_MS);

  on("page", ({ to }) => {
    if (to !== "execution") return;
    requestAnimationFrame(() => {
      ed.editor?.layout();
      updateFades();
    });
  });
  on("motion", applyEditorOptions);
}
