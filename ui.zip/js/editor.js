import { $, icon, clamp, debounce, formatBytes, saveTextFile, escapeHtml } from "./dom.js";
import { store } from "./store.js";
import { state } from "./state.js";
import { reducedMotion } from "./motion.js";
import { toast } from "./toast.js";
import { openMenu } from "./menu.js";
import { confirmDialog } from "./dialog.js";
import { hideTooltip } from "./tooltip.js";
import { on, emit } from "./bus.js";
import { registerLuauLanguage } from "./luau.js";

const MONACO_BASE = "https://cdn.jsdelivr.net/npm/monaco-editor@0.52.0/min/vs";
const TABS_KEY = "tabs.v1";
const MAX_FILE = 4 * 1024 * 1024; 
const FALLBACK_AFTER_MS = 3000;
const OUT_MIN = 38;
const EDITOR_MIN = 220;

const ed = { monaco: null, editor: null, fallback: false, tabs: [], activeId: "home" };
let suppressClick = false;

function trackRecent(item) {
  if (!item || !item.name) return;
  import("./home.js").then((m) => m.recordRecent(item)).catch(() => {});
}

const parseTabId = (v) => (v === "home" ? "home" : (Number(v) || v));

function loadTabs() {
  const saved = store.get(TABS_KEY);
  let scriptTabs = [];
  if (saved && Array.isArray(saved.tabs) && saved.tabs.length) {
    const seen = new Set();
    let maxId = 0;
    scriptTabs = saved.tabs
      .filter((t) => t && typeof t.name === "string" && !t.isHome && t.id !== "home")
      .map((t, i) => {
        let id = Number.isInteger(t.id) && t.id > 0 ? t.id : i + 1;
        while (seen.has(id)) id += 1000;
        seen.add(id);
        maxId = Math.max(maxId, id);
        return { id, name: t.name.slice(0, 80) || "untitled.lua", value: typeof t.value === "string" ? t.value : "", dirty: false, model: null, view: null };
      });
  }
  if (!scriptTabs.length) {
    scriptTabs = [{ id: 1, name: "untitled.lua", value: "", dirty: false, model: null, view: null }];
  }
  ed.tabs = [
    { id: "home", name: "Home", isHome: true, value: "", dirty: false, model: null, view: null },
    ...scriptTabs
  ];
  if (saved && saved.active && ed.tabs.some((t) => String(t.id) === String(saved.active))) {
    ed.activeId = saved.active;
  } else {
    ed.activeId = "home";
  }
}

const nextId = () => {
  const nums = ed.tabs.map((t) => Number(t.id)).filter((n) => Number.isInteger(n) && n > 0);
  return nums.length ? Math.max(...nums) + 1 : 1;
};
const activeTab = () => ed.tabs.find((t) => String(t.id) === String(ed.activeId)) || ed.tabs[0];
const usingMonaco = () => !!ed.editor && !ed.fallback;
const tabEl = (id) => $(`.editor-tab[data-tabid="${id}"]`);

function syncFromEditor() {
  const cur = activeTab();
  if (cur?.isHome) return;
  if (usingMonaco()) {
    for (const t of ed.tabs) if (!t.isHome && t.model) t.value = t.model.getValue();
  } else {
    if (cur) cur.value = $("#fallback-editor").value;
  }
}

const persist = debounce(() => {
  syncFromEditor();
  const ok = store.set(TABS_KEY, {
    tabs: ed.tabs.filter((t) => !t.isHome).map(({ id, name, value }) => ({ id, name, value })),
    active: ed.activeId
  });
  if (!ok && !persist.warned) {
    persist.warned = true;
    toast("Scripts are too large to keep between sessions. Save them to files.", "warn", 5000);
  }
}, 500);

export function flushPersist() { persist.flush(); }

function uniqueName(wanted = "untitled.lua") {
  const names = new Set(ed.tabs.map((t) => t.name.toLowerCase()));
  if (!names.has(wanted.toLowerCase())) return wanted;
  const dot = wanted.lastIndexOf(".");
  const base = dot > 0 ? wanted.slice(0, dot) : wanted;
  const ext = dot > 0 ? wanted.slice(dot) : "";
  for (let n = 2; ; n++) {
    const candidate = `${base}${n}${ext}`;
    if (!names.has(candidate.toLowerCase())) return candidate;
  }
}

function defineTheme(monaco) {

  monaco.editor.defineTheme("byte", {
    base: "vs-dark",
    inherit: true,
    rules: [
      { token: "", foreground: "e5e5e5" },
      { token: "comment", foreground: "666670", fontStyle: "italic" },
      { token: "keyword", foreground: "e2e8f0", fontStyle: "bold" },
      { token: "string", foreground: "86efac" },
      { token: "string.escape", foreground: "bbf7d0" },
      { token: "number", foreground: "fde047" },
      { token: "number.hex", foreground: "fde047" },
      { token: "number.float", foreground: "fde047" },
      { token: "delimiter", foreground: "888892" },
      { token: "delimiter.bracket", foreground: "b0b0ba" },
      { token: "operator", foreground: "d4d4d8" },
      { token: "operator.typecast", foreground: "fde047" },
      { token: "type", foreground: "93c5fd" },
      { token: "keyword.global", foreground: "93c5fd" },
      { token: "string.template", foreground: "86efac" }
    ],
    colors: {
      "editor.background": "#000000",
      "editor.foreground": "#ededed",
      "editorLineNumber.foreground": "#404048",
      "editorLineNumber.activeForeground": "#d4d4d8",
      "editorCursor.foreground": "#ffffff",
      "editor.lineHighlightBackground": "#0c0c0e",
      "editor.lineHighlightBorder": "#00000000",
      "editor.selectionBackground": "#282832",
      "editor.inactiveSelectionBackground": "#1c1c22",
      "editor.selectionHighlightBackground": "#1e1e26",
      "editor.wordHighlightBackground": "#1e1e26",
      "editor.findMatchBackground": "#3f3f4e",
      "editor.findMatchHighlightBackground": "#2a2a36",
      "editorIndentGuide.background1": "#141416",
      "editorIndentGuide.activeBackground1": "#28282e",
      "editorBracketMatch.background": "#1e1e24",
      "editorBracketMatch.border": "#44444e",
      "editorBracketHighlight.foreground1": "#e4e4e7",
      "editorBracketHighlight.foreground2": "#a1a1aa",
      "editorBracketHighlight.foreground3": "#71717a",
      "editorGutter.background": "#000000",
      "editorWidget.background": "#0c0c0e",
      "editorWidget.border": "#242428",
      "editorSuggestWidget.background": "#0c0c0e",
      "editorSuggestWidget.border": "#242428",
      "editorSuggestWidget.foreground": "#f4f4f5",
      "editorSuggestWidget.selectedForeground": "#ffffff",
      "editorSuggestWidget.selectedBackground": "#1e1e24",
      "editorSuggestWidget.highlightForeground": "#ffffff",
      "editorSuggestWidget.focusHighlightForeground": "#ffffff",
      "editorHoverWidget.background": "#0c0c0e",
      "editorHoverWidget.border": "#242428",
      "editorHoverWidget.foreground": "#f4f4f5",
      "list.hoverBackground": "#16161a",
      "list.activeSelectionBackground": "#1e1e24",
      "list.activeSelectionForeground": "#ffffff",
      "list.focusOutline": "#00000000",
      "menu.background": "#0c0c0e",
      "menu.foreground": "#ededed",
      "menu.selectionBackground": "#1e1e24",
      "menu.border": "#242428",
      "menu.separatorBackground": "#1a1a1e",
      "scrollbarSlider.background": "#24242880",
      "scrollbarSlider.hoverBackground": "#383840",
      "scrollbarSlider.activeBackground": "#52525c",
      "scrollbar.shadow": "#00000000",
      "focusBorder": "#52525c",
      "input.background": "#08080a",
      "input.border": "#242428",
      "inputOption.activeBorder": "#52525c",
      "editorOverviewRuler.border": "#00000000",
      "minimap.background": "#000000",
      "minimapSlider.background": "#24242860",
      "editorStickyScroll.background": "#08080a",
      "editorStickyScrollHover.background": "#0c0c0e",
      "editorWhitespace.foreground": "#222226",
      "editorError.foreground": "#ef4444",
      "editorWarning.foreground": "#eab308"
    }
  });
}

function editorOptions() {
  const s = state.settings;
  const reduced = reducedMotion();
  return {
    fontFamily: '"Geist Mono Variable", ui-monospace, "Cascadia Code", Consolas, monospace',
    fontLigatures: true,
    fontSize: s.fontSize,
    lineHeight: Math.round(s.fontSize * 1.6),
    tabSize: s.tabSize,
    insertSpaces: true,
    wordWrap: s.wordWrap ? "on" : "off",
    minimap: { enabled: s.minimap, renderCharacters: false, showSlider: "mouseover", scale: 1 },
    cursorSmoothCaretAnimation: reduced ? "off" : "on",
    smoothScrolling: !reduced
  };
}

function ensureModel(tab) {
  if (!tab || tab.isHome || tab.model || !ed.monaco) return;
  tab.model = ed.monaco.editor.createModel(tab.value || "", "luau");
  tab.model.updateOptions({ tabSize: state.settings.tabSize, insertSpaces: true });
  tab.model.onDidChangeContent(() => {
    if (!tab.dirty) { tab.dirty = true; tabEl(tab.id)?.classList.add("dirty"); }
    persist();
    if (String(tab.id) === String(ed.activeId)) updateStatus();
  });
}

function mountMonaco(monaco) {
  if (ed.editor) return;
  ed.monaco = monaco;
  registerLuauLanguage(monaco);
  defineTheme(monaco);

  if (ed.fallback) {
    const t = activeTab();
    if (t && !t.isHome) t.value = $("#fallback-editor").value;
  }
  for (const t of ed.tabs) {
    if (!t.isHome) ensureModel(t);
  }

  const initialScriptTab = ed.tabs.find((t) => !t.isHome) || ed.tabs[0];
  if (initialScriptTab && !initialScriptTab.model) ensureModel(initialScriptTab);

  ed.editor = monaco.editor.create($("#monaco-host"), {
    model: initialScriptTab?.model || null,
    language: "luau",
    theme: "byte",
    automaticLayout: true,
    scrollBeyondLastLine: false,
    lineNumbers: "on",
    renderLineHighlight: "all",
    roundedSelection: true,
    padding: { top: 14, bottom: 14 },
    folding: true,
    cursorBlinking: "smooth",
    bracketPairColorization: { enabled: true },
    guides: { bracketPairs: "active", indentation: true },
    stickyScroll: { enabled: true },
    fixedOverflowWidgets: true,
    dropIntoEditor: { enabled: false },
    overviewRulerBorder: false,
    hideCursorInOverviewRuler: true,
    renderWhitespace: "selection",
    scrollbar: { verticalScrollbarSize: 10, horizontalScrollbarSize: 10, useShadows: false },
    acceptSuggestionOnEnter: "on",
    acceptSuggestionOnCommitCharacter: true,
    tabCompletion: "on",
    suggestOnTriggerCharacters: true,
    quickSuggestions: { other: true, comments: false, strings: true },
    suggest: {
      showMethods: true,
      showFunctions: true,
      showConstructors: true,
      showFields: true,
      showVariables: true,
      showClasses: true,
      showStructs: true,
      showInterfaces: true,
      showModules: true,
      showProperties: true,
      showEvents: true,
      showOperators: true,
      showUnits: true,
      showValues: true,
      showConstants: true,
      showEnums: true,
      showEnumMembers: true,
      showKeywords: true,
      showWords: true,
      showColors: true,
      showFiles: true,
      showReferences: true,
      showFolders: true,
      showTypeParameters: true,
      showSnippets: true
    },
    ...editorOptions()
  });

  ed.fallback = false;
  $("#fallback-editor").style.display = "none";
  $("#monaco-host").classList.add("ready");
  $("#editor-loading").classList.add("done");
  refreshTabVisibility(false);

  ed.editor.onDidChangeCursorSelection(updateCursor);
  ed.editor.onDidChangeModel(() => { updateStatus(); updateCursor(); });
  document.fonts?.ready.then(() => monaco.editor.remeasureFonts()).catch(() => {});

  const monacoOverride = document.createElement("style");
  monacoOverride.id = "byte-monaco-override";
  monacoOverride.textContent = `
    .monaco-editor .suggest-widget {
      background: #0a0a0d !important;
      border: 1px solid #242428 !important;
      border-radius: 5px !important;
      box-shadow: 0 20px 48px rgba(0,0,0,.92), 0 0 0 1px rgba(255,255,255,.04) !important;
      animation: sw-in 110ms cubic-bezier(.2,0,0,1) both !important;
    }
    .monaco-editor .suggest-widget,
    .monaco-editor .suggest-widget *,
    .monaco-editor .monaco-hover,
    .monaco-editor .monaco-hover * {
      font-family: var(--font-sans) !important;
    }
    .monaco-editor .suggest-widget .contents .main {
      display: flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      background: transparent !important;
    }
    .monaco-editor .suggest-widget .contents .main .suggest-icon {
      margin-right: 8px !important;
      flex-shrink: 0 !important;
    }
    .monaco-editor .suggest-widget .contents .main .left {
      display: inline-flex !important;
      align-items: center !important;
      flex: 1 1 auto !important;
      min-width: 0 !important;
      overflow: visible !important;
    }
    .monaco-editor .suggest-widget .contents .main .right {
      display: inline-flex !important;
      align-items: center !important;
      margin-left: auto !important;
      padding-left: 12px !important;
      flex-shrink: 0 !important;
    }
    .monaco-editor .suggest-widget .monaco-list-row {
      color: #e4e4e7 !important;
    }
    .monaco-editor .suggest-widget .monaco-list-row.focused {
      background: #1a1a22 !important;
      color: #ffffff !important;
    }
    .monaco-editor .suggest-widget .monaco-list-row .label-name,
    .monaco-editor .suggest-widget .monaco-list-row .label-name *,
    .monaco-editor .suggest-widget .monaco-list-row .monaco-icon-label,
    .monaco-editor .suggest-widget .monaco-list-row .monaco-icon-label-container,
    .monaco-editor .suggest-widget .monaco-list-row .monaco-icon-name-container,
    .monaco-editor .suggest-widget .monaco-list-row .monaco-highlighted-label,
    .monaco-editor .suggest-widget .monaco-list-row .monaco-highlighted-label span {
      color: #ffffff !important;
      opacity: 1 !important;
      visibility: visible !important;
    }
    .monaco-editor .suggest-widget .monaco-list-row.focused .label-name,
    .monaco-editor .suggest-widget .monaco-list-row.focused .label-name *,
    .monaco-editor .suggest-widget .monaco-list-row.focused .monaco-highlighted-label,
    .monaco-editor .suggest-widget .monaco-list-row.focused .monaco-highlighted-label span {
      color: #ffffff !important;
    }
    .monaco-editor .suggest-widget .monaco-list-row .highlight {
      color: #ffffff !important;
      font-weight: 700 !important;
      text-decoration: underline !important;
    }
    .monaco-editor .suggest-widget .details-label {
      color: #a1a1aa !important;
      font-size: 11px !important;
    }
    .monaco-editor .suggest-widget .details {
      background: #0a0a0d !important;
      border-color: #242428 !important;
      color: #d4d4d8 !important;
      animation: sw-in 90ms cubic-bezier(.2,0,0,1) both !important;
    }
    .monaco-editor .monaco-hover {
      background: #0a0a0d !important;
      border: 1px solid #242428 !important;
      border-radius: 5px !important;
      color: #e4e4e7 !important;
      box-shadow: 0 16px 40px rgba(0,0,0,.9) !important;
      animation: sw-in 90ms cubic-bezier(.2,0,0,1) both !important;
    }
    .monaco-editor .monaco-hover p,
    .monaco-editor .monaco-hover code,
    .monaco-editor .monaco-hover span {
      color: inherit !important;
    }
    @keyframes sw-in {
      from { opacity: 0; transform: translateY(4px); }
      to   { opacity: 1; transform: translateY(0); }
    }
  `;
  document.head.appendChild(monacoOverride);

  updateStatus();
  updateCursor();
}

function loadMonaco() {

  window.MonacoEnvironment = {
    getWorkerUrl() {
      const src = `self.MonacoEnvironment={baseUrl:'${MONACO_BASE}/../'};importScripts('${MONACO_BASE}/base/worker/workerMain.js');`;
      return `data:text/javascript;charset=utf-8,${encodeURIComponent(src)}`;
    }
  };
  const s = document.createElement("script");
  s.src = `${MONACO_BASE}/loader.js`;
  s.onload = () => {
    try {
      window.require.config({ paths: { vs: MONACO_BASE } });
      window.require(["vs/editor/editor.main"], () => mountMonaco(window.monaco), activateFallback);
    } catch {
      activateFallback();
    }
  };
  s.onerror = activateFallback;
  document.head.appendChild(s);
}

function activateFallback() {
  if (ed.editor || ed.fallback) return;
  ed.fallback = true;
  const fb = $("#fallback-editor");
  const t = activeTab();
  fb.value = (t && !t.isHome ? t.value : "") || "";
  $("#editor-loading").classList.add("done");
  applyEditorOptions();
  refreshTabVisibility(false);
  updateStatus();
}

function bindFallback() {
  const fb = $("#fallback-editor");
  fb.addEventListener("input", () => {
    const t = activeTab();
    if (t && !t.dirty) { t.dirty = true; tabEl(t.id)?.classList.add("dirty"); }
    persist();
    updateStatus();
    updateCursor();
  });
  fb.addEventListener("keydown", (e) => {
    if (e.key === "Tab" && !e.ctrlKey && !e.altKey && !e.shiftKey) {
      e.preventDefault();

      document.execCommand("insertText", false, " ".repeat(state.settings.tabSize));
    }
  });
  for (const ev of ["keyup", "click", "select"]) fb.addEventListener(ev, updateCursor);
}

const updateSize = debounce(() => {
  const bytes = new TextEncoder().encode(currentScript()).length;
  $("#es-size").textContent = formatBytes(bytes);
}, 160);

function updateStatus() {
  const cur = activeTab();
  if (cur?.isHome) {
    $("#es-lines").textContent = "Home";
    $("#es-indent").textContent = `Spaces: ${state.settings.tabSize}`;
    $("#es-size").textContent = "0 B";
    return;
  }
  let lines = 1;
  if (usingMonaco()) lines = ed.editor.getModel()?.getLineCount() ?? 1;
  else {
    const v = $("#fallback-editor").value;
    lines = v ? v.split("\n").length : 1;
  }
  $("#es-lines").textContent = `${lines} line${lines === 1 ? "" : "s"}`;
  $("#es-indent").textContent = `Spaces: ${state.settings.tabSize}`;
  updateSize();
}

function updateCursor() {
  const cur = activeTab();
  if (cur?.isHome) {
    $("#es-pos").textContent = "Ln 1, Col 1";
    const selEl = $("#es-sel");
    if (selEl) selEl.hidden = true;
    return;
  }
  let ln = 1;
  let col = 1;
  let sel = 0;
  if (usingMonaco()) {
    const p = ed.editor.getPosition();
    const s = ed.editor.getSelection();
    if (p) { ln = p.lineNumber; col = p.column; }
    if (s && !s.isEmpty()) sel = ed.editor.getModel()?.getValueInRange(s)?.length || 0;
  } else {
    const fb = $("#fallback-editor");
    const before = fb.value.slice(0, fb.selectionStart);
    const parts = before.split("\n");
    ln = parts.length;
    col = parts[parts.length - 1].length + 1;
    sel = Math.abs(fb.selectionEnd - fb.selectionStart);
  }
  $("#es-pos").textContent = `Ln ${ln}, Col ${col}`;
  const selEl = $("#es-sel");
  selEl.hidden = sel === 0;
  if (sel) selEl.textContent = `${sel} selected`;
}

export function applyEditorOptions() {
  if (usingMonaco()) {
    ed.editor.updateOptions(editorOptions());
    for (const t of ed.tabs) t.model?.updateOptions({ tabSize: state.settings.tabSize, insertSpaces: true });
  } else {
    const fb = $("#fallback-editor");
    fb.style.tabSize = String(state.settings.tabSize);
    fb.style.whiteSpace = state.settings.wordWrap ? "pre-wrap" : "pre";
    fb.style.fontSize = `${state.settings.fontSize}px`;
  }
  updateStatus();
}

function updateFades() {
  const bar = $("#editor-tabs");
  const max = bar.scrollWidth - bar.clientWidth;
  bar.classList.toggle("fade-l", bar.scrollLeft > 2);
  bar.classList.toggle("fade-r", max - bar.scrollLeft > 2);
}

function renderTabs() {
  const bar = $("#editor-tabs");
  bar.querySelectorAll(".editor-tab").forEach((n) => n.remove());
  for (const t of ed.tabs) {
    const el = document.createElement("div");
    const active = String(t.id) === String(ed.activeId);
    el.className = `editor-tab${active ? " active" : ""}${t.dirty ? " dirty" : ""}${t.isHome ? " is-home" : ""}`;
    el.id = `tab-${t.id}`;
    el.dataset.tabid = String(t.id);
    el.dataset.tip = t.name;
    el.dataset.tipPos = "bottom";
    el.setAttribute("role", "tab");
    el.setAttribute("aria-selected", String(active));
    el.setAttribute("aria-controls", "editor-host");
    el.tabIndex = active ? 0 : -1;
    if (t.isHome) {
      el.innerHTML =
        `<svg class="ic tab-ic tab-home-ic"><use href="#i-home"/></svg><span class="tab-name">${escapeHtml(t.name)}</span>`;
    } else {
      el.innerHTML =
        `${icon("code", "tab-ic")}<span class="tab-name"></span>` +
        `<span class="tab-dot" aria-hidden="true"></span>` +
        `<span class="tab-close" role="button" tabindex="-1" aria-label="Close tab">${icon("x")}</span>`;
      el.querySelector(".tab-name").textContent = t.name;
      el.querySelector(".tab-close").setAttribute("aria-label", `Close ${t.name}`);
    }
    bar.appendChild(el);
  }
  bar.classList.toggle("multi", ed.tabs.length > 1);
  $("#editor-host").setAttribute("aria-labelledby", `tab-${ed.activeId}`);
  requestAnimationFrame(() => {
    updateFades();
    tabEl(ed.activeId)?.scrollIntoView({ block: "nearest", inline: "nearest" });
  });
  emit("tabs-change");
}

function refreshActiveClasses() {
  for (const el of document.querySelectorAll(".editor-tab")) {
    const on = String(el.dataset.tabid) === String(ed.activeId);
    el.classList.toggle("active", on);
    el.setAttribute("aria-selected", String(on));
    el.tabIndex = on ? 0 : -1;
  }
  $("#editor-host").setAttribute("aria-labelledby", `tab-${ed.activeId}`);
  tabEl(ed.activeId)?.scrollIntoView({ block: "nearest", inline: "nearest" });
}

function refreshTabVisibility(focus = true) {
  const cur = activeTab();
  const homeDash = $("#home-dashboard");
  const monacoHost = $("#monaco-host");
  const fallbackEd = $("#fallback-editor");
  const edLoading = $("#editor-loading");

  if (cur?.isHome) {
    if (homeDash) homeDash.style.display = "flex";
    if (monacoHost) monacoHost.style.display = "none";
    if (fallbackEd) fallbackEd.style.display = "none";
    if (edLoading) edLoading.style.display = "none";
  } else {
    if (homeDash) homeDash.style.display = "none";
    if (usingMonaco()) {
      if (monacoHost) monacoHost.style.display = "block";
      if (fallbackEd) fallbackEd.style.display = "none";
      ensureModel(cur);
      ed.editor.setModel(cur.model);
      if (cur.view) ed.editor.restoreViewState(cur.view);
      requestAnimationFrame(() => ed.editor?.layout());
      if (focus) ed.editor.focus();
    } else {
      if (monacoHost) monacoHost.style.display = "none";
      if (fallbackEd) {
        fallbackEd.style.display = "block";
        fallbackEd.value = cur.value || "";
        if (focus && ed.fallback) fallbackEd.focus();
      }
    }
  }
}

export function switchTab(id, { focus = true } = {}) {
  const next = ed.tabs.find((t) => String(t.id) === String(id));
  if (!next) return;
  if (String(id) === String(ed.activeId)) {
    refreshTabVisibility(focus);
    return;
  }
  const cur = activeTab();
  if (cur && !cur.isHome) {
    if (usingMonaco()) {
      cur.view = ed.editor.saveViewState();
    } else {
      const fb = $("#fallback-editor");
      cur.value = fb.value;
    }
  }
  ed.activeId = next.id;
  refreshActiveClasses();
  refreshTabVisibility(focus);
  updateStatus();
  updateCursor();
  persist();
  if (next && !next.isHome) {
    trackRecent({ name: next.name, content: next.value });
  }
}

export function cycleTab(dir = 1) {
  if (ed.tabs.length < 2) return;
  const i = ed.tabs.findIndex((t) => String(t.id) === String(ed.activeId));
  switchTab(ed.tabs[(i + dir + ed.tabs.length) % ed.tabs.length].id);
}

export function newTab({ name = null, value = "", focus = true } = {}) {
  const id = nextId();
  const tab = { id, name: uniqueName(name || "untitled.lua"), value, dirty: false, model: null, view: null };
  ed.tabs.push(tab);
  const cur = activeTab();
  if (cur && !cur.isHome) {
    if (usingMonaco()) cur.view = ed.editor.saveViewState();
    else {
      const fb = $("#fallback-editor");
      cur.value = fb.value;
    }
  }
  ed.activeId = id;
  renderTabs();
  refreshTabVisibility(focus);
  updateStatus();
  updateCursor();
  persist();
  if (tab && !tab.isHome) {
    trackRecent({ name: tab.name, content: tab.value });
  }
  return tab;
}

function removeTab(id) {
  const idx = ed.tabs.findIndex((t) => String(t.id) === String(id));
  if (idx === -1 || ed.tabs[idx].isHome) return null;
  const [t] = ed.tabs.splice(idx, 1);
  if (String(ed.activeId) === String(id)) {
    const next = ed.tabs[Math.max(0, idx - 1)];
    ed.activeId = next.id;
    refreshTabVisibility(false);
  }
  try { t.model?.dispose(); } catch {  }
  return { tab: t, index: idx };
}

function reopen(snapshot) {
  const tab = newTab({ name: snapshot.name, value: snapshot.value });
  const i = ed.tabs.indexOf(tab);
  if (i !== -1 && snapshot.index < ed.tabs.length - 1) {
    ed.tabs.splice(i, 1);
    ed.tabs.splice(snapshot.index, 0, tab);
    renderTabs();
    persist();
  }
}

export function closeTab(id = ed.activeId) {
  const t = ed.tabs.find((x) => String(x.id) === String(id));
  if (!t || t.isHome) return;
  const scriptTabs = ed.tabs.filter((x) => !x.isHome);
  if (scriptTabs.length <= 1) {
    toast("Default script retained.", "info", 1600);
    return;
  }
  hideTooltip();
  syncFromEditor();
  const removed = removeTab(id);
  renderTabs();
  updateStatus();
  updateCursor();
  persist();
  if (removed && removed.tab.value.trim()) {
    const snap = { name: removed.tab.name, value: removed.tab.value, index: removed.index };
    toast(`Closed ${removed.tab.name}.`, "info", 4500, { action: { label: "Undo", run: () => reopen(snap) } });
  }
}

async function closeMany(ids) {
  syncFromEditor();
  const victims = ed.tabs.filter((t) => !t.isHome && ids.some((id) => String(id) === String(t.id)));
  if (!victims.length) return;
  if (victims.some((t) => t.value.trim())) {
    const ok = await confirmDialog({
      title: `Close ${victims.length} tab${victims.length > 1 ? "s" : ""}?`,
      message: "Their contents will be removed from Byte. Save anything you want to keep first.",
      confirmLabel: "Close tabs",
      danger: true,
      iconName: "x"
    });
    if (!ok) return;
  }
  for (const t of victims) removeTab(t.id);
  renderTabs();
  updateStatus();
  persist();
}

function duplicateTab(id) {
  const t = ed.tabs.find((x) => String(x.id) === String(id));
  if (!t || t.isHome) return;
  syncFromEditor();
  const dot = t.name.lastIndexOf(".");
  const copy = dot > 0 ? `${t.name.slice(0, dot)} copy${t.name.slice(dot)}` : `${t.name} copy`;
  newTab({ name: copy, value: t.value });
}

function beginRename(id) {
  const t = ed.tabs.find((x) => String(x.id) === String(id));
  if (!t || t.isHome) return;
  const el = tabEl(id);
  if (!el || el.querySelector(".tab-rename")) return;
  hideTooltip();
  const nameEl = el.querySelector(".tab-name");
  const input = document.createElement("input");
  input.type = "text";
  input.className = "tab-rename";
  input.value = t.name;
  input.maxLength = 80;
  input.spellcheck = false;
  input.setAttribute("aria-label", "Tab name");
  nameEl.replaceWith(input);
  input.focus();
  const dot = t.name.lastIndexOf(".");
  input.setSelectionRange(0, dot > 0 ? dot : t.name.length);

  let done = false;
  const commit = (save) => {
    if (done) return;
    done = true;
    const v = input.value.trim();
    if (save && v && v !== t.name) {
      t.name = v;
      persist();
    }
    renderTabs();
    if (usingMonaco()) ed.editor.focus();
  };
  input.addEventListener("keydown", (e) => {
    e.stopPropagation();
    if (e.key === "Enter") { e.preventDefault(); commit(true); }
    else if (e.key === "Escape") { e.preventDefault(); commit(false); }
  });
  input.addEventListener("blur", () => commit(true));
  input.addEventListener("pointerdown", (e) => e.stopPropagation());
  input.addEventListener("click", (e) => e.stopPropagation());
}

export function renameActiveTab() { beginRename(ed.activeId); }

function tabMenu(e, id) {
  e.preventDefault();
  const t = ed.tabs.find((x) => String(x.id) === String(id));
  if (!t) return;
  if (t.isHome) {
    const scriptTabs = ed.tabs.filter((x) => !x.isHome).map((x) => x.id);
    openMenu(e.clientX, e.clientY, [
      { label: "New script tab", icon: "plus", kbd: "Ctrl+T", run: () => newTab() },
      { label: "Close other tabs", disabled: !scriptTabs.length, run: () => closeMany(scriptTabs) }
    ]);
    return;
  }
  const idx = ed.tabs.findIndex((x) => String(x.id) === String(id));
  const right = ed.tabs.slice(idx + 1).filter((x) => !x.isHome).map((x) => x.id);
  const others = ed.tabs.filter((x) => String(x.id) !== String(id) && !x.isHome).map((x) => x.id);
  openMenu(e.clientX, e.clientY, [
    { label: "Rename", icon: "edit", kbd: "F2", run: () => beginRename(id) },
    { label: "Duplicate", icon: "copy", run: () => duplicateTab(id) },
    { label: "Save to file", icon: "save", run: () => { switchTab(id, { focus: false }); saveActive(); } },
    "sep",
    { label: "Close", icon: "x", kbd: "Ctrl+W", disabled: ed.tabs.filter((x) => !x.isHome).length <= 1, run: () => closeTab(id) },
    { label: "Close others", disabled: !others.length, run: () => closeMany(others) },
    { label: "Close to the right", disabled: !right.length, run: () => closeMany(right) }
  ]);
}

function startTabDrag(e, el) {
  if (e.button !== 0 || e.target.closest(".tab-close, .tab-rename") || el.classList.contains("is-home")) return;
  const bar = $("#editor-tabs");
  const els = Array.from(bar.querySelectorAll(".editor-tab"));
  const from = els.indexOf(el);
  if (from <= 0 || els.length < 3) return;
  const rects = els.map((t) => ({ left: t.offsetLeft, width: t.offsetWidth }));
  const w = rects[from].width;
  const startX = e.clientX;
  let dragging = false;
  let to = from;

  const move = (ev) => {
    const dx = ev.clientX - startX;
    if (!dragging) {
      if (Math.abs(dx) < 6) return;
      dragging = true;
      hideTooltip();
      el.setPointerCapture?.(ev.pointerId);
      el.classList.add("dragging");
      bar.classList.add("reordering");
    }
    const minDx = rects[1].left - rects[from].left;
    const maxDx = rects[rects.length - 1].left + rects[rects.length - 1].width - (rects[from].left + w);
    const cdx = clamp(dx, minDx, maxDx);
    el.style.transform = `translateX(${cdx}px)`;
    const center = rects[from].left + w / 2 + cdx;
    to = 1;
    for (let i = 1; i < rects.length; i++) {
      if (i !== from && rects[i].left + rects[i].width / 2 < center) to++;
    }
    els.forEach((t, i) => {
      if (i === 0 || i === from) return;
      let shift = 0;
      if (from < to && i > from && i <= to) shift = -w;
      else if (to < from && i >= to && i < from) shift = w;
      t.style.transform = shift ? `translateX(${shift}px)` : "";
    });
  };
  const up = () => {
    window.removeEventListener("pointermove", move);
    window.removeEventListener("pointerup", up);
    window.removeEventListener("pointercancel", up);
    if (!dragging) return;
    suppressClick = true;
    setTimeout(() => { suppressClick = false; }, 0);
    els.forEach((t) => { t.style.transform = ""; });
    el.classList.remove("dragging");
    bar.classList.remove("reordering");
    if (to !== from && to > 0) {
      const [m] = ed.tabs.splice(from, 1);
      ed.tabs.splice(to, 0, m);
      persist();
    }
    renderTabs();
  };
  window.addEventListener("pointermove", move);
  window.addEventListener("pointerup", up);
  window.addEventListener("pointercancel", up);
}

function bindTabBar() {
  const bar = $("#editor-tabs");
  bar.addEventListener("click", (e) => {
    if (suppressClick) return;
    const el = e.target.closest(".editor-tab");
    if (!el) return;
    const id = parseTabId(el.dataset.tabid);
    if (e.target.closest(".tab-close")) closeTab(id);
    else switchTab(id);
  });
  bar.addEventListener("dblclick", (e) => {
    const el = e.target.closest(".editor-tab");
    if (el && !e.target.closest(".tab-close")) beginRename(parseTabId(el.dataset.tabid));
  });
  bar.addEventListener("auxclick", (e) => {
    const el = e.target.closest(".editor-tab");
    if (el && e.button === 1) { e.preventDefault(); closeTab(parseTabId(el.dataset.tabid)); }
  });
  bar.addEventListener("contextmenu", (e) => {
    const el = e.target.closest(".editor-tab");
    if (el) tabMenu(e, parseTabId(el.dataset.tabid));
  });
  bar.addEventListener("pointerdown", (e) => {
    const el = e.target.closest(".editor-tab");
    if (el) startTabDrag(e, el);
  });
  bar.addEventListener("keydown", (e) => {
    const el = e.target.closest(".editor-tab");
    if (!el || e.target.closest(".tab-rename")) return;
    const curId = parseTabId(el.dataset.tabid);
    const i = ed.tabs.findIndex((t) => String(t.id) === String(curId));
    let n = -1;
    if (e.key === "ArrowRight") n = (i + 1) % ed.tabs.length;
    else if (e.key === "ArrowLeft") n = (i - 1 + ed.tabs.length) % ed.tabs.length;
    else if (e.key === "Home") n = 0;
    else if (e.key === "End") n = ed.tabs.length - 1;
    else if (e.key === "Delete") { e.preventDefault(); closeTab(curId); return; }
    else if (e.key === "F2") { e.preventDefault(); beginRename(curId); return; }
    if (n < 0) return;
    e.preventDefault();
    switchTab(ed.tabs[n].id, { focus: false });
    tabEl(ed.tabs[n].id)?.focus();
  });
  bar.addEventListener("wheel", (e) => {
    if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) {
      bar.scrollLeft += e.deltaY;
      e.preventDefault();
    }
  }, { passive: false });
  bar.addEventListener("scroll", updateFades, { passive: true });
  new ResizeObserver(updateFades).observe(bar);
  $("#tab-add").addEventListener("click", () => newTab());
}

export function currentScript() {
  const cur = activeTab();
  if (cur?.isHome) {
    const firstScript = ed.tabs.find((t) => !t.isHome);
    return firstScript ? firstScript.value : "";
  }
  return usingMonaco() ? ed.editor.getValue() : $("#fallback-editor").value;
}

export function activeTabName() {
  const cur = activeTab();
  if (cur?.isHome) {
    const firstScript = ed.tabs.find((t) => !t.isHome);
    return firstScript ? firstScript.name : "script.lua";
  }
  return cur?.name || "script.lua";
}

export function markActiveClean() {
  const t = activeTab();
  if (t && !t.isHome) { t.dirty = false; tabEl(t.id)?.classList.remove("dirty"); }
}

export function getTabs() {
  return ed.tabs.filter((t) => !t.isHome).map(({ id, name }) => ({ id, name, active: String(id) === String(ed.activeId) }));
}

export function focusEditor() {
  if (activeTab()?.isHome) {
    const firstScript = ed.tabs.find((t) => !t.isHome) || newTab();
    switchTab(firstScript.id, { focus: true });
    return;
  }
  if (usingMonaco()) ed.editor.focus();
  else $("#fallback-editor").focus();
}

function replaceAll(text) {
  if (activeTab()?.isHome) {
    const firstScript = ed.tabs.find((t) => !t.isHome) || newTab();
    switchTab(firstScript.id, { focus: true });
  }
  if (usingMonaco()) {
    const m = ed.editor.getModel();
    ed.editor.pushUndoStop();
    ed.editor.executeEdits("byte", [{ range: m.getFullModelRange(), text, forceMoveMarkers: true }]);
    ed.editor.pushUndoStop();
    ed.editor.focus();
  } else {
    const fb = $("#fallback-editor");
    fb.focus();
    fb.select();
    const ok = text ? document.execCommand("insertText", false, text) : document.execCommand("delete");
    if (!ok) fb.value = text;
    fb.dispatchEvent(new Event("input"));
  }
}

export async function pasteFromClipboard() {
  let text = "";
  try { text = await navigator.clipboard.readText(); }
  catch { toast("Clipboard access denied.", "err"); return; }
  if (!text) { toast("Clipboard empty.", "warn"); return; }
  replaceAll(text);
  toast("Loaded from clipboard.", "ok", 1600);
}

export function clearEditor() {
  const before = currentScript();
  if (!before) { focusEditor(); return; }
  replaceAll("");
  toast("Editor cleared.", "info", 4500, { action: { label: "Undo", run: () => replaceAll(before) } });
}

export function openInNewTab(name, code) {
  return newTab({ name, value: code });
}

async function openFiles(files) {
  const list = files.slice(0, 8);
  let opened = 0;
  for (const f of list) {
    if (f.size > MAX_FILE) { toast(`${f.name} is larger than 4 MB.`, "warn", 3600); continue; }
    if (!/\.(lua|luau|txt)$/i.test(f.name) && f.type && !f.type.startsWith("text/")) {
      toast(`${f.name} is not a text script.`, "warn", 3600);
      continue;
    }
    try {
      const text = await f.text();
      newTab({ name: f.name, value: text });
      opened++;
    } catch {
      toast(`Could not read ${f.name}.`, "err");
    }
  }
  if (opened) toast(opened === 1 ? `Opened ${list[0].name}.` : `Opened ${opened} files.`, "ok", 2000);
  if (files.length > list.length) toast("Only the first 8 files were opened.", "warn");
}

export function openFileDialog() {
  $("#file-input").click();
}

export async function saveActive() {
  const t = activeTab();
  let name = t?.name || "script.lua";
  if (!/\.[a-z0-9]+$/i.test(name)) name += ".lua";
  const r = await saveTextFile(name, currentScript(), { description: "Lua script", extensions: [".lua", ".luau", ".txt"] });
  if (r === "saved") {
    trackRecent({ name, content: currentScript() });
    toast(`Saved ${name}.`, "ok", 2000);
  } else if (r === "downloaded") {
    trackRecent({ name, content: currentScript() });
    toast(`Downloaded ${name}.`, "ok", 2000);
  } else if (r === "failed") toast("Could not save the file.", "err");
}

function bindFiles() {
  const input = $("#file-input");
  input.addEventListener("change", async () => {
    const files = Array.from(input.files || []);
    input.value = "";
    if (files.length) await openFiles(files);
  });
  $("#btn-open-file").addEventListener("click", openFileDialog);
  $("#btn-save-file").addEventListener("click", saveActive);

  const shell = $("#editor-shell");
  const overlay = $("#drop-overlay");
  const hasFiles = (e) => Array.from(e.dataTransfer?.types || []).includes("Files");
  let depth = 0;
  shell.addEventListener("dragenter", (e) => {
    if (!hasFiles(e)) return;
    e.preventDefault();
    depth++;
    overlay.classList.add("show");
  }, true);
  shell.addEventListener("dragover", (e) => {
    if (!hasFiles(e)) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = "copy";
  }, true);
  shell.addEventListener("dragleave", (e) => {
    if (!hasFiles(e)) return;
    depth = Math.max(0, depth - 1);
    if (!depth) overlay.classList.remove("show");
  }, true);
  shell.addEventListener("drop", async (e) => {
    if (!hasFiles(e)) return;
    e.preventDefault();
    e.stopPropagation();
    depth = 0;
    overlay.classList.remove("show");
    await openFiles(Array.from(e.dataTransfer.files || []));
  }, true);
}

function bindSplitter() {
  const sp = $("#splitter");
  const panel = $("#output-panel");
  const ws = $("#workspace");
  const toolbar = ws?.querySelector(".ws-action-bar, .exec-toolbar");
  let desired = clamp(Number(store.get("layout.outH", 200)) || 200, OUT_MIN, 2000);
  let lastOpen = desired > OUT_MIN + 6 ? desired : 200;

  const maxH = () => Math.max(OUT_MIN, (ws?.clientHeight ?? 600) - EDITOR_MIN - (toolbar?.offsetHeight ?? 36) - (sp?.offsetHeight ?? 8));
  const render = (animateIt = false) => {
    if (!ws.clientHeight) return; 
    const h = clamp(desired, OUT_MIN, maxH());
    if (animateIt && !reducedMotion()) {
      panel.classList.add("animating");
      setTimeout(() => panel.classList.remove("animating"), 480);
    }
    panel.style.setProperty("--out-h", `${h}px`);
    panel.classList.toggle("collapsed", h <= OUT_MIN + 4);
    sp.setAttribute("aria-valuenow", String(Math.round((h / maxH()) * 100)));
  };
  const set = (v, { animateIt = false, save = true } = {}) => {
    desired = clamp(v, OUT_MIN, Math.max(OUT_MIN, maxH()));
    if (desired > OUT_MIN + 6) lastOpen = desired;
    render(animateIt);
    if (save) store.set("layout.outH", Math.round(desired));
  };
  const toggle = () => set(desired > OUT_MIN + 6 ? OUT_MIN : lastOpen, { animateIt: true });

  sp.addEventListener("pointerdown", (e) => {
    if (e.button !== 0) return;
    e.preventDefault();
    sp.setPointerCapture(e.pointerId);
    const startY = e.clientY;
    const startH = panel.getBoundingClientRect().height;
    document.body.classList.add("resizing-v");
    sp.classList.add("dragging");
    const move = (ev) => set(startH - (ev.clientY - startY), { save: false });
    const up = () => {
      sp.removeEventListener("pointermove", move);
      sp.removeEventListener("pointerup", up);
      sp.removeEventListener("pointercancel", up);
      document.body.classList.remove("resizing-v");
      sp.classList.remove("dragging");
      store.set("layout.outH", Math.round(desired));
    };
    sp.addEventListener("pointermove", move);
    sp.addEventListener("pointerup", up);
    sp.addEventListener("pointercancel", up);
  });
  sp.addEventListener("dblclick", toggle);
  sp.addEventListener("keydown", (e) => {
    const step = { ArrowUp: 16, ArrowDown: -16, PageUp: 64, PageDown: -64 }[e.key];
    if (step) { e.preventDefault(); set(desired + step); return; }
    if (e.key === "Home") { e.preventDefault(); set(maxH(), { animateIt: true }); }
    else if (e.key === "End") { e.preventDefault(); set(OUT_MIN, { animateIt: true }); }
    else if (e.key === "Enter") { e.preventDefault(); toggle(); }
  });
  new ResizeObserver(() => render()).observe(ws);
  on("prefs-reset", () => set(200, { animateIt: true }));
  render();
}

export function initEditor() {
  loadTabs();
  bindTabBar();
  bindFallback();
  bindFiles();
  bindSplitter();
  renderTabs();
  refreshTabVisibility(false);
  updateStatus();

  window.addEventListener("dragover", (e) => e.preventDefault());
  window.addEventListener("drop", (e) => e.preventDefault());
  window.addEventListener("pagehide", () => persist.flush());
  window.addEventListener("beforeunload", () => persist.flush());

  loadMonaco();
  setTimeout(() => { if (!ed.editor) activateFallback(); }, FALLBACK_AFTER_MS);

  on("page", ({ to }) => {
    if (to !== "execution") return;
    requestAnimationFrame(() => {
      ed.editor?.layout();
      updateFades();
    });
  });
  on("motion", applyEditorOptions);
}
