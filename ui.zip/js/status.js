import { $, formatDuration } from "./dom.js";
import { state, canInject } from "./state.js";
import { bridgeGet, BRIDGE } from "./bridge.js";
import { log } from "./console.js";
import { toast } from "./toast.js";
import { injectBusy } from "./actions.js";
import { emit } from "./bus.js";

const INTERVALS = { visible: { status: 1500, tail: 400 }, hidden: { status: 4000, tail: 2000 } };
const timers = { status: 0, tail: 0 };
let lastAttachedPid = null;
let sessionTimer = 0;

function interval(key) {
  return (document.hidden ? INTERVALS.hidden : INTERVALS.visible)[key];
}

function setSession(kind, label, { roblox, pid, tip }) {
  const panel = $("#session-panel");
  const st = $("#sp-state");
  if (st) {
    st.className = `session-state ${kind}`;
    const txt = st.querySelector(".txt");
    if (txt) txt.textContent = label;
  }
  if (panel) {
    panel.classList.toggle("attached", kind === "attached");
    panel.dataset.tip = tip;
  }
  const robloxEl = $("#sp-roblox");
  if (robloxEl) robloxEl.textContent = roblox;
  const pidEl = $("#sp-pid");
  if (pidEl) pidEl.textContent = pid;

  const target = $("#exec-target");
  if (target) {
    target.className = `badge target${kind === "attached" ? " ok" : kind === "ready" ? " warn" : kind === "offline" ? " err" : ""}`;
    const targetText = $("#exec-target-text");
    if (targetText) {
      targetText.textContent =
        kind === "attached" ? `PID ${pid}` : kind === "ready" ? "Roblox ready" : kind === "offline" ? "Bridge offline" : "No target";
    }
  }
}

function setBridgeBadge(online) {
  const b = $("#bridge-badge");
  if (!b) return;
  b.className = `badge ${online ? "ok" : "warn"}`;
  $("#bridge-badge-text").textContent = online ? "Connected" : "Offline";
}

function renderLatency() {
  const ms = state.latency;
  const dot = $("#sb-lat-dot");
  const label = $("#sb-latency");
  const settingsEl = $("#settings-latency");
  if (!state.bridgeOnline || ms === null) {
    if (dot) dot.className = "lat-dot down";
    if (label) label.textContent = "Offline";
    if (settingsEl) settingsEl.textContent = "Offline";
    return;
  }
  const v = `${ms < 10 ? ms.toFixed(1) : Math.round(ms)} ms`;
  if (dot) dot.className = `lat-dot ${ms <= 50 ? "good" : ms <= 250 ? "slow" : "down"}`;
  if (label) label.textContent = v;
  if (settingsEl) settingsEl.textContent = v;
}

function renderUptime() {
  const up = $("#sp-uptime");
  if (up) up.textContent = state.attachedAt ? formatDuration(Date.now() - state.attachedAt) : "0:00";
}

function syncInjectButton() {
  const inj = $("#btn-inject");
  if (!inj) return;
  if (!inj.classList.contains("loading")) inj.disabled = !canInject() || injectBusy();
  inj.dataset.tip = state.pids.length
    ? "Already attached"
    : !state.robloxPids.length
      ? "Start Roblox first"
      : state.injectorAvailable ? "Attach Byte to Roblox" : "Byte-Injector.exe not found";
}

export async function pollStatus() {
  const s = await bridgeGet("/status", { measure: true });
  renderLatency();
  setBridgeBadge(state.bridgeOnline);
  if (!s) {
    setSession("offline", "Offline", { roblox: "Unknown", pid: "None", tip: "Bridge offline" });
    return;
  }
  state.pids = s.pids || [];
  state.robloxPids = s.robloxPids || [];
  state.injectorAvailable = !!s.injectorAvailable;
  syncInjectButton();

  const currentPid = state.pids[0] || null;
  if (currentPid) {
    state.activePid = currentPid;
    setSession("attached", "Attached", { roblox: "Running", pid: String(currentPid), tip: `Attached to PID ${currentPid}` });
  } else if (state.robloxPids.length) {
    state.activePid = null;
    setSession("ready", "Ready", { roblox: "Running", pid: String(state.robloxPids[0]), tip: "Roblox detected, not attached" });
  } else {
    state.activePid = null;
    setSession("", "Idle", { roblox: "Not running", pid: "None", tip: "Waiting for Roblox" });
  }

  if (currentPid && currentPid !== lastAttachedPid) {
    state.attachedAt = Date.now();

    if (state.authed && !state.gateOpen) toast(`Byte attached to Roblox (PID ${currentPid}).`, "ok", 3000);
    log(`Attached to Roblox PID ${currentPid}. Ready to execute.`, "ok");
    clearInterval(sessionTimer);
    sessionTimer = setInterval(renderUptime, 1000);
    emit("attach", currentPid);
  } else if (!currentPid && lastAttachedPid) {
    state.attachedAt = null;
    clearInterval(sessionTimer);
    if (state.authed && !state.gateOpen) toast("Byte detached from Roblox.", "warn", 3000);
    log(`Detached from PID ${lastAttachedPid}.`, "warn");
    emit("detach", lastAttachedPid);
  }
  lastAttachedPid = currentPid;
  renderUptime();
}

function kindFor(level) {
  const l = level.toLowerCase();
  if (l === "error" || l === "err") return "err";
  if (l === "warn" || l === "warning") return "warn";
  if (l === "ok" || l === "success") return "ok";
  return "out";
}

export async function tailOutput() {
  try {
    const r = await fetch(`${BRIDGE}/output?since=${state.outputCursor | 0}`, { cache: "no-store" });
    if (!r.ok) return;
    const j = await r.json();
    if (j.since === 0 && state.outputCursor > 0) state.outputCursor = 0;
    state.outputCursor = j.size || 0;
    if (!j.content) return;
    for (const line of j.content.split("\n")) {
      const clean = line.replace(/\r$/, "");
      if (!clean) continue;
      const bar = clean.indexOf("|");
      const lvl = bar > 0 ? clean.slice(0, bar) : "info";
      const msg = bar > 0 ? clean.slice(bar + 1) : clean;
      log(msg, kindFor(lvl));
    }
  } catch {  }
}

function loop(key, fn) {
  const run = async () => {
    try { await fn(); } finally { timers[key] = setTimeout(run, interval(key)); }
  };
  clearTimeout(timers[key]);
  timers[key] = setTimeout(run, interval(key));
}

export function startPolling() {
  loop("status", pollStatus);
  loop("tail", tailOutput);

  document.addEventListener("visibilitychange", () => {
    if (document.hidden) return;
    clearTimeout(timers.status);
    clearTimeout(timers.tail);
    loop("status", pollStatus);
    loop("tail", tailOutput);
    pollStatus();
  });
}
