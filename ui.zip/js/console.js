/* Console: one entry store rendered into two views (Executor output panel and
   the full Console page). Consecutive duplicates coalesce into a counter, the
   full view filters by level and text, and views stop auto-scrolling once the
   user scrolls up (a "new output" pill brings them back). */

import { $, $$, icon, highlight, timeStamp, copyText, saveTextFile, fileStamp, debounce, restartClass } from "./dom.js";
import { store } from "./store.js";
import { state } from "./state.js";
import { bridgePost } from "./bridge.js";
import { on, emit } from "./bus.js";
import { toast } from "./toast.js";
import { openMenu } from "./menu.js";
import { flashCopied } from "./fx.js";

const MAX_ENTRIES = 2000;
// fixed-width level tags read faster in a mono column than glyphs
const TAG = { out: "OUT", info: "SYS", ok: "OK", warn: "WRN", err: "ERR" };
const SR_PREFIX = { warn: "Warning: ", err: "Error: " };
const LEVEL_NAME = { out: "OUT", info: "INFO", ok: "OK", warn: "WARN", err: "ERROR" };

const entries = [];
let nextId = 1;
const counts = { all: 0, out: 0, sys: 0, warn: 0, err: 0 };
let unseenErrors = 0;
let burst = 0;
const views = [];
let fullView = null;
let miniView = null;

function bucket(kind) {
  if (kind === "out") return "out";
  if (kind === "warn") return "warn";
  if (kind === "err") return "err";
  return "sys";
}

function matches(view, e) {
  if (view.filter !== "all" && bucket(e.kind) !== view.filter) return false;
  if (view.query && !e.text.toLowerCase().includes(view.query)) return false;
  return true;
}

function emptyHtml(view) {
  const filtered = entries.length > 0;
  return `<div class="console-empty">
    ${icon(filtered ? "search" : "terminal")}
    <span>${filtered ? "Nothing matches this filter." : view.mini ? "No output yet. Run a script to see logs here." : "No output yet. Script output, warnings and errors from the attached session appear here."}</span>
  </div>`;
}

function lineNode(e, query, fresh) {
  const d = document.createElement("div");
  d.className = `line ${e.kind}${fresh ? " fresh" : ""}`;
  d.dataset.id = String(e.id);
  d.innerHTML =
    `<span class="ts">${timeStamp(e.t)}</span>` +
    `<span class="lvl" aria-hidden="true">${TAG[e.kind] || "OUT"}</span>` +
    `<span class="msg">${SR_PREFIX[e.kind] ? `<span class="visually-hidden">${SR_PREFIX[e.kind]}</span>` : ""}${highlight(e.text, query)}</span>` +
    (e.count > 1 ? `<span class="rep" aria-label="repeated ${e.count} times">${e.count}</span>` : "");
  return d;
}

function updateRep(node, count) {
  let rep = node.querySelector(".rep");
  if (!rep) {
    rep = document.createElement("span");
    rep.className = "rep";
    node.appendChild(rep);
  }
  rep.textContent = String(count);
  rep.setAttribute("aria-label", `repeated ${count} times`);
  restartClass(rep, "bump");
}

function queueScroll(view) {
  if (view.scrollQueued) return;
  view.scrollQueued = true;
  requestAnimationFrame(() => {
    view.scrollQueued = false;
    if (view.stick) view.el.scrollTop = view.el.scrollHeight;
  });
}

function updateJump(view) {
  const show = view.unseen > 0 && !view.stick;
  view.jump.classList.toggle("show", show);
  if (show) view.jump.querySelector("span").textContent = `${view.unseen} new line${view.unseen === 1 ? "" : "s"}`;
}

function appendTo(view, e, fresh) {
  view.el.querySelector(".console-empty")?.remove();
  const node = lineNode(e, view.query, fresh);
  view.el.appendChild(node);
  view.nodes.set(e.id, node);
  while (view.nodes.size > view.cap) {
    const [id, n] = view.nodes.entries().next().value;
    n.remove();
    view.nodes.delete(id);
  }
  if (view.stick) queueScroll(view);
  else { view.unseen += 1; updateJump(view); }
}

function renderView(view) {
  view.el.innerHTML = "";
  view.nodes.clear();
  view.unseen = 0;
  updateJump(view);
  const list = entries.filter((e) => matches(view, e)).slice(-view.cap);
  if (!list.length) { view.el.innerHTML = emptyHtml(view); return; }
  const frag = document.createDocumentFragment();
  for (const e of list) {
    const n = lineNode(e, view.query, false);
    frag.appendChild(n);
    view.nodes.set(e.id, n);
  }
  view.el.appendChild(frag);
  view.stick = true;
  view.el.scrollTop = view.el.scrollHeight;
}

/* chip counters, nav badge and output-panel count, batched per frame */
let countsQueued = false;
const lastShown = {};
function queueCounts() {
  if (countsQueued) return;
  countsQueued = true;
  requestAnimationFrame(() => {
    countsQueued = false;
    for (const k of Object.keys(counts)) {
      const n = document.querySelector(`.chip .n[data-count="${k}"]`);
      if (!n) continue;
      const v = String(counts[k]);
      if (n.textContent !== v) {
        n.textContent = v;
        if (state.page === "console" && lastShown[k] !== undefined) restartClass(n, "bump");
        lastShown[k] = v;
      }
      if (k === "err" || k === "warn") n.classList.toggle("has", counts[k] > 0);
    }
    const mini = $("#mini-count");
    if (mini) mini.textContent = counts.all ? `${counts.all}` : "";
    const badge = $("#nav-err-badge");
    if (badge) {
      badge.hidden = unseenErrors === 0;
      badge.textContent = unseenErrors > 99 ? "99+" : String(unseenErrors);
    }
  });
}

function tally(kind) {
  counts.all += 1;
  counts[bucket(kind)] += 1;
  if (kind === "err" && state.page !== "console") unseenErrors += 1;
  queueCounts();
}

/* public: append a line to every view. kind: out | info | ok | warn | err */
export function log(text, kind = "info") {
  const msg = String(text ?? "");
  const k = TAG[kind] ? kind : "info";
  const last = entries[entries.length - 1];
  if (last && last.kind === k && last.text === msg) {
    last.count += 1;
    last.t = new Date();
    for (const v of views) {
      const n = v.nodes.get(last.id);
      if (n) updateRep(n, last.count);
    }
    tally(k);
    return;
  }

  const e = { id: nextId++, t: new Date(), kind: k, text: msg, count: 1 };
  entries.push(e);
  if (entries.length > MAX_ENTRIES) {
    const removed = entries.splice(0, entries.length - MAX_ENTRIES);
    for (const r of removed) {
      for (const v of views) {
        const n = v.nodes.get(r.id);
        if (n) { n.remove(); v.nodes.delete(r.id); }
      }
    }
  }
  // only animate the first lines of a burst; a 300-line dump should just appear
  if (burst === 0) requestAnimationFrame(() => { burst = 0; });
  burst += 1;
  const fresh = burst <= 12;
  for (const v of views) if (matches(v, e)) appendTo(v, e, fresh);
  tally(k);
}

export async function clearConsole() {
  entries.length = 0;
  for (const k of Object.keys(counts)) counts[k] = 0;
  unseenErrors = 0;
  views.forEach(renderView);
  queueCounts();
  state.outputCursor = 0;
  await bridgePost("/output/clear");
}

function serialize(view) {
  return entries
    .filter((e) => matches(view, e))
    .map((e) => `[${timeStamp(e.t)}] ${LEVEL_NAME[e.kind].padEnd(5)} ${e.text}${e.count > 1 ? ` (x${e.count})` : ""}`)
    .join("\n");
}

async function copyView(view, btn) {
  const text = serialize(view);
  if (!text) { toast("Nothing to copy yet.", "warn"); return; }
  if (await copyText(text)) {
    flashCopied(btn);
    toast("Output copied.", "ok", 1600);
  } else toast("Clipboard access denied.", "err");
}

async function exportView(view) {
  const text = serialize(view);
  if (!text) { toast("Nothing to save yet.", "warn"); return; }
  const r = await saveTextFile(`byte-console-${fileStamp()}.txt`, text, { description: "Log file", extensions: [".txt", ".log"] });
  if (r === "saved") toast("Console output saved.", "ok");
  else if (r === "downloaded") toast("Console output downloaded.", "ok");
  else if (r === "failed") toast("Could not save the file.", "err");
}

function onContext(e, view) {
  e.preventDefault();
  const line = e.target.closest(".line");
  const entry = line ? entries.find((x) => x.id === +line.dataset.id) : null;
  const selection = String(window.getSelection?.() || "");
  openMenu(e.clientX, e.clientY, [
    selection ? { label: "Copy selection", icon: "copy", run: async () => { if (await copyText(selection)) toast("Copied.", "ok", 1400); } } : null,
    entry ? { label: "Copy line", icon: "copy", run: async () => { if (await copyText(entry.text)) toast("Line copied.", "ok", 1400); } } : null,
    { label: "Copy visible output", icon: "copy", run: () => copyView(view) },
    { label: "Save to file", icon: "download", run: () => exportView(view) },
    "sep",
    { label: "Clear console", icon: "trash", kbd: "Ctrl+L", danger: true, run: clearConsole }
  ]);
}

function makeView(el, { mini = false } = {}) {
  const wrap = el.parentElement;
  const jump = document.createElement("button");
  jump.className = "jump-pill";
  jump.type = "button";
  jump.innerHTML = `${icon("arrow-down")}<span>New output</span>`;
  wrap.appendChild(jump);

  const view = { el, wrap, jump, mini, filter: "all", query: "", stick: true, unseen: 0, nodes: new Map(), cap: mini ? 300 : 1200, scrollQueued: false };
  el.addEventListener("scroll", () => {
    const atBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 32;
    view.stick = atBottom;
    if (atBottom && view.unseen) { view.unseen = 0; updateJump(view); }
  }, { passive: true });
  jump.addEventListener("click", () => {
    view.stick = true;
    view.unseen = 0;
    updateJump(view);
    el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
  });
  el.addEventListener("contextmenu", (e) => onContext(e, view));
  views.push(view);
  return view;
}

function initRadioGroup(group, value, onChange) {
  const buttons = $$("[role=radio]", group);
  const set = (v, focus = false) => {
    buttons.forEach((b) => {
      const on = b.dataset.value === v;
      b.setAttribute("aria-checked", on ? "true" : "false");
      b.tabIndex = on ? 0 : -1;
      if (on && focus) b.focus();
    });
  };
  set(value);
  group.addEventListener("click", (e) => {
    const b = e.target.closest("[role=radio]");
    if (!b) return;
    set(b.dataset.value);
    onChange(b.dataset.value);
  });
  group.addEventListener("keydown", (e) => {
    const i = buttons.findIndex((b) => b.getAttribute("aria-checked") === "true");
    let n = -1;
    if (e.key === "ArrowRight" || e.key === "ArrowDown") n = (i + 1) % buttons.length;
    else if (e.key === "ArrowLeft" || e.key === "ArrowUp") n = (i - 1 + buttons.length) % buttons.length;
    else if (e.key === "Home") n = 0;
    else if (e.key === "End") n = buttons.length - 1;
    if (n < 0) return;
    e.preventDefault();
    set(buttons[n].dataset.value, true);
    onChange(buttons[n].dataset.value);
  });
}

export function focusConsoleSearch() {
  const s = $("#console-search");
  s?.focus();
  s?.select();
}

export function initConsole() {
  miniView = makeView($("#console"), { mini: true });
  fullView = makeView($("#console-full"));

  // filter chips
  const savedFilter = store.get("console.filter", "all");
  fullView.filter = ["all", "out", "sys", "warn", "err"].includes(savedFilter) ? savedFilter : "all";
  initRadioGroup($("#console-filter"), fullView.filter, (v) => {
    fullView.filter = v;
    store.set("console.filter", v);
    renderView(fullView);
  });

  // search
  const search = $("#console-search");
  const applySearch = debounce(() => {
    fullView.query = search.value.trim().toLowerCase();
    renderView(fullView);
  }, 90);
  search.addEventListener("input", applySearch);
  search.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && search.value) { e.stopPropagation(); search.value = ""; applySearch.flush(); }
  });

  // toggles
  const tsBtn = $("#btn-console-ts");
  const wrapBtn = $("#btn-console-wrap");
  const applyToggles = () => {
    const ts = store.get("console.ts", true);
    const wrap = store.get("console.wrap", true);
    tsBtn.setAttribute("aria-pressed", String(ts));
    wrapBtn.setAttribute("aria-pressed", String(wrap));
    for (const v of views) v.el.classList.toggle("no-ts", !ts);
    fullView.el.classList.toggle("nowrap", !wrap);
  };
  tsBtn.addEventListener("click", () => { store.set("console.ts", !store.get("console.ts", true)); applyToggles(); });
  wrapBtn.addEventListener("click", () => { store.set("console.wrap", !store.get("console.wrap", true)); applyToggles(); });
  applyToggles();

  $("#btn-console-copy").addEventListener("click", (e) => copyView(fullView, e.currentTarget));
  $("#btn-console-export").addEventListener("click", () => exportView(fullView));
  $("#btn-console-clear").addEventListener("click", clearConsole);
  $("#btn-mini-copy").addEventListener("click", (e) => copyView(miniView, e.currentTarget));
  $("#btn-mini-clear").addEventListener("click", clearConsole);

  views.forEach(renderView);
  queueCounts();

  on("page", ({ to }) => {
    if (to === "console") {
      unseenErrors = 0;
      queueCounts();
      // returning to the page: land on the newest line
      if (fullView.stick) fullView.el.scrollTop = fullView.el.scrollHeight;
    }
  });
  on("prefs-reset", applyToggles);
  emit("console-ready");
}
