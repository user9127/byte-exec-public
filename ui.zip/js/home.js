import { $, $$, escapeHtml } from "./dom.js";
import { goToPage } from "./nav.js";
import { newTab, openInNewTab, openFileDialog, getTabs } from "./editor.js";
import { LIBRARY, openLibraryScript } from "./library.js";
import { launchSupportedRoblox } from "./actions.js";
import { state } from "./state.js";
import { store } from "./store.js";
import { on, emit } from "./bus.js";

const RECENTS_KEY = "recents.v1";

export function formatRelativeTime(timestamp) {
  if (!timestamp) return "";
  const diff = Math.max(0, Date.now() - timestamp);
  const sec = Math.floor(diff / 1000);
  if (sec < 60) return "just now";
  const min = Math.floor(sec / 60);
  if (min < 60) return `${min}m ago`;
  const hr = Math.floor(min / 60);
  if (hr < 24) return `${hr}h ago`;
  const day = Math.floor(hr / 24);
  if (day < 7) return `${day}d ago`;
  const wk = Math.floor(day / 7);
  return `${wk}w ago`;
}

export function getRecents() {
  const saved = store.get(RECENTS_KEY);
  if (Array.isArray(saved) && saved.length) {
    return saved;
  }

  const tabs = getTabs();
  const initial = [];
  const now = Date.now();
  tabs.forEach((t, i) => {
    if (!t.isHome && t.name) {
      initial.push({
        id: t.name.toLowerCase(),
        name: t.name,
        time: now - (i * 18 + 5) * 60 * 1000,
        content: t.value || ""
      });
    }
  });
  if (initial.length) {
    store.set(RECENTS_KEY, initial);
  }
  return initial;
}

export function recordRecent({ name, content = null, libraryName = null, path = null } = {}) {
  if (!name || typeof name !== "string") return;
  const list = getRecents().slice();
  const id = name.toLowerCase().trim();
  const existingIdx = list.findIndex((item) => (item.id || item.name.toLowerCase()) === id);

  const updatedItem = {
    id,
    name: name.trim(),
    time: Date.now(),
    content: content !== null ? content : (existingIdx !== -1 ? list[existingIdx].content : ""),
    libraryName: libraryName || (existingIdx !== -1 ? list[existingIdx].libraryName : null),
    path: path || (existingIdx !== -1 ? list[existingIdx].path : null)
  };

  if (existingIdx !== -1) {
    list.splice(existingIdx, 1);
  }
  list.unshift(updatedItem);
  const trimmed = list.slice(0, 15);
  store.set(RECENTS_KEY, trimmed);
  renderHomeRecent();
}

export function renderHomeRecent() {
  const container = $("#home-recent-list");
  if (!container) return;

  const recents = getRecents();
  if (!recents.length) {
    container.innerHTML = `<div class="hir-empty"><span>No recent scripts</span></div>`;
    return;
  }

  container.innerHTML = recents.map((item, idx) => `
    <button class="home-item-row recent-row" type="button" data-idx="${idx}" title="${escapeHtml(item.name)}">
      <svg class="ic"><use href="#i-code"/></svg>
      <span class="hir-label">${escapeHtml(item.name)}</span>
      <span class="hir-time">${escapeHtml(formatRelativeTime(item.time))}</span>
    </button>
  `).join("");

  $$(".recent-row", container).forEach((btn) => {
    btn.addEventListener("click", () => {
      const idx = +btn.dataset.idx;
      const item = recents[idx];
      if (!item) return;

      recordRecent({
        name: item.name,
        content: item.content,
        libraryName: item.libraryName,
        path: item.path
      });

      const tabs = getTabs();
      const existingTab = tabs.find((t) => !t.isHome && t.name.toLowerCase() === item.name.toLowerCase());
      if (existingTab) {
        import("./editor.js").then((m) => m.switchTab(existingTab.id));
        return;
      }

      if (item.libraryName) {
        const found = LIBRARY.find((l) => l.name.toLowerCase() === item.libraryName.toLowerCase());
        if (found) {
          openLibraryScript(found);
          return;
        }
      }

      openInNewTab(item.name, item.content || `-- ${item.name}\n`);
    });
  });
}

export function renderExplorer() {
  const libContainer = $("#exp-library-items");
  if (libContainer) {
    libContainer.innerHTML = LIBRARY.slice(0, 8).map((s) => `
      <div class="exp-leaf exp-lib-leaf" data-lib="${escapeHtml(s.name)}">
        <svg class="ic"><use href="#i-code"/></svg>
        <span class="leaf-name">${escapeHtml(s.name)}</span>
      </div>
    `).join("");

    $$(".exp-lib-leaf", libContainer).forEach((item) => {
      item.addEventListener("click", () => {
        const name = item.dataset.lib;
        const found = LIBRARY.find((l) => l.name === name);
        if (found) {
          recordRecent({ name: found.name, libraryName: found.name, content: found.code });
          openLibraryScript(found);
        }
      });
    });
  }

  const scriptsContainer = $("#exp-scripts-items");
  if (scriptsContainer) {
    const tabs = getTabs();
    scriptsContainer.innerHTML = tabs.map((t) => `
      <div class="exp-leaf exp-tab-leaf" data-id="${t.id}">
        <svg class="ic"><use href="#i-code"/></svg>
        <span class="leaf-name">${escapeHtml(t.name)}</span>
      </div>
    `).join("");

    $$(".exp-tab-leaf", scriptsContainer).forEach((item) => {
      item.addEventListener("click", () => {
        const id = +item.dataset.id;
        import("./editor.js").then((m) => m.switchTab(id));
      });
    });
  }

  const autoContainer = $("#exp-autoexec-items");
  if (autoContainer) {
    autoContainer.innerHTML = `
      <div class="exp-leaf exp-auto-leaf" data-file="auto_init.lua">
        <svg class="ic"><use href="#i-play"/></svg>
        <span class="leaf-name">auto_init.lua</span>
      </div>
    `;
    $$(".exp-auto-leaf", autoContainer).forEach((leaf) => {
      leaf.addEventListener("click", () => {
        recordRecent({ name: "auto_init.lua", content: "-- Auto-execute initialization script\nprint('Auto execute running')\n" });
        openInNewTab("auto_init.lua", "-- Auto-execute initialization script\nprint('Auto execute running')\n");
      });
    });
  }
}

export function initHomeAndExplorer() {

  $("#hcard-new-script")?.addEventListener("click", () => newTab());
  $("#hcard-script-hub")?.addEventListener("click", () => goToPage("library"));
  $("#hcard-launch-roblox")?.addEventListener("click", () => launchSupportedRoblox());
  $("#hcard-settings")?.addEventListener("click", () => goToPage("settings"));
  $("#hact-open-file")?.addEventListener("click", () => openFileDialog());

  renderHomeRecent();

  $$(".exp-group-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const group = btn.closest(".exp-group");
      group?.classList.toggle("is-open");
    });
  });

  const searchInput = $("#exp-search-input");
  if (searchInput) {
    searchInput.addEventListener("input", () => {
      const q = searchInput.value.trim().toLowerCase();
      $$(".exp-leaf").forEach((leaf) => {
        const text = leaf.textContent.toLowerCase();
        leaf.style.display = !q || text.includes(q) ? "" : "none";
      });
    });
  }

  $("#btn-exp-new")?.addEventListener("click", () => newTab());

  renderExplorer();

  on("tabs-change", () => {
    renderExplorer();
    renderHomeRecent();
  });
}
